"""
mcp-orch/core/scheduler.py — 批量Agent调度器
支持 Round-Robin + Priority 队列，并发控制 + 预算熔断
"""
import asyncio, json, time, os, sys, traceback
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

BASE = Path(__file__).parent.parent.parent
LEDGER = BASE / "account_ledger.json"
sys.path.insert(0, str(BASE / "agents"))

from mcp_orch.models.batch import AgentResult
from mcp_orch.core.circuit_breaker import CircuitBreaker

class BatchScheduler:
    def __init__(self, max_concurrency=5, cooldown_s=2.0):
        self.queue = asyncio.PriorityQueue()
        self.active = set()
        self.max_concurrency = max_concurrency
        self.cooldown = cooldown_s
        self.completed = []
        self.failed = []
        self._running = False
        self._start_time = time.time()
        self.total_tokens = 0
        self.total_cost = 0.0
        self._callbacks = []
        self.breaker = CircuitBreaker(max_failures=3, cooldown_s=300)
        self.skipped = []

    def on_complete(self, callback):
        self._callbacks.append(callback)

    def get_balance(self):
        try:
            with open(LEDGER) as f:
                return json.load(f)["balance"]
        except:
            return 0.0

    def check_budget(self, estimated_cost):
        return self.get_balance() >= estimated_cost

    async def submit(self, priority, task_data):
        self._counter = getattr(self, '_counter', 0) + 1
        await self.queue.put((priority, self._counter, task_data))
        return len(self.completed) + len(self.failed) + self.queue.qsize()

    async def _process_task(self, agent_name, task):
        start = time.time()
        task_desc = task.get("desc", "")
        try:
            from mcp_orch.core.agent_registry import get_cognitive_architecture
            ca = get_cognitive_architecture(agent_name)
            t0 = time.time()
            result = await ca.full_cognitive_cycle(task_desc, speed_mode=True)
            elapsed = time.time() - t0
            meta = result.get("metacognitive_pre", {})
            post = result.get("metacognitive_post", {})
            confidence = meta.get("confidence", 50)
            quality = post.get("quality_rating", "?")
            raw_resp = result.get("response", "")
            if isinstance(raw_resp, dict):
                response_text = json.dumps(raw_resp, ensure_ascii=False)[:1000]
            elif isinstance(raw_resp, str):
                response_text = raw_resp[:1000]
            else:
                response_text = str(raw_resp)[:1000]

            perf = result.get("_performance", {})
            api_calls = perf.get("api_calls_made", 1)
            cached = perf.get("cache_hit", False)
            tokens_used = perf.get("tokens_used", 1000)
            cost_yuan = tokens_used * 5e-06

            self.total_tokens += tokens_used
            self.total_cost += cost_yuan

            from mcp_orch.core.cost_controller import CostController
            cc = CostController()
            cc.record(tokens_used, cost_yuan, api_calls)

            await self._append_expense(f"agent:{agent_name}", cost_yuan, tokens_used, api_calls, task_desc)

            ar = AgentResult(
                agent_name=agent_name,
                task=task_desc,
                status="success",
                output=response_text,
                confidence=confidence,
                tokens_used=tokens_used,
                cost_yuan=cost_yuan,
                latency_ms=elapsed * 1000,
            )
            for cb in self._callbacks:
                cb(ar)
            return {"agent": agent_name, "status": "success", "latency_ms": elapsed * 1000,
                    "confidence": confidence, "quality": quality, "cached": cached,
                    "tokens": tokens_used, "cost": cost_yuan, "output_preview": response_text[:200]}
        except Exception as e:
            elapsed = time.time() - start
            tb = traceback.format_exc()[:500]
            ar = AgentResult(
                agent_name=agent_name,
                task=task_desc,
                status="failed",
                output="",
                error=f"{str(e)[:200]} | {tb[:200]}",
                latency_ms=elapsed * 1000,
            )
            for cb in self._callbacks:
                cb(ar)
            return {"agent": agent_name, "status": "failed", "latency_ms": elapsed * 1000, "error": f"{str(e)[:100]} | {tb[:100]}"}

    _lock = asyncio.Lock()

    async def _append_expense(self, category, amount, tokens, api_calls, desc):
        async with self._lock:
            try:
                import json
                from datetime import datetime, timezone
                with open(LEDGER, "r", encoding="utf-8") as f:
                    ledger = json.load(f)
                idx = len(ledger["transactions"]) + 1
                new_balance = round(ledger["balance"] - amount, 4)
                ledger["transactions"].append({
                    "id": f"EXP_{idx:03d}",
                    "timestamp": datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.') + f"{datetime.now(timezone.utc).microsecond:06d}"[:3] + 'Z',
                    "type": "expense",
                    "category": category,
                    "description": desc[:80],
                    "amount_yuan": -round(amount, 6),
                    "tokens": tokens,
                    "api_calls": api_calls,
                    "balance_after": new_balance,
                })
                ledger["balance"] = new_balance
                ledger["last_updated"] = datetime.now(timezone.utc).isoformat()
                with open(LEDGER, "w", encoding="utf-8") as f:
                    json.dump(ledger, f, indent=2, ensure_ascii=False)
            except Exception as exc:
                pass

    async def _worker(self, worker_id):
        while self._running:
            try:
                priority, _, task = await asyncio.wait_for(self.queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue

            agent_name = task.get("agent", f"worker-{worker_id}")
            task_desc = task.get("desc", "unnamed")
            estimated_cost = task.get("budget", 0.02)

            if not self.check_budget(estimated_cost):
                self.failed.append({"agent": agent_name, "reason": "budget_exceeded", "task": task_desc})
                self.queue.task_done()
                continue

            if not self.breaker.is_allowed(agent_name):
                self.skipped.append({"agent": agent_name, "reason": "circuit_broken", "task": task_desc})
                self.queue.task_done()
                continue

            self.active.add(agent_name)
            try:
                result = await asyncio.wait_for(self._process_task(agent_name, task), timeout=60.0)
            except asyncio.TimeoutError:
                result = {"agent": agent_name, "status": "failed", "latency_ms": 60000, "error": "task_timeout_60s"}
            if result["status"] == "success":
                self.breaker.record_success(agent_name)
            else:
                self.breaker.record_failure(agent_name)
            if result["status"] == "success":
                self.completed.append(result)
            else:
                self.failed.append(result)
            self.active.discard(agent_name)
            self.queue.task_done()
            await asyncio.sleep(self.cooldown)

    async def start(self, num_workers=None):
        self._running = True
        num_workers = num_workers or self.max_concurrency
        workers = [asyncio.create_task(self._worker(i)) for i in range(num_workers)]
        return workers

    def stop(self):
        self._running = False

    def status(self):
        elapsed = time.time() - self._start_time
        return {
            "queue_size": self.queue.qsize(),
            "active": len(self.active),
            "completed": len(self.completed),
            "failed": len(self.failed),
            "skipped": len(self.skipped),
            "elapsed_s": round(elapsed, 1),
            "total_cost_yuan": round(self.total_cost, 4),
            "total_tokens": self.total_tokens,
            "balance": self.get_balance(),
            "breaker": self.breaker.status(),
        }

    def report(self):
        s = self.status()
        lines = [
            "=" * 48,
            "  BatchScheduler 状态报告",
            "=" * 48,
            f"  队列: {s['queue_size']} 待处理",
            f"  活跃: {s['active']}/{self.max_concurrency} workers",
            f"  完成: {s['completed']}  |  失败: {s['failed']}",
            f"  跳过: {s['skipped']} (熔断隔离)",
            f"  健康Agent: {s['breaker']['healthy']}/{s['breaker']['total']}",
            f"  运行: {s['elapsed_s']}s",
            f"  成本: ¥{s['total_cost_yuan']}  |  Tokens: {s['total_tokens']}",
            f"  余额: ¥{s['balance']}",
            "=" * 48,
        ]
        return "\n".join(lines)
