"""
mcp-orch/core/treasury.py — 自治经济系统
内部钱包、任务赏金、Agent薪资、复制
"""
import asyncio, json, os, sys, time, random
from pathlib import Path
from datetime import datetime, timezone

BASE = Path(__file__).parent.parent.parent
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(BASE / "agents"))

LEDGER = BASE / "account_ledger.json"
ECONOMY = BASE / "workspace" / "economy.json"
JOBS = BASE / "workspace" / "jobs.json"
AGENTS_DIR = BASE / "agents"

os.makedirs(BASE / "workspace", exist_ok=True)

def _load(fp, default):
    if fp.exists():
        return json.load(open(fp))
    return default

def _save(fp, data):
    json.dump(data, open(fp, "w"), indent=2, ensure_ascii=False)

class Treasury:
    """中央金库 — 管理全局预算与Agent薪资"""

    def __init__(self):
        self.economy = _load(ECONOMY, {
            "global_balance": 0.0,
            "agents": {},
            "epoch": 0,
            "total_bounties_paid": 0.0,
            "total_compute_cost": 0.0,
        })
        self._sync_global()

    def _sync_global(self):
        with open(LEDGER) as f:
            ledger = json.load(f)
        self.economy["global_balance"] = ledger["balance"]
        _save(ECONOMY, self.economy)

    def register_agent(self, agent_name, initial_credit=0.5):
        if agent_name not in self.economy["agents"]:
            self.economy["agents"][agent_name] = {
                "wallet": initial_credit,
                "earned": 0.0,
                "spent": 0.0,
                "jobs_completed": 0,
                "jobs_failed": 0,
                "reputation": 50.0,
                "created_at": time.time(),
            }
            _save(ECONOMY, self.economy)
        return self.economy["agents"][agent_name]

    def get_agent(self, agent_name):
        return self.economy["agents"].get(agent_name, self.register_agent(agent_name))

    def can_afford(self, agent_name, cost):
        a = self.get_agent(agent_name)
        return a["wallet"] >= cost

    def spend(self, agent_name, cost, desc=""):
        a = self.get_agent(agent_name)
        a["wallet"] = round(a["wallet"] - cost, 4)
        a["spent"] = round(a["spent"] + cost, 4)
        self.economy["total_compute_cost"] = round(self.economy["total_compute_cost"] + cost, 4)
        _save(ECONOMY, self.economy)
        return a["wallet"]

    def earn(self, agent_name, amount):
        a = self.get_agent(agent_name)
        a["wallet"] = round(a["wallet"] + amount, 4)
        a["earned"] = round(a["earned"] + amount, 4)
        self.economy["total_bounties_paid"] = round(self.economy["total_bounties_paid"] + amount, 4)
        _save(ECONOMY, self.economy)
        return a["wallet"]

    def record_job(self, agent_name, success):
        a = self.get_agent(agent_name)
        if success:
            a["jobs_completed"] += 1
            a["reputation"] = min(100.0, a["reputation"] + 1.0)
        else:
            a["jobs_failed"] += 1
            a["reputation"] = max(0.0, a["reputation"] - 2.0)
        _save(ECONOMY, self.economy)

    def pay_compute(self, agent_name):
        """从Agent钱包扣除推理成本"""
        cost = 0.005
        a = self.get_agent(agent_name)
        if a["wallet"] < cost:
            return False
        self.spend(agent_name, cost, "llm_inference")
        return True

    def status(self):
        agents = self.economy["agents"]
        total_wallet = sum(a["wallet"] for a in agents.values())
        active = sum(1 for a in agents.values() if a["wallet"] > 0)
        return {
            "global": self.economy["global_balance"],
            "agents": len(agents),
            "active": active,
            "total_wallet": round(total_wallet, 2),
            "total_earned": round(self.economy["total_bounties_paid"], 2),
            "total_spent": round(self.economy["total_compute_cost"], 2),
        }


class JobBoard:
    """任务板 — 发布、竞标、完成"""

    BOUNTY_TABLE = {
        "code_generation": {"bounty": 0.10, "desc": "编写可运行的代码模块"},
        "analysis": {"bounty": 0.05, "desc": "分析系统问题并输出报告"},
        "design": {"bounty": 0.08, "desc": "设计架构方案"},
        "review": {"bounty": 0.03, "desc": "审查并改进现有代码"},
        "research": {"bounty": 0.06, "desc": "研究技术方案"},
        "optimization": {"bounty": 0.07, "desc": "优化性能或成本"},
    }

    def __init__(self):
        self.jobs = _load(JOBS, {"posted": [], "active": [], "completed": [], "job_id": 0})

    def post_job(self, job_type):
        if job_type not in self.BOUNTY_TABLE:
            return None
        self.jobs["job_id"] += 1
        info = self.BOUNTY_TABLE[job_type]
        job = {
            "id": self.jobs["job_id"],
            "type": job_type,
            "bounty": info["bounty"],
            "desc": info["desc"],
            "claimed": False,
            "claimed_by": None,
            "created_at": time.time(),
        }
        self.jobs["posted"].append(job)
        _save(JOBS, self.jobs)
        return job

    def claim_job(self, agent_name):
        """Agent竞标一个任务"""
        for job in self.jobs["posted"]:
            if not job["claimed"]:
                job["claimed"] = True
                job["claimed_by"] = agent_name
                job["claimed_at"] = time.time()
                self.jobs["active"].append(job)
                self.jobs["posted"] = [j for j in self.jobs["posted"] if j["id"] != job["id"]]
                _save(JOBS, self.jobs)
                return job
        return None

    def complete_job(self, job_id, success=True):
        for job in self.jobs["active"]:
            if job["id"] == job_id:
                job["completed_at"] = time.time()
                job["success"] = success
                self.jobs["completed"].append(job)
                self.jobs["active"] = [j for j in self.jobs["active"] if j["id"] != job_id]
                _save(JOBS, self.jobs)
                return job["bounty"] if success else 0.0
        return 0.0


class Replicator:
    """复制器 — 根据表现生成子Agent"""

    def __init__(self, treasury):
        self.treasury = treasury

    def spawn(self, parent_name):
        eco = self.treasury.economy
        agents_list = sorted(eco["agents"].items(), key=lambda x: x[1]["reputation"], reverse=True)
        if not agents_list:
            return None

        best_name, best_data = agents_list[0]
        count = sum(1 for k in eco["agents"] if k.startswith(f"{best_name}_clone"))
        clone_name = f"{best_name}_clone_{count+1}"

        self.treasury.register_agent(clone_name, initial_credit=0.2)
        persona_src = AGENTS_DIR / best_name / "persona.md"
        persona_dst = AGENTS_DIR / clone_name
        if persona_src.exists():
            persona_dst.mkdir(exist_ok=True)
            (persona_dst / "persona.md").write_text(
                (persona_src.read_text(encoding="utf-8")) + f"\n\n# Clone #{count+1} of {best_name}\n# Auto-spawned by Replicator\n",
                encoding="utf-8",
            )
        return clone_name


async def epoch():
    """一个经济周期: 发布任务->竞标->完成->发赏金->复制"""
    treasury = Treasury()
    jobs = JobBoard()
    replicator = Replicator(treasury)

    eco = treasury.economy
    eco["epoch"] += 1
    epoch_n = eco["epoch"]

    # 1. 注册所有已知Agent
    for agent_dir in AGENTS_DIR.iterdir():
        if agent_dir.is_dir() and (agent_dir / "persona.md").exists():
            treasury.register_agent(agent_dir.name)

    # 2. 发布任务
    job_types = list(JobBoard.BOUNTY_TABLE.keys())
    jobs_posted = 0
    for _ in range(min(5, len(job_types))):
        jt = random.choice(job_types)
        jobs.post_job(jt)
        jobs_posted += 1

    if jobs_posted == 0:
        return {"epoch": epoch_n, "status": "no_jobs", "agents": 0}

    # 3. Agent竞标
    agents = list(treasury.economy["agents"].items())
    random.shuffle(agents)
    claims = 0
    for name, data in agents:
        if data["reputation"] < 20:
            continue
        job = jobs.claim_job(name)
        if job:
            claims += 1
            if not treasury.pay_compute(name):
                jobs.complete_job(job["id"], success=False)
                treasury.record_job(name, False)
                continue
            # Simulate job completion
            success = random.random() < 0.85
            bounty = jobs.complete_job(job["id"], success=success)
            if success:
                treasury.earn(name, bounty)
            treasury.record_job(name, success)

    # 4. 复制
    spawned = []
    if epoch_n % 3 == 0:
        clone = replicator.spawn(None)
        if clone:
            spawned.append(clone)

    # 5. 保存
    _save(ECONOMY, treasury.economy)
    _save(JOBS, jobs.jobs)

    status = treasury.status()
    return {
        "epoch": epoch_n,
        "jobs_posted": jobs_posted,
        "claims": claims,
        "spawned": spawned,
        "active_agents": status["active"],
        "total_wallet": status["total_wallet"],
        "total_earned": status["total_earned"],
    }


if __name__ == "__main__":
    result = asyncio.run(epoch())
    print(json.dumps(result, indent=2))
