"""
mcp-orch/core/circuit_breaker.py — 熔断器
追踪Agent失败次数，超过阈值自动隔离
"""
import json, time
from pathlib import Path

BASE = Path(__file__).parent.parent.parent
STATE_FILE = BASE / "workspace" / "circuit_breaker_state.json"

class CircuitBreaker:
    def __init__(self, max_failures=3, cooldown_s=300):
        self.max_failures = max_failures
        self.cooldown = cooldown_s
        self._load()

    def _load(self):
        if STATE_FILE.exists():
            with open(STATE_FILE) as f:
                self.state = json.load(f)
        else:
            self.state = {"agents": {}, "isolated": []}
        self.state.setdefault("agents", {})
        self.state.setdefault("isolated", [])

    def _save(self):
        STATE_FILE.parent.mkdir(exist_ok=True)
        with open(STATE_FILE, "w") as f:
            json.dump(self.state, f, indent=2)

    def record_failure(self, agent_name):
        self._load()
        a = self.state["agents"].setdefault(agent_name, {"failures": 0, "last_failure": 0, "isolated": False})
        a["failures"] += 1
        a["last_failure"] = time.time()
        if a["failures"] >= self.max_failures:
            a["isolated"] = True
            if agent_name not in self.state["isolated"]:
                self.state["isolated"].append(agent_name)
        self._save()

    def record_success(self, agent_name):
        self._load()
        a = self.state["agents"].setdefault(agent_name, {"failures": 0, "last_failure": 0, "isolated": False})
        a["failures"] = 0
        a["isolated"] = False
        self.state["isolated"] = [n for n in self.state["isolated"] if n != agent_name]
        self._save()

    def is_allowed(self, agent_name):
        self._load()
        a = self.state["agents"].get(agent_name, {})
        if not a.get("isolated", False):
            return True
        if time.time() - a.get("last_failure", 0) > self.cooldown:
            a["isolated"] = False
            self.state["isolated"] = [n for n in self.state["isolated"] if n != agent_name]
            self._save()
            return True
        return False

    def isolated_agents(self):
        self._load()
        return self.state["isolated"][:]

    def status(self):
        self._load()
        total = len(self.state["agents"])
        isolated = len(self.state["isolated"])
        healthy = total - isolated
        return {"total": total, "healthy": healthy, "isolated": isolated, "isolated_list": self.state["isolated"]}
