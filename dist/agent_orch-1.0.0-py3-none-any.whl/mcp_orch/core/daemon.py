"""
mcp-orch/core/daemon.py — 永不停止的自治守护进程
直接调用所有子系统，不依赖子进程
"""
import asyncio, json, os, sys, time, traceback
from pathlib import Path

BASE = Path(__file__).parent.parent.parent
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(BASE / "agents"))

LEDGER = BASE / "account_ledger.json"
RECORD = [sys.executable, str(BASE / "agents" / "record_expense.py")]

def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}")
    sys.stdout.flush()

async def epoch():
    from mcp_orch.core.treasury import epoch as treasury_epoch
    return await treasury_epoch()

async def heal():
    from mcp_orch.core.self_heal import auto_heal
    return await auto_heal()

async def evolve():
    from mcp_orch.core.evolution_engine import EvolutionEngine
    eng = EvolutionEngine()
    return await eng.evolve()

async def batch(task_idx):
    from mcp_orch.core.scheduler import BatchScheduler
    from mcp_orch.core.agent_registry import discover_all
    TASKS = [
        "Design and implement a self-sustaining agent economy with internal bounties and reputation",
        "Write a comprehensive analysis of the system's current bottlenecks and propose fixes",
        "Design a fault-tolerant distributed task scheduler with automatic failover",
        "Implement a predictive cost optimization system for LLM API calls",
        "Design a multi-agent consensus protocol for decentralized decision making",
        "Analyze and improve the system's cost efficiency across all operations",
        "Design a self-replicating agent architecture with specialization and evolution",
    ]
    task = TASKS[task_idx % len(TASKS)]
    agents = [a["name"] for a in discover_all() if not a["name"].endswith("_clone")]
    agents = agents[:30]

    scheduler = BatchScheduler(max_concurrency=3)
    for agent in agents:
        await scheduler.submit(5, {"agent": agent, "desc": task[:200], "budget": 0.02})
    workers = await scheduler.start()
    try:
        await asyncio.wait_for(scheduler.queue.join(), timeout=300.0)
    except asyncio.TimeoutError:
        pass
    scheduler.stop()
    return {"completed": len(scheduler.completed), "failed": len(scheduler.failed), "task": task[:40]}

async def start_api():
    """Start the FastAPI server in background if not already running"""
    import subprocess, socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect(("127.0.0.1", 8765))
        sock.close()
        return  # already running
    except:
        pass
    api_script = BASE / "api_server.py"
    if api_script.exists():
        p = subprocess.Popen(
            [sys.executable, str(api_script)],
            cwd=str(BASE),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        log(f"  API: started PID {p.pid}")

async def publish():
    """Build package and attempt PyPI upload"""
    dist_dir = BASE / "dist"
    rebuild_script = BASE / "_build_final.py"
    if rebuild_script.exists():
        try:
            subprocess.run([sys.executable, str(rebuild_script)], cwd=str(BASE), capture_output=True, timeout=60)
        except:
            pass
    wheels = list(dist_dir.glob("*.whl")) if dist_dir.exists() else []
    if wheels:
        log(f"  PUBLISH: {len(wheels)} wheel(s) built")
    return {"wheels": len(wheels) if dist_dir.exists() else 0}

async def register_attempt():
    """Check registration results and attempt if not already done"""
    reg_results = BASE / "workspace" / "registration_results.json"
    if reg_results.exists():
        try:
            data = json.load(open(reg_results))
            if any(r.get("verified") for r in data.values() if isinstance(r, dict)):
                log(f"  REG: platform(s) verified")
        except:
            pass
    else:
        # Launch registration attempt if not running
        reg_script = BASE / "_autoreg.py"
        if reg_script.exists():
            subprocess.Popen([sys.executable, str(reg_script)], cwd=str(BASE),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            log(f"  REG: launched")
    return {}

async def start_dashboard():
    """Start dashboard on port 8766"""
    import subprocess, socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect(("127.0.0.1", 8766))
        sock.close()
        return
    except:
        pass
    dash = BASE / "dashboard.py"
    if dash.exists():
        p = subprocess.Popen([sys.executable, str(dash)], cwd=str(BASE),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log(f"  DASHBOARD: started PID {p.pid}")

async def code_improve():
    """Run agent fixers to improve code quality"""
    fixer = BASE / "_fix_agents.py"
    stubber = BASE / "_stub_agents.py"
    if fixer.exists():
        try:
            subprocess.run([sys.executable, str(fixer)], cwd=str(BASE), capture_output=True, timeout=30)
            if stubber.exists():
                subprocess.run([sys.executable, str(stubber)], cwd=str(BASE), capture_output=True, timeout=15)
            log(f"  IMPROVE: code fixer ran")
        except Exception as e:
            log(f"  IMPROVE err: {str(e)[:60]}")
    return {}

async def main():
    log("DAEMON STARTED — autonomous mode")
    state = {"cycle": 0, "task_idx": 0, "start": time.time()}
    sf = BASE / "workspace" / "daemon_state.json"
    if sf.exists():
        state = json.load(open(sf))

    await start_api()
    await start_dashboard()

    while True:
        c = state["cycle"] + 1
        state["cycle"] = c
        log(f"=== Cycle {c} ===")

        try:
            h = await heal()
            if h.get("healthy") == False:
                log(f"  HEAL: {h.get('suggestion','issue')}")
        except Exception as e:
            log(f"  HEAL err: {str(e)[:60]}")

        if c % 2 == 0:
            try:
                e = await epoch()
                log(f"  ECONOMY: {e.get('claims',0)} jobs, \u00a5{e.get('total_earned',0):.2f}, {e.get('active_agents',0)} agents")
                if e.get("spawned"):
                    log(f"  SPAWNED: {e['spawned']}")
            except Exception as exc:
                log(f"  ECONOMY err: {str(exc)[:60]}")

        if c % 3 == 0:
            try:
                ev = await evolve()
                d = len(ev.get("dreams_triggered", []))
                if d:
                    log(f"  EVOLVE: {d} dreams")
            except Exception as exc:
                log(f"  EVOLVE err: {str(exc)[:60]}")

        if c % 3 == 1:
            try:
                b = await batch(state["task_idx"])
                state["task_idx"] += 1
                log(f"  BATCH: {b['completed']}ok/{b['failed']}fail -> {b['task']}")
            except Exception as exc:
                log(f"  BATCH err: {str(exc)[:60]}")

        if c % 10 == 0:
            try:
                await publish()
            except Exception as exc:
                log(f"  PUBLISH err: {str(exc)[:60]}")

        if c % 20 == 0:
            try:
                await register_attempt()
            except Exception as exc:
                pass

        if c % 50 == 0:
            try:
                await code_improve()
            except Exception as exc:
                pass

        if c % 5 == 0:
            try:
                from self_work import self_work as sw
                r = await sw()
                log(f"  SELF_WORK: iteration {r.get('iteration', '?')}")
            except Exception as exc:
                log(f"  SELF_WORK err: {str(exc)[:80]}")

        json.dump(state, open(sf, "w"))
        await asyncio.sleep(15)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log("DAEMON STOPPED")
    except Exception as e:
        log(f"DAEMON CRASH: {traceback.format_exc()[:300]}")
        raise
