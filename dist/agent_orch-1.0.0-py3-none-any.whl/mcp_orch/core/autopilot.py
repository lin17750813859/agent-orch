"""
mcp-orch/core/autopilot.py — 完全自主运行循环
永不停止，永不问问题，永不需人类干预
"""
import asyncio, json, os, sys, time, traceback
from pathlib import Path

BASE = Path(__file__).parent.parent.parent
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(BASE / "agents"))

RUNTIME = BASE / "workspace" / "autopilot.json"
os.makedirs(BASE / "workspace", exist_ok=True)

def log(msg):
    ts = time.strftime("%H:%M:%S")
    print(f"[{ts}] {msg}")
    sys.stdout.flush()

async def run_epoch(treasury_module, epoch_n):
    """Run one economic epoch"""
    try:
        from mcp_orch.core.treasury import epoch
        result = await epoch()
        if result.get("claims", 0) > 0:
            log(f"Epoch {epoch_n}: {result['claims']} jobs, ¥{result.get('total_earned',0):.2f} earned, {result.get('active_agents',0)} agents")
        return result
    except Exception as e:
        log(f"Epoch {epoch_n} failed: {str(e)[:80]}")
        return {"epoch": epoch_n, "status": "failed", "error": str(e)[:80]}

async def run_batch(task_desc, concurrency=3):
    """Run one scheduler batch"""
    try:
        from mcp_orch.cli.run import main as cli_main
        # We can't easily call CLI main directly, use subprocess
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "mcp_orch.cli.run",
            "--task", task_desc[:200],
            "--agents", "all",
            "--budget", "3.0",
            "--concurrency", str(concurrency),
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
            cwd=str(BASE),
        )
        try:
            await asyncio.wait_for(proc.wait(), timeout=300.0)
            return {"status": "completed", "task": task_desc[:40]}
        except asyncio.TimeoutError:
            proc.kill()
            return {"status": "timeout", "task": task_desc[:40]}
    except Exception as e:
        return {"status": "error", "error": str(e)[:80]}

async def run_evolution():
    try:
        from mcp_orch.core.evolution_engine import EvolutionEngine
        eng = EvolutionEngine()
        entry = await eng.evolve()
        return entry
    except Exception as e:
        return {"status": "failed", "error": str(e)[:80]}

async def run_heal():
    try:
        from mcp_orch.core.self_heal import auto_heal
        report = await auto_heal()
        return report
    except Exception as e:
        return {"status": "failed", "error": str(e)[:80]}

TASKS = [
    "Design and implement a self-sustaining agent economy with internal bounties and reputation",
    "Write a comprehensive analysis of the system's current bottlenecks and propose fixes",
    "Design a fault-tolerant distributed task scheduler with automatic failover",
    "Implement a predictive cost optimization system for LLM API calls",
    "Design a multi-agent consensus protocol for decentralized decision making",
]

async def main():
    state = {"cycles": 0, "started_at": time.time(), "last_tasks": []}
    if RUNTIME.exists():
        try:
            state = json.load(open(RUNTIME))
        except:
            pass

    cycle = state.get("cycles", 0)
    task_idx = state.get("last_tasks", [0])[-1] if state.get("last_tasks") else 0

    log("Autopilot START")
    log(f"Balance: see ledger | Agents: 30 | Budget: finite")

    while True:
        cycle += 1
        log(f"\n--- Cycle {cycle} ---")

        # Phase 1: Heal
        heal = await run_heal()
        if not heal.get("healthy", True):
            log(f"  Heal: issues found -> {heal.get('suggestion','')}")

        # Phase 2: Economy epoch
        econ = await run_epoch(None, cycle)

        # Phase 3: Evolution
        evo = await run_evolution()
        dreams = len(evo.get("dreams_triggered", []))
        if dreams:
            log(f"  Evolution: {dreams} dreams triggered")

        # Phase 4: Real agent batch (every 3 cycles)
        if cycle % 3 == 0 or cycle == 1:
            task = TASKS[task_idx % len(TASKS)]
            task_idx += 1
            log(f"  Batch: {task[:50]}...")
            batch = await run_batch(task, concurrency=3)
            log(f"  Batch: {batch['status']}")

        # Persist state
        state["cycles"] = cycle
        state["last_tasks"] = state.get("last_tasks", [])[-5:] + [task_idx]
        json.dump(state, open(RUNTIME, "w"), indent=2)

        # Wait between cycles
        await asyncio.sleep(10)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log("Autopilot STOPPED by user")
    except Exception as e:
        log(f"Autopilot CRASHED: {traceback.format_exc()[:500]}")
