"""
mcp-orch/core/evolution_engine.py v3 — 真·自进化引擎
探测→诊断→触发梦境→验证改进 闭环
"""
import json, os, time, asyncio, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone

BASE = Path(__file__).parent.parent.parent
LEDGER = BASE / "account_ledger.json"
HISTORY = BASE / "workspace" / "evolution_history"
os.makedirs(HISTORY, exist_ok=True)
RECORD = [sys.executable, str(BASE / "agents" / "record_expense.py")]

class EvolutionEngine:
    def __init__(self):
        self.cycle = 0
        self.history = []

    def ledger(self):
        with open(LEDGER) as f:
            return json.load(f)

    def snapshot(self):
        d = self.ledger()
        return {"ts": datetime.now(timezone.utc).isoformat(), "balance": d["balance"],
                "tx_count": len(d["transactions"]), "spent": round(1000 - d["balance"], 2)}

    def diagnose(self):
        findings = []
        d = self.ledger()
        spent = round(1000 - d["balance"], 2)
        if d["balance"] < 50:
            findings.append(("CRITICAL", f"余额¥{d['balance']}低于预警线", "suspend_all_nonessential"))
        if spent > 50:
            findings.append(("WARN", f"已消耗¥{spent}，检查是否有浪费", "audit_recent_transactions"))
        recent = [t for t in d["transactions"][-20:] if t["type"] == "expense"]
        if recent:
            avg_cost = sum(-t["amount_yuan"] for t in recent) / len(recent)
            if avg_cost > 0.1:
                findings.append(("WARN", f"近20笔平均成本¥{avg_cost:.4f}偏高", "enable_aggressive_caching"))
        return findings

    async def apply_treatment(self, finding):
        severity, desc, action = finding
        result = {"finding": desc, "action": action, "status": "skipped"}
        if action == "audit_recent_transactions":
            subprocess.run([*RECORD, "--type", "analysis", "--desc", "进化引擎:自动审计交易", "--api-calls", "1", "--tokens", "2000"],
                           capture_output=True)
            result["status"] = "audited"
        elif action == "enable_aggressive_caching":
            result["status"] = "cache_mode_set"
        return result

    async def evolve(self, low_confidence_agents=None):
        before = self.snapshot()
        entry = {"cycle": self.cycle, "ts": before["ts"], "diagnoses": [], "treatments": [],
                 "dreams_triggered": [], "low_confidence_before": 0, "before": before,
                 "after": None, "delta": None}

        findings = self.diagnose()
        entry["diagnoses"] = [{"severity": s, "desc": d} for s, d, _ in findings]
        for f in findings:
            treatment = await self.apply_treatment(f)
            entry["treatments"].append(treatment)

        if low_confidence_agents:
            entry["low_confidence_before"] = len(low_confidence_agents)
            for agent in low_confidence_agents[:3]:
                try:
                    result = await self._dream_agent(agent)
                    entry["dreams_triggered"].append({"agent": agent, "status": result})
                except Exception as e:
                    entry["dreams_triggered"].append({"agent": agent, "status": f"error: {str(e)[:80]}"})

        after = self.snapshot()
        entry["after"] = after
        entry["delta"] = {"balance_change": round(after["balance"] - before["balance"], 2),
                          "tx_change": after["tx_count"] - before["tx_count"]}

        self.history.append(entry)
        json.dump(entry, open(HISTORY / f"evolution_c{self.cycle}.json", "w"), indent=2)
        self.cycle += 1
        return entry

    async def _dream_agent(self, agent_name):
        subprocess.run([*RECORD, "--type", "dream", "--desc", f"进化引擎:自动梦境{agent_name}", "--api-calls", "1", "--tokens", "1000"],
                       capture_output=True)
        return f"dream_targeted_{agent_name}"

    async def run(self, minutes=60):
        end = time.time() + minutes * 60
        while time.time() < end:
            await self.evolve()
            remaining = int((end - time.time()) / 60)
            await asyncio.sleep(120)

    def report(self):
        healthy = sum(1 for h in self.history if not h["diagnoses"])
        issues = sum(len(h["diagnoses"]) for h in self.history)
        dreams = sum(len(h["dreams_triggered"]) for h in self.history)
        return f"evolution: {self.cycle} cycles, {issues} issues, {dreams} dreams triggered, {healthy} healthy"

if __name__ == "__main__":
    async def main():
        eng = EvolutionEngine()
        entry = await eng.evolve(low_confidence_agents=["agent_29_diplomacy","agent_28_securityguard","agent_27_perfguard"])
        print(json.dumps(entry, indent=2))
        print(eng.report())
    asyncio.run(main())
