"""
mcp-orch/core/cost_controller.py — 预算追踪与熔断
实时检查账户余额，超限自动熔断
"""
import json, time
from pathlib import Path

BASE = Path(__file__).parent.parent.parent
LEDGER = BASE / "account_ledger.json"

class CostController:
    def __init__(self, warning_threshold=50.0, critical_threshold=10.0):
        self.warning = warning_threshold
        self.critical = critical_threshold
        self.total_spent_this_session = 0.0
        self.calls_this_session = 0
        self.tokens_this_session = 0
        self._start_balance = self._read_balance()
        self._start_time = time.time()

    def _read_balance(self):
        try:
            with open(LEDGER) as f:
                return json.load(f)["balance"]
        except:
            return 0.0

    def check(self, estimated_cost=0.02):
        balance = self._read_balance()
        remaining = balance - estimated_cost
        if remaining <= 0:
            return "FUSE_BLOWN", balance
        if remaining <= self.critical:
            return "CRITICAL", balance
        if remaining <= self.warning:
            return "WARNING", balance
        return "OK", balance

    def record(self, tokens, cost, calls=1):
        self.total_spent_this_session += cost
        self.tokens_this_session += tokens
        self.calls_this_session += calls

    def session_report(self):
        elapsed = time.time() - self._start_time
        balance = self._read_balance()
        spent = self._start_balance - balance
        return {
            "session_cost": round(self.total_spent_this_session, 4),
            "actual_delta": round(spent, 4),
            "balance": balance,
            "tokens_used": self.tokens_this_session,
            "api_calls": self.calls_this_session,
            "elapsed_s": round(elapsed, 1),
            "burn_rate_yuan_per_hour": round(spent / (elapsed/3600), 4) if elapsed > 0 else 0,
        }

    def fuse_status(self):
        status, balance = self.check()
        bar_len = 40
        used = self._start_balance - balance
        fill = int((used / self._start_balance) * bar_len) if self._start_balance > 0 else 0
        bar = "█" * min(fill, bar_len) + "░" * (bar_len - min(fill, bar_len))
        return f"[{bar}] ¥{used:.2f}/¥{self._start_balance:.2f} used | {status}"
