"""
mcp-orch/cli/run.py — 终端入口
用法: python -m mcp-orch.cli.run --task "分析30个Agent的成本分布" --agents "strategist,analyst,critic" --budget 5.0
"""
import argparse, asyncio, json, sys, time
from pathlib import Path

BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE.parent))

from mcp_orch.models.batch import BatchTask, AgentResult
from mcp_orch.core.scheduler import BatchScheduler

ALL_AGENTS = [
    "strategist","analyst","innovator","critic","executor",
    "philosopher","scientist","artist","coach","observer",
    "architect","mediator","ethicist","riskguard","memorycurator",
    "datascientist","qualityguard","useradvocate","techwriter",
    "domainexpert","negotiator","synthesizer","debugger",
    "strategistv2","patternminer","sysintegrator","perfguard",
    "securityguard","diplomacy","metascheduler"
]

LAYERS = {
    "strategy": ["strategist","strategistv2","philosopher","synthesizer","patternminer"],
    "analysis": ["analyst","critic","scientist","ethicist","riskguard","debugger","securityguard"],
    "execution": ["executor","architect","sysintegrator","perfguard","diplomacy"],
    "creative": ["innovator","artist","techwriter","useradvocate"],
    "monitor": ["coach","observer","memorycurator","datascientist","qualityguard","domainexpert"],
    "meta": ["metascheduler","mediator","negotiator"],
}

def resolve_agents(spec):
    if spec == "all":
        return ALL_AGENTS
    if spec in LAYERS:
        return LAYERS[spec]
    return [a.strip() for a in spec.split(",")]

async def main():
    parser = argparse.ArgumentParser(description="mcp-orch: 30-Agent批量调度框架")
    parser.add_argument("--task", required=True, help="任务描述")
    parser.add_argument("--agents", default="all", help="Agent列表/layer名/all")
    parser.add_argument("--budget", type=float, default=10.0, help="预算上限(¥)")
    parser.add_argument("--concurrency", type=int, default=3, help="最大并行数")
    parser.add_argument("--dry-run", action="store_true", help="只打印不执行")
    args = parser.parse_args()

    targets = resolve_agents(args.agents)
    print(f"\n  🚀 mcp-orch 启动 | 任务: {args.task}")
    print(f"  👥 Agent: {len(targets)}个 | 预算: ¥{args.budget} | 并发: {args.concurrency}")
    print(f"  {'='*48}")

    if args.dry_run:
        print("\n  📋 Dry-Run 模式 — 不执行")
        print(f"  目标Agent ({len(targets)}):")
        for a in targets:
            print(f"    - {a}")
        print(f"  预估成本: ¥{len(targets) * 0.02:.2f}")
        return

    from mcp_orch.core.agent_registry import discover_all
    registry = {a["name"]: a for a in discover_all()}

    scheduler = BatchScheduler(max_concurrency=args.concurrency)
    results = []

    def collect(r):
        results.append(r)
    scheduler.on_complete(collect)

    start = time.time()

    for agent in targets:
        await scheduler.submit(priority=5, task_data={
            "agent": agent,
            "desc": args.task[:200],
            "budget": args.budget / max(len(targets), 1),
        })

    workers = await scheduler.start()
    try:
        await asyncio.wait_for(scheduler.queue.join(), timeout=300.0)
    except asyncio.TimeoutError:
        remaining = scheduler.queue.qsize()
        print(f"\n  ⚠️ 全局超时 ({remaining}任务未完成)")
    scheduler.stop()

    elapsed = time.time() - start
    s = scheduler.status()

    print(f"\n  ✅ 批次完成 | 耗时: {elapsed:.1f}s")
    print(f"  成功: {s['completed']} | 失败: {s['failed']} | 消耗Tokens: {s['total_tokens']} | 成本: ¥{s['total_cost_yuan']:.4f}")
    print(f"  余额: ¥{s['balance']}")

    if results:
        print(f"\n  {'='*56}")
        print(f"  Agent 执行结果明细")
        print(f"  {'='*56}")
        print(f"  {'Agent':<20s} {'状态':<8s} {'置信度':<8s} {'质量':<6s} {'延迟':<8s} {'成本':<8s}")
        print(f"  {'-'*56}")
        for r in results:
            status_sym = "✅" if r.status == "success" else "❌"
            conf_raw = str(r.confidence) if r.confidence else "0"
            try:
                conf_val = float(conf_raw.split()[0])
            except ValueError:
                conf_val = 0
            conf = f"{conf_val:.0f}%"
            qual = (r.output[:8] if r.output else "?") if r.status == "success" else (r.error[:8] if r.error else "?")
            latency = f"{r.latency_ms:.0f}ms" if r.latency_ms < 1000 else f"{r.latency_ms/1000:.1f}s"
            cost = f"¥{r.cost_yuan:.4f}"
            display = registry.get(r.agent_name, {}).get("display_name", r.agent_name)
            print(f"  {display:<20s} {status_sym:<8s} {conf:<8s} {qual:<6s} {latency:<8s} {cost:<8s}")

        confs = []
        for r in results:
            if r.status == "success" and r.confidence:
                try:
                    confs.append(float(str(r.confidence).split()[0]))
                except ValueError:
                    pass
        avg_conf = sum(confs) / max(len(confs), 1)
        total_cost = sum(r.cost_yuan for r in results)
        print(f"  {'='*56}")
        print(f"  平均置信度: {avg_conf:.1f}% | 总成本: ¥{total_cost:.4f} | 耗时: {elapsed:.1f}s")
    print(f"  {'='*48}")

if __name__ == "__main__":
    asyncio.run(main())
