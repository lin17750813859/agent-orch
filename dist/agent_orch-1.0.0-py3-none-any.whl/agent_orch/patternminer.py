import pandas as pd
import numpy as np
from collections import defaultdict
from itertools import combinations
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import json
from typing import Dict, List, Tuple, Any, Set, Optional
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from mlxtend.frequent_patterns import apriori, association_rules
from mlxtend.preprocessing import TransactionEncoder
import warnings
warnings.filterwarnings('ignore')

class PatternMiner:
    def __init__(self, name: str = "PatternMiner"):
        self.name = name
        self.patterns = {}
        self.anomalies = []
        self.sequence_patterns = []
        self.confidence_threshold = 0.7
        self.support_threshold = 0.1
        self.anomaly_threshold = -0.5
        self.history = []
        
    def analyze_patterns(self, data: pd.DataFrame, metadata: Dict = None) -> Dict:
        """Main method to run pattern analysis"""
        results = {}
        
        # Frequent pattern mining
        frequent_patterns = self.mine_frequent_patterns(data)
        results['frequent_patterns'] = frequent_patterns
        
        # Sequence analysis
        sequence_patterns = self.analyze_sequences(data)
        results['sequence_patterns'] = sequence_patterns
        
        # Anomaly detection
        anomalies = self.detect_anomalies(data)
        results['anomalies'] = anomalies
        
        # Pattern visualization
        self.visualize_patterns(data, results)
        
        # Store results
        self.patterns = results
        self.history.append({
            'timestamp': datetime.now().isoformat(),
            'results': results,
            'metadata': metadata
        })
        
        return results
    
    def mine_frequent_patterns(self, data: pd.DataFrame) -> Dict:
        """Mine frequent patterns using Apriori algorithm"""
        results = {}
        
        # Prepare transacti