import json
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

class Domain(Enum):
    FINANCE = "finance"
    HEALTHCARE = "healthcare"
    EDUCATION = "education"
    ENGINEERING = "engineering"
    BUSINESS = "business"
    TECHNOLOGY = "technology"

@dataclass
class KnowledgeEntry:
    domain: Domain
    topic: str
    content: str
    confidence: float
    sources: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Rule:
    id: str
    domain: Domain
    conditions: List[str]
    conclusion: str
    confidence_threshold: float = 0.7
    enabled: bool = True

class DomainExpert:
    def __init__(self, name: str, initial_domains: List[Domain]):
        self.name = name
        self.domains = set(initial_domains)
        self.knowledge_base: List[KnowledgeEntry] = []
        self.rules: List[Rule] = []
        self.inference_history: List[Dict[str, Any]] = []
        self.logger = logging.getLogger(f"{__name__}.{name}")
        
    def add_domain(self, domain: Domain) -> bool:
        if domain not in self.domains:
            self.domains.add(domain)
            return True
        return False
    
    def remove_domain(self, domain: Domain) -> bool:
        if domain in self.domains:
            self.domains.remove(domain)
            # Remove domain-specific rules
            self.rules = [rule for rule in self.rules if rule.domain != domain]
            # Remove domain-specific knowledge
            self.knowledge_base = [entry for entry in self.knowledge_base if entry.domain != domain]
            return True
        return False
    
    def add_knowledge(self, entry: KnowledgeEntry) -> bool:
        if entry.domain not in self.domains:
            self.logger.warning(f"Cannot add knowledge for domain {entry.domain} not in expert's domains")
            return False
        
        # Check for duplica