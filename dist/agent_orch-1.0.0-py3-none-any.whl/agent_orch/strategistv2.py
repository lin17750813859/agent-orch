import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
import copy

class RiskProfile(Enum):
    CONSERVATIVE = 1
    MODERATE = 2
    AGGRESSIVE = 3

@dataclass
class StrategyOption:
    name: str
    description: str
    estimated_outcomes: Dict[str, float]
    resource_requirements: Dict[str, float]
    risk_level: RiskProfile
    probability_of_success: float
    dependencies: List[str]

class AdvancedStrategy:
    def __init__(self, name: str, objectives: List[str]):
        """
        Initialize the AdvancedStrategy system with objectives.
        
        Args:
            name: Name of the strategy
            objectives: List of strategic objectives to optimize for
        """
        self.name = name
        self.objectives = objectives
        self.strategy_options: List[StrategyOption] = []
        self.decision_matrix = None
        self.weights = {}
        self.risk_adjustment_factor = 1.0
        
    def add_strategy_option(self, option: StrategyOption):
        """Add a strategy option to the analysis."""
        self.strategy_options.append(option)
        
    def set_objective_weights(self, weights: Dict[str, float]):
        """
        Set weights for different objectives.
        
        Args:
            weights: Dictionary mapping objectives to their weights (0-1)
        """
        total = sum(weights.values())
        self.weights = {k: v/total for k, v in weights.items()}
        
    def calculate_utility_scores(self) -> np.ndarray:
        """
        Calculate utility scores for each strategy option based on objectives.
        
        Returns:
            NumPy array of utility scores
        """
        if not self.strategy_options or not self.weights:
            raise ValueError("Strategy options and objective weights must be set first")
            
        num_options = len(self.strategy_options)
        num_objectives = len(self.objectives)