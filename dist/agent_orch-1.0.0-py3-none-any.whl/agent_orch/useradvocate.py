import json
import logging
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from enum import Enum
import uuid
from datetime import datetime

class FeedbackType(Enum):
    FUNCTIONAL = "functional"
    USABILITY = "usability"
    AESTHETIC = "aesthetic"
    PERFORMANCE = "performance"
    CONTENT = "content"

@dataclass
class UserFeedback:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    type: FeedbackType = None
    rating: int = 0  # 1-5 scale
    comment: str = ""
    suggestion: str = ""
    user_context: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

class UserProxy:
    def __init__(self, name: str = "UserProxy", user_id: Optional[str] = None):
        self.name = name
        self.user_id = user_id or str(uuid.uuid4())
        self.logger = logging.getLogger(f"{__name__}.{name}")
        self.preferences = {}
        self.feedback_history: List[UserFeedback] = []
        self.ui_hooks: Dict[str, Callable] = {}
        self.validators: Dict[str, Callable] = {}
        self._initialize_default_validators()
        
    def _initialize_default_validators(self):
        """Initialize default input validators"""
        self.validators["numeric"] = lambda x: isinstance(x, (int, float))
        self.validators["string"] = lambda x: isinstance(x, str)
        self.validators["boolean"] = lambda x: isinstance(x, bool)
        self.validators["list"] = lambda x: isinstance(x, list)
        self.validators["dict"] = lambda x: isinstance(x, dict)
    
    def register_validator(self, name: str, validator: Callable[[Any], bool]):
        """Register a custom input validator"""
        self.validators[name] = validator
        self.logger.info(f"Registered validator: {name}")
    
    def validate_input(self, value: Any, validator_name: str) -> bool:
        """Validate input again
"""