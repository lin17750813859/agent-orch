"""
webhook_receiver.py - Single file FastAPI webhook receiver for GitHub/GitLab
Accepts webhooks and triggers agent tasks via subprocess or API calls.
"""

import os
import json
import hmac
import hashlib
import logging
import subprocess
from typing import Optional, Dict, Any
from datetime import datetime

from fastapi import FastAPI, Request, HTTPException, Header, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

# Configuration
CONFIG = {
    "github_secret": os.environ.get("GITHUB_WEBHOOK_SECRET", ""),
    "gitlab_secret": os.environ.get("GITLAB_WEBHOOK_SECRET", ""),
    "agent_command": os.environ.get("AGENT_COMMAND", "echo"),
    "agent_args": os.environ.get("AGENT_ARGS", ""),
    "log_file": os.environ.get("WEBHOOK_LOG_FILE", "webhook_receiver.log"),
    "host": os.environ.get("WEBHOOK_HOST", "0.0.0.0"),
    "port": int(os.environ.get("WEBHOOK_PORT", "8000")),
}

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(CONFIG["log_file"]),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("webhook_receiver")

app = FastAPI(
    title="Webhook Receiver",
    description="Accepts GitHub/GitLab webhooks and triggers agent tasks",
    version="1.0.0"
)

# In-memory event store (for demo purposes)
events_store: list = []


class WebhookEvent(BaseModel):
    """Model for storing webhook events"""
    id: str
    source: str  # github or gitlab
    event_type: str
    payload: Dict[str, Any]
    received_at: datetime = Field(default_factory=datetime.utcnow)
    processed: bool = False
    result: Optional[str] = None


def verify_github_signature(payload_body: bytes, signature_header: str) -> bool:
    """Verify GitHub webhook signature"""
    if not CONFIG["github_secret"]:
        logger.warning("GitHub secret not configured, skipping signature verification")
        ret