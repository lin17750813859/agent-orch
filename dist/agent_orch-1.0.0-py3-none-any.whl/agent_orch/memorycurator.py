import json
import numpy as np
from collections import deque, defaultdict
from datetime import datetime, timedelta
import uuid
from typing import List, Dict, Any, Tuple, Optional, Set

class MemoryManager:
    """
    Manages short-term and long-term memory storage, retrieval, forgetting, and consolidation.
    """
    
    def __init__(self, max_short_term_size: int = 1000, 
                 max_long_term_size: int = 10000,
                 short_term_decay_rate: float = 0.1,
                 long_term_threshold: float = 0.7,
                 consolidation_interval: int = 100):
        """
        Initialize the MemoryManager.
        
        Args:
            max_short_term_size: Maximum number of memories in short-term storage
            max_long_term_size: Maximum number of memories in long-term storage
            short_term_decay_rate: Rate at which short-term memories decay
            long_term_threshold: Activation threshold for long-term consolidation
            consolidation_interval: Number of operations between consolidation checks
        """
        self.short_term_memory = deque(maxlen=max_short_term_size)
        self.long_term_memory = deque(maxlen=max_long_term_size)
        self.short_term_decay_rate = short_term_decay_rate
        self.long_term_threshold = long_term_threshold
        self.consolidation_counter = 0
        self.consolidation_interval = consolidation_interval
        
        # Memory metadata for tracking
        self.memory_metadata = {}
        self.memory_index = defaultdict(list)
        self.access_counter = defaultdict(int)
        
        # Forgetting parameters
        self.forgetting_threshold = 0.1
        self.recency_weight = 0.5
        self.frequency_weight = 0.3
        self.relevance_weight = 0.2
        
    def add_memory(self, content: Dict[str, Any], memory_type: str = "short_term", 
                   tags: Optional[Set[str]] = None, relevance: float = 1.0) -> str:
        """
        Add a mem
"""