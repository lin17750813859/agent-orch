import json
import time
from datetime import datetime
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, asdict
from collections import defaultdict, deque
import threading
import logging

@dataclass
class AgentMetrics:
    agent_id: str
    last_active: float
    message_count: int
    error_count: int
    response_times: List[float]
    topics_discussed: Set[str]
    confidence_scores: List[float]

@dataclass
class SystemEvent:
    timestamp: float
    event_type: str
    source_agent: str
    data: Dict[str, Any]
    severity: int  # 1-10 scale

@dataclass
class SystemState:
    timestamp: float
    active_agents: Set[str]
    total_messages: int
    error_rate: float
    dominant_topics: List[str]
    agent_confidence_avg: float
    system_health: float  # 0-1 scale

@dataclass
class PatternAlert:
    pattern_id: str
    description: str
    confidence: float
    timestamp: float
    affected_agents: List[str]
    recommended_action: str
    severity: int  # 1-10 scale

class SystemObserver:
    def __init__(self, max_history_size: int = 1000, alert_threshold: float = 0.7):
        self.metrics: Dict[str, AgentMetrics] = {}
        self.events: deque = deque(maxlen=max_history_size)
        self.state_history: deque = deque(maxlen=max_history_size)
        self.patterns: Dict[str, int] = defaultdict(int)  # pattern_id -> count
        self.alerts: List[PatternAlert] = []
        self.alert_threshold = alert_threshold
        self.lock = threading.Lock()
        self.logger = logging.getLogger(__name__)
        
        # Initialize system state
        self._update_system_state()
        
    def record_agent_message(self, agent_id: str, message: Dict[str, Any], 
                           response_time: float = None):
        with self.lock:
            # Initialize metrics if agent is new
            if agent_id not in self.metrics:
                self.metrics[agent_id] = AgentMetrics(
                    agent_id=ag
)