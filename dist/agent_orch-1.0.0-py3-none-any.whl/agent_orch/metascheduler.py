import heapq
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

class TaskPriority(Enum):
    CRITICAL = 4
    HIGH = 3
    MEDIUM = 2
    LOW = 1
    BACKGROUND = 0

@dataclass(order=True)
class Task:
    id: str
    name: str
    priority: TaskPriority
    estimated_duration: int  # in seconds
    deadline: Optional[datetime] = None
    assigned_agent: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    dependencies: List[str] = field(default_factory=list)
    completed: bool = False
    progress: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass(order=True)
class Agent:
    id: str
    name: str
    capacity: float = 1.0  # 1.0 = full capacity, 0.0 = busy
    current_tasks: List[str] = field(default_factory=list)
    specialization: List[str] = field(default_factory=list)
    last_heartbeat: datetime = field(default_factory=datetime.now)
    status: str = "active"
    efficiency_score: float = 1.0  # 0.0 to 1.0

class MetaScheduler:
    def __init__(self, max_agents: int = 10):
        self.tasks: Dict[str, Task] = {}
        self.agents: Dict[str, Agent] = {}
        self.task_queue: List[Task] = []
        self.lock = threading.Lock()
        self.logger = logging.getLogger("MetaScheduler")
        self.max_agents = max_agents
        self.agent_load_threshold = 0.8
        self.load_balancing_interval = 30  # seconds
        self.deadline_warning_buffer = 3600  # 1 hour in seconds
        self.running = False
        self.scheduler_thread = None
        self.load_balancer_thread = None
        
    def start(self):
        """Start the scheduler and its background threads"""
        self.running = True
        self.scheduler_thread = threading.Thread(target=self._schedule_tasks)
        self.load_balancer_thread = threading.Thread(targ
)