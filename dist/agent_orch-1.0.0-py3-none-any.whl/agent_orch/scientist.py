import numpy as np
from scipy import stats
from typing import Dict, List, Tuple, Optional, Union
import pandas as pd
from dataclasses import dataclass

@dataclass
class ExperimentResult:
    """Data class to store experiment results"""
    p_value: float
    statistically_significant: bool
    effect_size: float
    confidence_interval: Tuple[float, float]
    sample_size: int
    statistical_power: float = 0.0
    significance_level: float = 0.05

class Experiment:
    """
    A/B testing and hypothesis testing framework
    """
    
    def __init__(self, significance_level: float = 0.05, min_sample_size: int = 30):
        """
        Initialize the experiment
        
        Args:
            significance_level: Alpha level for statistical significance (default: 0.05)
            min_sample_size: Minimum sample size for valid experiment (default: 30)
        """
        self.significance_level = significance_level
        self.min_sample_size = min_sample_size
        self.results: Dict[str, ExperimentResult] = {}
        self.hypothesis = None
        self.alternative_hypothesis = None
        self.null_hypothesis = None
        
    def set_hypothesis(self, null_hypothesis: str, alternative_hypothesis: str):
        """
        Set the null and alternative hypotheses for the experiment
        
        Args:
            null_hypothesis: Statement to be tested (typically no effect)
            alternative_hypothesis: Alternative to be accepted if null is rejected
        """
        self.null_hypothesis = null_hypothesis
        self.alternative_hypothesis = alternative_hypothesis
        
    def calculate_sample_size(self, effect_size: float, power: float = 0.8, 
                           std_dev: float = 1.0) -> int:
        """
        Calculate required sample size for desired power and effect size
        
        Args:
            effect_size: Minimum effect size to detect
            power: Desired statistical power (default: 0.8)
"""