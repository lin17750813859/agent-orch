"""agent_orch — Multi-Agent Orchestration Framework"""
__version__ = "1.0.0"

# Agent modules (30 agents)
from .agent_cli import Agent

# Core framework
from .core.agent_registry import discover_all, get_cognitive_architecture, registry_report
from .core.scheduler import BatchScheduler
from .core.treasury import epoch as treasury_epoch
from .core.evolution_engine import EvolutionEngine
from .core.circuit_breaker import CircuitBreaker
from .core.self_heal import auto_heal
