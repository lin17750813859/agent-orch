import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

class EthicalPrinciple(Enum):
    AUTONOMY = "autonomy"
    BENEFICENCE = "beneficence"
    NON_MALEFICENCE = "non_maleficence"
    JUSTICE = "justice"
    TRANSPARENCY = "transparency"
    ACCOUNTABILITY = "accountability"
    PRIVACY = "privacy"
    FAIRNESS = "fairness"

@dataclass
class EthicalDilemma:
    description: str
    affected_parties: List[str]
    options: List[str]
    potential_harms: List[str]
    potential_benefits: List[str]

@dataclass
class EthicalAssessment:
    principle_scores: Dict[EthicalPrinciple, float]
    overall_risk: float
    recommendation: str
    justification: str
    confidence: float

class EthicalAdvisor:
    def __init__(self):
        self.principles_weights = {
            EthicalPrinciple.AUTONOMY: 0.15,
            EthicalPrinciple.BENEFICENCE: 0.15,
            EthicalPrinciple.NON_MALEFICENCE: 0.20,
            EthicalPrinciple.JUSTICE: 0.15,
            EthicalPrinciple.TRANSPARENCY: 0.10,
            EthicalPrinciple.ACCOUNTABILITY: 0.10,
            EthicalPrinciple.PRIVACY: 0.10,
            EthicalPrinciple.FAIRNESS: 0.05
        }
        self.risk_threshold = 0.7
        self.confidence_threshold = 0.6
        
    def evaluate_principle(self, principle: EthicalPrinciple, context: Dict) -> float:
        """Evaluate how well a specific principle is upheld in the given context."""
        if principle == EthicalPrinciple.AUTONOMY:
            return self._evaluate_autonomy(context)
        elif principle == EthicalPrinciple.BENEFICENCE:
            return self._evaluate_beneficence(context)
        elif principle == EthicalPrinciple.NON_MALEFICENCE:
            return self._evaluate_non_maleficence(context)
        elif principle == EthicalPrinciple.JUSTICE:
            return self._evaluate_justice(context)
        elif principle == EthicalPrinciple.TRANSPARENCY:
            return self._