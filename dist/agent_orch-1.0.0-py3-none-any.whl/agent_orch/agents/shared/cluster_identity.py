"""
ClusterIdentity — 集群自我边界分析: 全局集群 / 单 Agent / 会话缓存 三层边界
v1.0: 读取全量历史, 生成演化叙事 + 边界定义
"""
import json, time, math
from pathlib import Path
from .sqlite_store import assessment_get_all
from .global_workspace import GlobalWorkspace as GW

BASE = Path(__file__).parent.parent
DIM_KEYS = ["architecture", "reasoning_quality", "memory_efficiency", "evolution_capability"]


class ClusterIdentity:
    """
    集群自我认知 — 三层边界分析:
    L1 全局集群 (30-Agent 整体系统)
    L2 单 Agent (独立 persona/行为)
    L3 会话缓存 (临时状态)
    """

    @staticmethod
    def analyze_boundaries() -> dict:
        """
        分析三层边界, 返回每层的描述与统计
        """
        records = assessment_get_all()

        # L1: Global cluster
        agent_list = sorted(BASE.glob("agents/agent_*"))
        configured_agents = [d.name for d in agent_list if (d / "config.json").exists() and d.name != "agent_0001"]
        cycle_ids = sorted(set(r.get("type", "") for r in records if r.get("type", "").startswith("cycle_")))
        dim_latest = {}
        for d in DIM_KEYS:
            vals = []
            for r in reversed(records):
                data = r.get("data", {})
                after = data.get("after", {})
                dims = after.get("dimension_scores", {})
                v = dims.get(d)
                if isinstance(v, (int, float)) and v > 0:
                    vals.append(v)
                    if len(vals) >= 3:
                        break
            if vals:
                dim_latest[d] = {"recent_3": vals, "mean": round(sum(vals) / len(vals), 1)}

        l1 = {
            "layer": "L1_global_cluster",
            "description": f"30 Agent 自治系统 — {len(configured_agents)}活跃Agent, {len(cycle_ids)}已完成循环",
            "agent_count": len(configured_agents),
            "cycle_count": len(cycle_ids),
            "cycle_ids": cycle_ids[-10:],
            "recent_dimension_scores": dim_latest,
            "record_count": len(records),
        }

        # L2: Single agents — analyze per-agent behavior from agent_scores
        agent_histories: dict[str, dict] = {}
        for r in records:
            data = r.get("data", {})
            agent_scores = data.get("agent_scores", [])
            if not agent_scores:
                agent_scores = data.get("agent_scores_raw", [])
            if not agent_scores:
                continue
            for ascore in agent_scores:
                if not isinstance(ascore, dict):
                    continue
                aname = ascore.get("agent", "")
                if not aname:
                    continue
                if aname not in agent_histories:
                    agent_histories[aname] = {d: [] for d in DIM_KEYS}
                for d in DIM_KEYS:
                    v = ascore.get(d)
                    if isinstance(v, (int, float)) and 10 <= v <= 100:
                        agent_histories[aname][d].append(v)

        # Compute per-agent behavior statistics
        agent_stats = {}
        for aname, dimscores in agent_histories.items():
            stats = {}
            for d in DIM_KEYS:
                vals = dimscores[d]
                if len(vals) >= 2:
                    mean_v = sum(vals) / len(vals)
                    var = sum((v - mean_v)**2 for v in vals) / len(vals)
                    stats[d] = {
                        "count": len(vals),
                        "mean": round(mean_v, 1),
                        "stddev": round(math.sqrt(var), 2),
                        "min": round(min(vals), 1),
                        "max": round(max(vals), 1),
                        "recent": round(vals[-1], 1) if vals else 0,
                    }
                elif len(vals) == 1:
                    stats[d] = {"count": 1, "mean": round(vals[0], 1), "stddev": 0}
                else:
                    stats[d] = {"count": 0}
            agent_stats[aname] = stats

        # Identify most/least consistent agents
        agent_volatility = {}
        for aname, stats in agent_stats.items():
            vols = []
            for d in DIM_KEYS:
                sd = stats.get(d, {}).get("stddev", 0)
                if sd > 0:
                    vols.append(sd)
            agent_volatility[aname] = round(sum(vols) / max(1, len(vols)), 2) if vols else 0

        sorted_by_volatility = sorted(agent_volatility.items(), key=lambda x: x[1])
        most_consistent = [a for a, v in sorted_by_volatility[:5] if v > 0] if sorted_by_volatility else []
        most_volatile = [a for a, v in sorted_by_volatility[-5:] if v > 0] if sorted_by_volatility else []

        l2 = {
            "layer": "L2_single_agent",
            "description": f"{len(agent_stats)} Agent 个体行为分析",
            "agent_count": len(agent_stats),
            "agent_stats": agent_stats,
            "most_consistent_agents": most_consistent,
            "most_volatile_agents": most_volatile,
            "volatility_scores": agent_volatility,
        }

        # L3: Session cache (transient broadcasts, shared knowledge, queue)
        try:
            broadcasts = GW.read_broadcasts(limit=50)
            shared = GW.get_shared_knowledge(topic="", limit=50)
            broadcast_agents = set(b.get("agent", "") for b in broadcasts if isinstance(b, dict))
        except Exception:
            broadcasts = []
            shared = []
            broadcast_agents = set()

        l3 = {
            "layer": "L3_session_cache",
            "description": f"临时会话缓存 — {len(broadcasts)}广播 {len(shared)}共享知识",
            "broadcast_count": len(broadcasts),
            "shared_knowledge_count": len(shared),
            "broadcast_agents": list(broadcast_agents)[:20],
            "last_broadcast_time": broadcasts[-1].get("timestamp", 0) if broadcasts else 0,
        }

        return {
            "layers": [l1, l2, l3],
            "generated_at": time.time(),
        }

    @staticmethod
    def generate_narrative() -> dict:
        """
        生成完整演化历史叙事
        Returns: {title, chapters: [{title, period, events, metrics}, ...], summary}
        """
        records = assessment_get_all()
        boundaries = ClusterIdentity.analyze_boundaries()

        if not records:
            return {"error": "no records", "chapters": [], "summary": "集群尚未启动"}

        # Chronological chapters based on record type
        chapters = []
        seen_types = set()
        cycle_runs = [r for r in records if r.get("type", "").startswith(("r", "cycle"))]
        chapters.append({
            "title": "起源与初始化",
            "period": "R0-R3",
            "events": [
                "30 Agent 集群启动",
                "W1-W5 工作区搭建",
                "元认知循环协议建立",
            ],
            "metrics": {},
        })

        # R4-R7 mechanics
        r4_r7 = [r for r in records if r.get("type", "").startswith(("r4", "r5", "r6", "r7", "cycle")) and
                 "r8" not in r.get("type", "").lower()]
        if r4_r7:
            chapters.append({
                "title": "自治机制构建",
                "period": "R4-R7",
                "events": [
                    "元共识投票系统上线",
                    "心跳自愈 + 4级预算节流",
                    "MetaLearner 自主诊断推优",
                    "AutonomousDaemon 60s 常驻轮询",
                ],
                "metrics": {
                    "cycle_count": len(r4_r7),
                },
            })

        # R8 meta-meta learning
        r8_records = [r for r in records if "r8" in r.get("type", "").lower()]
        if r8_records:
            chapters.append({
                "title": "元元自省觉醒",
                "period": "R8",
                "events": [
                    f"{len(r8_records)}次元元校准循环",
                    "方差分析→提示词自主校准",
                    "批量离群值抑制(MAD截断)",
                    "自省能力上线: 系统可以审视自身输出偏差",
                ],
                "metrics": {
                    "calibration_rounds": len(r8_records),
                },
            })

        # R9+
        chapters.append({
            "title": "永续自治与长期记忆",
            "period": "R9+",
            "events": [
                "长期演化趋势监控上线",
                "集群自我边界定义",
                "预算耗尽可能处置协议",
                "向完全永续自治前进",
            ],
            "metrics": {},
        })

        # Summary
        l1 = boundaries.get("layers", [{}])[0]
        l2 = boundaries.get("layers", [{}])[1] if len(boundaries.get("layers", [])) > 1 else {}
        summary = (
            f"30-Agent 自治集群, {l1.get('cycle_count', 0)}次评估循环, "
            f"{l2.get('agent_count', 0)}个活跃Agent个体纳入长期行为追踪. "
            f"已完成R0→R9完整自省演化生命周期构建."
        )

        return {
            "title": "30-Agent 自治集群演化史",
            "chapters": chapters,
            "summary": summary,
            "generated_at": time.time(),
        }
