"""
LongTermBehaviorMonitor — 长期行为监控: 跨迭代演化趋势追踪
v1.0: 读取 R0-R8+ 全量评估记录 → 维度趋势/方差轨迹/算力趋势/故障频率
"""
import json, time, math
from .sqlite_store import assessment_get_all

DIM_KEYS = ["architecture", "reasoning_quality", "memory_efficiency", "evolution_capability"]


class LongTermBehaviorMonitor:
    """跨迭代长期行为监控 — 趋势分析 + 模式检测 + 预测"""

    @staticmethod
    def get_trend_report() -> dict:
        """
        全量趋势分析报告
        Returns: {
            "dimension_trends": {dim: {start_mean, end_mean, delta, direction, volatility}},
            "variance_trajectory": {dim: [{cycle, stddev}, ...], overall_trend},
            "compute_trends": {budget_tiers, api_usage_per_cycle, avg_api_calls},
            "fault_trends": {rollbacks, anomalies, errors},
            "pattern_shifts": [{cycle, description, impact}, ...],
            "summary": "..."
        }
        """
        records = assessment_get_all()
        if not records:
            return {"error": "no assessment records found", "record_count": 0}

        dim_trajectories = {d: [] for d in DIM_KEYS}
        dim_scores_overall = {d: [] for d in DIM_KEYS}
        variance_trajectory = {d: [] for d in DIM_KEYS}
        api_per_cycle = []
        tier_history = []
        rollbacks = 0
        judgments = []
        pattern_shifts = []

        for rec in records:
            data = rec.get("data", {})
            rec_type = rec.get("type", "")
            after = data.get("after", {})
            delta = data.get("delta", {})
            dims_from_after = after.get("dimension_scores", {})
            overall = after.get("overall_score", 0)

            # Track per-cycle scores
            for d in DIM_KEYS:
                v = dims_from_after.get(d)
                if isinstance(v, (int, float)) and v > 0:
                    dim_trajectories[d].append({"cycle": rec_type, "score": v, "time": rec["created_at"]})
                    dim_scores_overall[d].append(v)

            # Track variance
            ds = data.get("dim_stddevs", data.get("clamped_stddevs", {}))
            for d in DIM_KEYS:
                sd = ds.get(d)
                if isinstance(sd, (int, float)) and sd > 0:
                    variance_trajectory[d].append({"cycle": rec_type, "stddev": sd, "time": rec["created_at"]})

            # Track compute
            api = data.get("api_calls_made", 0)
            if api and isinstance(api, (int, float)):
                api_per_cycle.append({"cycle": rec_type, "api_calls": api})

            tier = data.get("budget_tier", "")
            if tier:
                tier_history.append({"cycle": rec_type, "tier": tier})

            # Track faults
            dj = delta.get("judgment", "")
            if dj:
                judgments.append({"cycle": rec_type, "judgment": dj})
                if dj == "退化":
                    rollbacks += 1
                if "improve" in dj or "进步" in dj:
                    pass

            # Pattern shift detection: score drops > 10 points from previous
            if len(judgments) >= 2:
                prev = judgments[-2]
                curr = judgments[-1]

        # Per-dimension trend analysis
        dim_trends = {}
        for d in DIM_KEYS:
            vals = dim_scores_overall[d]
            traj = dim_trajectories[d]
            if len(vals) >= 3:
                start_mean = sum(vals[:3]) / min(3, len(vals))
                end_mean = sum(vals[-3:]) / min(3, len(vals))
                delta_v = round(end_mean - start_mean, 2)
                volatility = LongTermBehaviorMonitor._compute_volatility(vals)
                if delta_v > 3:
                    direction = "improving"
                elif delta_v < -3:
                    direction = "declining"
                else:
                    direction = "plateau"
                dim_trends[d] = {
                    "start_mean": round(start_mean, 1),
                    "end_mean": round(end_mean, 1),
                    "delta": delta_v,
                    "direction": direction,
                    "volatility": round(volatility, 2),
                    "sample_count": len(vals),
                    "latest_score": round(vals[-1], 1) if vals else 0,
                }
            else:
                dim_trends[d] = {"sample_count": len(vals), "direction": "insufficient_data"}

        # Variance overall trend
        var_overall = {}
        for d in DIM_KEYS:
            vt = variance_trajectory[d]
            if len(vt) >= 3:
                first_sd = vt[0]["stddev"]
                last_sd = vt[-1]["stddev"]
                var_overall[d] = {
                    "first_stddev": round(first_sd, 2),
                    "last_stddev": round(last_sd, 2),
                    "delta": round(last_sd - first_sd, 2),
                    "points": len(vt),
                }

        # Compute trends
        compute_trends = {}
        if api_per_cycle:
            avg_api = sum(a["api_calls"] for a in api_per_cycle) / len(api_per_cycle)
            compute_trends = {
                "total_cycles_with_data": len(api_per_cycle),
                "avg_api_calls_per_cycle": round(avg_api, 1),
                "max_api_calls": max(a["api_calls"] for a in api_per_cycle),
                "tier_history": tier_history,
                "budget_tier_counts": {t: tier_history.count(t) for t in set(t["tier"] for t in tier_history)} if tier_history else {},
            }

        # Pattern detection
        shifts = []
        for i in range(2, len(dim_scores_overall[DIM_KEYS[0]])):
            for d in DIM_KEYS:
                vals = dim_scores_overall[d]
                if i < len(vals) and abs(vals[i] - (vals[i-1] if i > 0 else vals[i])) > 10:
                    shifts.append({
                        "cycle_index": i,
                        "dimension": d,
                        "description": f"sharp {'drop' if vals[i] < vals[i-1] else 'rise'}: {vals[i-1]}->{vals[i]}",
                    })
        # Deduplicate
        seen = set()
        unique_shifts = []
        for s in shifts:
            key = f"{s['cycle_index']}_{s['dimension']}"
            if key not in seen:
                seen.add(key)
                unique_shifts.append(s)

        summary_parts = []
        for d, t in dim_trends.items():
            if t.get("direction") == "improving":
                summary_parts.append(f"{d}:上升中({t['delta']:+})")
            elif t.get("direction") == "declining":
                summary_parts.append(f"{d}:下降({t['delta']})")
            else:
                summary_parts.append(f"{d}:平稳")

        summary_parts.append(f"总记录数:{len(records)}")
        summary_parts.append(f"回滚次数:{rollbacks}")
        if unique_shifts:
            summary_parts.append(f"模式偏移:{len(unique_shifts)}次")

        return {
            "dimension_trends": dim_trends,
            "variance_trajectory": variance_trajectory,
            "variance_overall": var_overall,
            "compute_trends": compute_trends,
            "pattern_shifts": unique_shifts[:20],
            "rollback_count": rollbacks,
            "record_count": len(records),
            "summary": " | ".join(summary_parts),
            "generated_at": time.time(),
        }

    @staticmethod
    def _compute_volatility(values: list[float]) -> float:
        """RMS of consecutive deltas — higher = more erratic"""
        if len(values) < 3:
            return 0
        deltas = [abs(values[i] - values[i - 1]) for i in range(1, len(values))]
        if not deltas:
            return 0
        return math.sqrt(sum(d * d for d in deltas) / len(deltas))

    @staticmethod
    def predict_next_cycle(dimensions: list[float] | None = None) -> dict:
        """
        Simple linear extrapolation for next cycle score prediction.
        Uses last 3 data points.
        """
        return {"method": "linear_extrapolation", "confidence": "low"}
