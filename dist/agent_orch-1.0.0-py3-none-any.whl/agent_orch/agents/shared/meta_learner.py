"""
MetaLearner — 元学习层: 自主归纳迭代规律, 脱离人工预设生成优化策略
v1.0: R0-R4 全周期数据分析 → 趋势归纳 → 自主优先级排定
"""
import json, time, re
from pathlib import Path

from .sqlite_store import *
from .heartbeat import get_heartbeat


class MetaLearner:
    """元学习器 — 读取全周期数据, 自主归纳规律, 生成优化优先级"""

    # 四个标准维度
    DIMENSIONS = ["architecture", "reasoning_quality", "memory_efficiency", "evolution_capability"]

    # 策略分类 (仅作基础聚类, 不预设优先级)
    STRATEGY_CATEGORIES = {
        "infra":     ["architecture", "架构", "存储", "database", "缓存", "cache", "并发", "并行"],
        "reasoning": ["reasoning", "推理", "逻辑", "分析", "评估", "judgment", "校准"],
        "memory":    ["memory", "记忆", "knowledge", "知识", "召回", "recall", "索引", "倒排"],
        "evolution": ["evolution", "演进", "进化", "自学", "self", "元认知", "meta", "反思"],
        "fault":     ["fault", "故障", "容错", "自愈", "heal", "heartbeat", "断路器", "breaker"],
        "consensus": ["consensus", "投票", "vote", "共识", "分歧", "协商", "合作"],
    }

    @staticmethod
    def analyze_all() -> dict:
        """全量分析管线: 数据采集 → 趋势 → 策略 → 故障 → 优先级 → 计划"""
        data = MetaLearner._collect_data()
        trends = MetaLearner._analyze_trends(data["assessments"])
        strategies = MetaLearner._assess_strategies(data["knowledge"], trends)
        fault_profile = MetaLearner._analyze_faults(data["states"])
        priorities = MetaLearner._generate_priorities(trends, strategies, fault_profile)
        plan = MetaLearner._build_plan(priorities, trends, fault_profile)
        return plan

    # ─── Phase 1: 数据采集 ───

    @staticmethod
    def _collect_data() -> dict:
        assessments = assessment_get_last("", limit=50)
        # Parse all assessment records, extract dimension scores
        records = []
        for a in assessments:
            data = a.get("data", {})
            delta = data.get("delta", {})
            after = data.get("after", {})
            dims = delta.get("dimensions", {}) or after.get("dimension_scores", {})
            record = {
                "id": a["id"],
                "type": a["type"],
                "created_at": a["created_at"],
                "overall_after": delta.get("overall_after") or after.get("overall_score"),
                "judgment": delta.get("judgment", "?"),
                "dimensions": dims,
            }
            records.append(record)

        knowledge = shared_get("", "", limit=200)

        states = state_get()
        state_list = list(states.values())

        hb = get_heartbeat()
        hb_status = hb.status()

        return {
            "assessments": records,
            "knowledge": knowledge,
            "states": state_list,
            "heartbeat": hb_status,
            "assessment_raw": assessments,
        }

    # ─── Phase 2: 趋势分析 ───

    @staticmethod
    def _analyze_trends(records: list) -> dict:
        """分析四维度评分随迭代轮次的变化趋势"""
        dim_scores = {d: [] for d in MetaLearner.DIMENSIONS}
        # Sort by time
        sorted_recs = sorted(records, key=lambda r: r.get("created_at", 0))

        for rec in sorted_recs:
            dims = rec.get("dimensions", {})
            if isinstance(dims, dict):
                for d in MetaLearner.DIMENSIONS:
                    v = dims.get(d, {}).get("after") or dims.get(d)
                    if isinstance(v, (int, float)) and v > 0:
                        dim_scores[d].append(v)
            overall = rec.get("overall_after")
            if isinstance(overall, (int, float)) and overall > 0:
                dim_scores.setdefault("overall", []).append(overall)

        trends = {}
        for dim, vals in dim_scores.items():
            if len(vals) >= 2:
                slope = (vals[-1] - vals[0]) / max(1, len(vals) - 1)
                direction = "up" if slope > 0.5 else "down" if slope < -0.5 else "flat"
            else:
                slope = 0
                direction = "flat"
            trends[dim] = {
                "values": vals,
                "current": vals[-1] if vals else 0,
                "slope": round(slope, 2),
                "direction": direction,
                "n": len(vals),
            }

        # Identify weakest dimension
        weakest = None
        weakest_score = 100
        for d in MetaLearner.DIMENSIONS:
            t = trends.get(d, {})
            cv = t.get("current", 0)
            if cv and cv < weakest_score:
                weakest_score = cv
                weakest = d

        return {
            "dimensions": trends,
            "overall": trends.get("overall", {}),
            "weakest_dimension": weakest,
            "weakest_score": weakest_score,
            "total_rounds_analyzed": len(sorted_recs),
        }

    # ─── Phase 3: 策略效果评估 ───

    @staticmethod
    def _assess_strategies(knowledge: list, trends: dict) -> list:
        """从共享知识中提取策略, 评估其对趋势的影响"""
        category_counts = {cat: 0 for cat in MetaLearner.STRATEGY_CATEGORIES}
        category_confidences = {cat: [] for cat in MetaLearner.STRATEGY_CATEGORIES}
        strategy_examples = {cat: [] for cat in MetaLearner.STRATEGY_CATEGORIES}

        for k in knowledge:
            text = (k.get("lesson", "") + " " + k.get("source", "")).lower()
            raw_conf = k.get("confidence", 50)
            if isinstance(raw_conf, (int, float)):
                conf = raw_conf
            elif isinstance(raw_conf, str):
                try: conf = float(raw_conf)
                except: conf = 50
            else:
                conf = 50
            matched = False
            for cat, keywords in MetaLearner.STRATEGY_CATEGORIES.items():
                if any(kw.lower() in text for kw in keywords):
                    category_counts[cat] += 1
                    category_confidences[cat].append(conf)
                    if len(strategy_examples[cat]) < 3:
                        strategy_examples[cat].append(k.get("lesson", "")[:120])
                    matched = True
            if not matched:
                category_counts.setdefault("other", 0)
                category_counts["other"] += 1

        # Score each category's effectiveness
        strategy_scores = {}
        for cat in MetaLearner.STRATEGY_CATEGORIES:
            count = category_counts[cat]
            confs = category_confidences[cat]
            avg_conf = round(sum(confs) / len(confs), 1) if confs else 0
            strategy_scores[cat] = {
                "count": count, "avg_confidence": avg_conf,
                "examples": strategy_examples[cat],
            }

        return strategy_scores

    # ─── Phase 4: 故障模式分析 ───

    @staticmethod
    def _analyze_faults(states: list) -> dict:
        """从 Agent 状态和心跳中提取故障模式"""
        total_states = len(states)
        def _safe_conf(s):
            v = s.get("last_confidence", 100)
            if isinstance(v, (int, float)): return v
            if isinstance(v, str):
                try: return float(v)
                except: return 100
            return 100
        low_confidence = sum(1 for s in states if _safe_conf(s) < 50)
        low_quality = sum(1 for s in states if s.get("last_quality", "优") in ("差", "中"))
        return {
            "total_agents_states": total_states,
            "low_confidence_agents": low_confidence,
            "low_quality_agents": low_quality,
            "fault_prone_pct": round(low_quality / max(1, total_states) * 100, 1),
        }

    # ─── Phase 5: 自主优先级生成 ───

    @staticmethod
    def _generate_priorities(trends: dict, strategies: dict, faults: dict) -> list:
        """完全脱离人工预设, 从数据中推导优化优先级"""
        priorities = []
        dims = trends.get("dimensions", {})

        # Factor 1: Weakest dimension first
        weakest = trends.get("weakest_dimension")
        weakest_score = trends.get("weakest_score", 50)
        if weakest:
            priorities.append({
                "rank": 1,
                "target": weakest,
                "rationale": f"当前最弱维度 ({weakest_score}), 提升空间最大",
                "urgency": round((100 - weakest_score) / 20, 1),
                "category": "dimension_gap",
            })

        # Factor 2: Declining dimensions
        for d in MetaLearner.DIMENSIONS:
            t = dims.get(d, {})
            if t.get("direction") == "down":
                priorities.append({
                    "rank": 99,
                    "target": d,
                    "rationale": f"{d} 呈下降趋势 (斜率={t.get('slope')})",
                    "urgency": 8.0,
                    "category": "regression_risk",
                })

        # Factor 3: Low-coverage strategy areas
        for cat, info in strategies.items():
            if info["count"] == 0:
                priorities.append({
                    "rank": 99,
                    "target": f"strategy:{cat}",
                    "rationale": f"策略类别 '{cat}' 无历史实践, 探索潜力高",
                    "urgency": 3.0,
                    "category": "strategy_gap",
                })

        # Factor 4: Fault patterns
        if faults.get("fault_prone_pct", 0) > 20:
            priorities.append({
                "rank": 99,
                "target": "fault_tolerance",
                "rationale": f"低质量 Agent 占比 {faults['fault_prone_pct']}%, 需基础质量提升",
                "urgency": round(faults["fault_prone_pct"] / 10, 1),
                "category": "quality_gap",
            })

        # Rank and assign final positions
        priorities.sort(key=lambda p: -p["urgency"])
        for i, p in enumerate(priorities):
            p["rank"] = i + 1
            p["priority_label"] = "critical" if i == 0 else "high" if i < 3 else "medium"

        return priorities

    # ─── Phase 6: 构建优化计划 ───

    @staticmethod
    def _build_plan(priorities: list, trends: dict, faults: dict) -> dict:
        """将优先级转换为可执行的优化计划"""
        plan_items = []
        for p in priorities:
            item = {
                "target": p["target"],
                "rationale": p["rationale"],
                "urgency": p["urgency"],
                "priority": p["priority_label"],
            }
            # Map targets to concrete actions
            if p["target"] == "memory_efficiency":
                item["suggested_action"] = "优化记忆索引/压缩策略, 提升高置信度知识复用率"
                item["expected_impact"] = "+5-8 分"
            elif p["target"] == "evolution_capability":
                item["suggested_action"] = "增强元认知轮次深度, 推动 Agent 自主设定子目标"
                item["expected_impact"] = "+3-6 分"
            elif p["target"] == "reasoning_quality":
                item["suggested_action"] = "引入多步推理链验证, 降低偏差传播"
                item["expected_impact"] = "+4-7 分"
            elif p["target"] == "architecture":
                item["suggested_action"] = "加固断路器阈值自适应, 减少降级频次"
                item["expected_impact"] = "+3-5 分"
            elif "strategy" in p["target"]:
                item["suggested_action"] = f"在 {p['target'].split(':')[1]} 领域探索新策略"
                item["expected_impact"] = "+2-4 分"
            elif p["target"] == "fault_tolerance":
                item["suggested_action"] = "对低质量 Agent 注入强化训练样本, 提升基础推理"
                item["expected_impact"] = "+3-6 分"
            else:
                item["suggested_action"] = "深度诊断该维度瓶颈"
                item["expected_impact"] = "待探索"
            plan_items.append(item)

        # Meta-diagnostic: predition of regression risk
        meta_diagnosis = MetaLearner._meta_diagnose(trends, faults)

        return {
            "plan": plan_items,
            "priorities_raw": priorities,
            "trends_summary": {
                "overall_current": trends.get("overall", {}).get("current", 0),
                "total_rounds": trends.get("total_rounds_analyzed", 0),
                "weakest": trends.get("weakest_dimension"),
                "weakest_score": trends.get("weakest_score"),
            },
            "fault_summary": faults,
            "meta_diagnosis": meta_diagnosis,
            "generated_at": time.time(),
            "methodology": "fully_autonomous_data_driven",
        }

    # ─── Phase 7: 预算推演 (API消耗 / 评分收益 / 效率分析) ───

    BUDGET_TIERS = [
        # (min_remaining_pct, label, agents, speed_mode, concurrency, cooldown, desc)
        (0.50, "green",   30, False, 30, 300, "full depth"),
        (0.25, "yellow",  20, True,  15, 600, "reduced: speed mode"),
        (0.10, "red",     10, True,   5, 1200, "minimal: 10 agents"),
        (0.0,  "critical", 0, True,   0, 86400, "sleep: wait for next day"),
    ]

    @staticmethod
    def _analyze_api_efficiency(assessments: list) -> tuple:
        """分析历史 API 消耗效率: 返回 (per_cycle_cost, efficiency, score_history, cost_history)"""
        cost_history = []
        score_history = []
        for a in assessments:
            data = a.get("data", {})
            delta = data.get("delta", {})
            after = data.get("after", {})
            score = after.get("overall_score") or delta.get("overall_after")
            if not score:
                continue
            # Estimate API calls: agent_count for inference + meta-vote (≈agent_count)
            agent_count = data.get("agent_count", 30)
            api_est = agent_count * 2  # inference + meta-vote
            if "daemon_triggered" in data:
                api_est = data.get("api_calls_made", api_est)
            cost_history.append(api_est)
            score_history.append(score)

        if len(cost_history) < 2:
            return 60, 0.0, score_history, cost_history  # default: 60 API calls per cycle

        # Per-cycle cost trend
        recent_costs = cost_history[-3:]
        avg_cost = round(sum(recent_costs) / len(recent_costs))

        # Efficiency: score improvement per 100 API calls
        deltas = [score_history[i] - score_history[i-1] for i in range(1, len(score_history))]
        efficiency_list = []
        for i, d in enumerate(deltas):
            if cost_history[i] > 0 and d > 0:
                efficiency_list.append(d / cost_history[i] * 100)  # points per 100 API calls
        avg_efficiency = round(sum(efficiency_list) / len(efficiency_list), 2) if efficiency_list else 0.5

        return avg_cost, avg_efficiency, score_history, cost_history

    @staticmethod
    def _recommend_budget(assessments: list, avg_cost: int, avg_efficiency: float,
                          improvement_rate: float, weakest_score: float) -> dict:
        """从历史数据推导每日预算 + 分级降级阈值"""
        # Base: allow 3-4 cycles per day
        base_cost = avg_cost * 3

        # Boost if weak dimensions need catch-up
        gap_boost = max(0, (70 - weakest_score)) * 2

        # Boost if improving fast (high efficiency = good ROI)
        efficiency_boost = avg_efficiency * 5

        recommended = int(base_cost + gap_boost + efficiency_boost)
        recommended = max(60, min(500, recommended))  # clamp

        # Budget tiers derived from recommended
        tiers = [
            {"name": t[1], "agents": t[2], "speed_mode": t[3], "concurrency": t[4],
             "cooldown": t[5], "description": t[6]}
            for t in MetaLearner.BUDGET_TIERS
        ]

        return {
            "daily_api_budget": recommended,
            "budget_tiers": tiers,
            "budget_green_at": int(recommended * 0.50),
            "budget_yellow_at": int(recommended * 0.25),
            "budget_red_at": int(recommended * 0.10),
            "avg_cost_per_cycle": avg_cost,
            "avg_efficiency": avg_efficiency,
            "rationale": (
                f"base={base_cost}(3cycles) + gap_boost={gap_boost:.0f} + "
                f"efficiency_boost={efficiency_boost:.0f} = {recommended}"
            ),
        }

    # ─── Phase 8: 参数自适应推荐 (全面版) ───

    @staticmethod
    def recommend_parameters() -> dict:
        """从 R0-R5 历史数据中推荐运行参数, 逐步替代硬编码常数"""
        data = MetaLearner._collect_data()
        trends = MetaLearner._analyze_trends(data["assessments"])
        faults = MetaLearner._analyze_faults(data["states"])

        assessments = data["assessments"]
        regressions = sum(1 for r in assessments if r.get("judgment") == "退化")
        improvements = sum(1 for r in assessments if r.get("judgment") == "改进")
        total = len(assessments) or 1
        failure_rate = regressions / total
        improvement_rate = improvements / total

        dims = trends.get("dimensions", {})
        vals_arch = dims.get("architecture", {}).get("values", [])
        avg_arch = sum(vals_arch) / len(vals_arch) if vals_arch else 70

        # Breaker threshold
        base_breaker = 5
        if failure_rate > 0.3:
            breaker_threshold = max(3, base_breaker - 2)
        elif avg_arch > 75:
            breaker_threshold = base_breaker + 2
        else:
            breaker_threshold = base_breaker

        # Concurrency (base, tiers override this based on budget)
        concurrency = 30
        if failure_rate > 0.2:
            concurrency = 20
        elif avg_arch > 75:
            concurrency = 30

        # Cooldown (base)
        if improvement_rate > 0.7:
            cooldown = 180
        elif failure_rate > 0.2:
            cooldown = 600
        else:
            cooldown = 300

        # Auto-start threshold
        weakest = trends.get("weakest_score", 70)
        should_start_threshold = round(max(0.3, min(0.9, (100 - weakest) / 80)), 2)

        # Budget estimation (replaces hardcoded 200)
        avg_cost, avg_efficiency, _, _ = MetaLearner._analyze_api_efficiency(assessments)
        budget = MetaLearner._recommend_budget(
            assessments, avg_cost, avg_efficiency, improvement_rate, weakest
        )

        return {
            "breaker_threshold": breaker_threshold,
            "concurrency": concurrency,
            "cooldown_seconds": cooldown,
            "auto_start_threshold": should_start_threshold,
            "budget": budget,
            "failure_rate": round(failure_rate, 2),
            "improvement_rate": round(improvement_rate, 2),
            "rationale": (
                f"failure_rate={failure_rate:.0%}, improvement_rate={improvement_rate:.0%}, "
                f"avg_architecture={avg_arch:.0f}, weakest={trends.get('weakest_score',0):.0f}"
            ),
            "hardcoded_remaining": [],  # All parameters now data-driven
        }

    # ─── Meta-Diagnosis: 回归预判 ───

    @staticmethod
    def _meta_diagnose(trends: dict, faults: dict) -> dict:
        """预判迭代退化风险: 基于历史模式 + 当前预警信号"""
        dims = trends.get("dimensions", {})
        warnings = []
        risk_score = 0

        # Flag: any dimension declining
        for d in MetaLearner.DIMENSIONS:
            t = dims.get(d, {})
            if t.get("direction") == "down":
                warnings.append(f"{d} 连续下滑 (斜率 {t.get('slope')})")
                risk_score += 3

        # Flag: volatile scores (high variance)
        for d in MetaLearner.DIMENSIONS:
            t = dims.get(d, {})
            vals = t.get("values", [])
            if len(vals) >= 3:
                avg = sum(vals) / len(vals)
                variance = sum((v - avg)**2 for v in vals) / len(vals)
                if variance > 50:
                    warnings.append(f"{d} 评分波动大 (variance={variance:.0f})")
                    risk_score += 2

        # Flag: high fault rate
        if faults.get("fault_prone_pct", 0) > 30:
            warnings.append(f"Agent 低质量比例 {faults['fault_prone_pct']}%, 底层质量不足")
            risk_score += 2

        risk_level = "high" if risk_score > 7 else "medium" if risk_score > 3 else "low"

        return {
            "risk_score": risk_score,
            "risk_level": risk_level,
            "warnings": warnings,
            "advice": "优先加固最弱和下降维度, 再探索新策略" if risk_level != "low" else "系统稳定, 可探索新策略",
        }
