"""
Autonomous Scheduler — 永续自治后台调度器
v1.0: 轮询 + 分层休眠 + 熔断感知 + 故障指数退避
"""
import asyncio, json, time
from pathlib import Path
from .sqlite_store import work_get_stats, work_enqueue, work_claim, work_complete, assessment_save


class AutonomousScheduler:
    """常驻后台自治循环调度器"""

    # Hibernation tiers
    TIERS = [
        {"name": "active",     "idle_max": 2,  "sem": 30, "speed": False, "sleep": 30},
        {"name": "cooldown",   "idle_max": 5,  "sem": 15, "speed": True,  "sleep": 60},
        {"name": "light_sleep","idle_max": 10, "sem": 5,  "speed": True,  "sleep": 120},
        {"name": "deep_sleep", "idle_max": 99, "sem": 1,  "speed": True,  "sleep": 300},
    ]

    def __init__(self):
        self.idle_cycles = 0
        self.total_cycles = 0
        self.last_cycle_time = 0.0
        self.consecutive_errors = 0
        self.state = {"phase": "idle", "idle_cycles": 0, "tier": "active",
                      "total_cycles": 0, "last_error": "", "uptime": 0.0}
        self._running = False

    def get_tier(self):
        for t in self.TIERS:
            if self.idle_cycles <= t["idle_max"]:
                return t
        return self.TIERS[-1]

    async def run_cycle(self):
        """单次自治循环"""
        from .global_workspace import GlobalWorkspace as GW
        from .dream_engine import DreamEngine
        from .cognitive_architecture import _breaker_state, _BREAKER, _breaker_failure, _breaker_success

        self.total_cycles += 1
        self.last_cycle_time = time.time()
        tier = self.get_tier()
        self.state["phase"] = "cycle_start"
        self.state["tier"] = tier["name"]

        # 1. Breaker check
        bs = _breaker_state()
        if bs == "OPEN":
            self.state["phase"] = "breaker_open_wait"
            return {"status": "breaker_open", "sleep": 60}

        # 2. Process work queue
        pending = work_get_stats().get("pending", 0)
        if pending > 0:
            self.idle_cycles = 0
            self.state["phase"] = "processing"
            consumed = 0
            while True:
                task = work_claim("scheduler")
                if not task:
                    break
                await self._execute_task(task, tier)
                consumed += 1
            self.state["phase"] = "processing_done"
            return {"status": "processed", "consumed": consumed}
        else:
            self.idle_cycles += 1
            # 3. Dream when idle
            if self.idle_cycles <= 2:  # First 2 idle cycles → dream
                self.state["phase"] = "dreaming"
                agent_dirs = sorted((Path(__file__).parent.parent).glob("agent_*"))
                for d in agent_dirs:
                    DreamEngine.dream_for_agent(str(d))
                return {"status": "dreamed", "idle_cycles": self.idle_cycles}
            else:
                self.state["phase"] = "idle"
                return {"status": "idle", "idle_cycles": self.idle_cycles}

    async def _execute_task(self, task: dict, tier: dict):
        """执行单个工作项（熔断感知）"""
        from .cognitive_architecture import _breaker_state, _breaker_failure, _breaker_success
        try:
            bs = _breaker_state()
            if bs == "OPEN":
                work_complete(task["id"], "breaker_open_deferred", "deferred")
                return
            work_complete(task["id"], f"executed_by_scheduler_{tier['name']}")
            _breaker_success()
        except Exception as e:
            _breaker_failure()
            self.consecutive_errors += 1
            work_complete(task["id"], str(e)[:200], "failed")

    async def run_forever(self):
        """永续循环入口"""
        self._running = True
        start = time.time()
        while self._running:
            try:
                result = await self.run_cycle()
                tier = self.get_tier()
                sleep_time = tier["sleep"]
                # Exponential backoff on errors
                if self.consecutive_errors > 0:
                    sleep_time = min(sleep_time * (2 ** min(self.consecutive_errors, 5)), 600)
            except Exception as e:
                sleep_time = 60
                self.consecutive_errors += 1
                self.state["last_error"] = str(e)[:200]

            self.state["uptime"] = round(time.time() - start)
            await asyncio.sleep(sleep_time)

    def stop(self):
        self._running = False

    def status(self) -> dict:
        return {
            **self.state,
            "total_cycles": self.total_cycles,
            "consecutive_errors": self.consecutive_errors,
            "tier_config": self.get_tier(),
            "running": self._running
        }


# Singleton scheduler instance
_scheduler = AutonomousScheduler()


def get_scheduler():
    return _scheduler
