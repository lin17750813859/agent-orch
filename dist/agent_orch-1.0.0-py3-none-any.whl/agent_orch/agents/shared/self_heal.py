"""
Self Heal — 自愈机制: 文件完整性检查 + store.db 备份 + 断链修复
v1.0: 检测→备份→修复 三级管线
"""
import json, time, shutil, sqlite3, threading
from pathlib import Path


class SelfHealer:
    """自愈系统 — 检测/备份/修复三阶段"""

    BACKUP_DIR = Path(__file__).parent.parent / "workspace" / "backups"
    MAX_BACKUPS = 10

    @staticmethod
    def integrity_check(agent_dir: str | Path | None = None) -> dict:
        """完整检测: 目录/配置/API密钥/记忆文件/SQLite/广播缓存"""
        checks = []
        all_pass = True
        base = Path(__file__).parent.parent

        # 1. Agent 目录完整性
        agent_path = Path(agent_dir) if agent_dir else None
        dirs_to_check = [base / "shared"] if not agent_path else [agent_path]
        if not agent_path:
            dirs_to_check.append(base / "workspace")

        for d in dirs_to_check:
            exists = d.exists()
            checks.append({"check": f"dir:{d.name}", "pass": exists})
            if not exists:
                all_pass = False

        # 2. 各 agent 的 config.json + persona.md
        agent_dirs = sorted(base.glob("agent_*"))
        missing_configs = 0
        missing_personas = 0
        empty_keys = 0
        for d in agent_dirs:
            if not d.is_dir():
                continue
            cfg = d / "config.json"
            if cfg.exists():
                try:
                    data = json.loads(cfg.read_text(encoding="utf-8"))
                    if not data.get("api_key", "").strip():
                        empty_keys += 1
                except:
                    missing_configs += 1
                    checks.append({"check": f"config_json:{d.name}", "pass": False, "error": "JSON损坏"})
                    all_pass = False
            else:
                missing_configs += 1
                checks.append({"check": f"config:{d.name}", "pass": False, "error": "文件缺失"})
                all_pass = False

            pm = d / "persona.md"
            if not pm.exists():
                missing_personas += 1
                checks.append({"check": f"persona:{d.name}", "pass": False, "error": "文件缺失"})
                all_pass = False

        if missing_configs == 0 and empty_keys == 0:
            checks.append({"check": "agent_configs", "pass": True})
        if missing_personas == 0:
            checks.append({"check": "agent_personas", "pass": True})

        # 3. 记忆文件 JSON 合法性
        corrupt_memories = 0
        for d in agent_dirs:
            if not d.is_dir():
                continue
            mem_dir = d / "memory"
            if not mem_dir.exists():
                continue
            for f in ["episodic.json", "semantic.json", "strategies.json"]:
                path = mem_dir / f
                if path.exists():
                    try:
                        json.loads(path.read_text(encoding="utf-8"))
                    except:
                        corrupt_memories += 1
                        checks.append({"check": f"memory:{d.name}/{f}", "pass": False, "error": "JSON损坏"})
                        all_pass = False

        if corrupt_memories == 0:
            checks.append({"check": "memory_files", "pass": True})

        # 4. SQLite DB
        db_path = base / "workspace" / "store.db"
        db_ok = False
        if db_path.exists():
            try:
                conn = sqlite3.connect(str(db_path))
                conn.execute("SELECT COUNT(*) FROM global_cache").fetchone()
                conn.close()
                db_ok = True
                checks.append({"check": "sqlite_db", "pass": True})
            except Exception as e:
                checks.append({"check": "sqlite_db", "pass": False, "error": str(e)[:100]})
                all_pass = False
        else:
            checks.append({"check": "sqlite_db", "pass": False, "error": "DB文件缺失"})
            all_pass = False

        # 5. 广播文件
        bcast_path = base / "workspace" / "broadcasts.jsonl"
        bcast_ok = False
        if bcast_path.exists():
            try:
                with open(bcast_path, "r", encoding="utf-8") as f:
                    for line in f:
                        if line.strip():
                            json.loads(line)
                bcast_ok = True
                checks.append({"check": "broadcasts_file", "pass": True})
            except:
                checks.append({"check": "broadcasts_file", "pass": False, "error": "JSONL损坏"})
                all_pass = False
        else:
            checks.append({"check": "broadcasts_file", "pass": True, "note": "尚未创建"})

        return {
            "overall": "pass" if all_pass else "has_issues",
            "total_checks": len(checks),
            "passed": sum(1 for c in checks if c.get("pass")),
            "failed": sum(1 for c in checks if not c.get("pass")),
            "checks": checks,
            "summary": {
                "agents_found": len(agent_dirs),
                "missing_configs": missing_configs,
                "missing_personas": missing_personas,
                "empty_api_keys": empty_keys,
                "corrupt_memories": corrupt_memories,
                "db_ok": db_ok,
                "bcast_ok": bcast_ok,
            },
        }

    @staticmethod
    def backup(tag: str = "") -> dict:
        """创建 store.db 检查点 + 关键配置快照"""
        base = Path(__file__).parent.parent
        SelfHealer.BACKUP_DIR.mkdir(parents=True, exist_ok=True)

        ts = int(time.time())
        label = f"{tag}_{ts}" if tag else str(ts)
        backup_path = SelfHealer.BACKUP_DIR / f"snapshot_{label}"
        backup_path.mkdir(exist_ok=True)

        files = []
        # store.db
        db_src = base / "workspace" / "store.db"
        if db_src.exists():
            dst = backup_path / "store.db"
            shutil.copy2(str(db_src), str(dst))
            files.append("store.db")

        # broadcasts (keep last 500 lines)
        bcast_src = base / "workspace" / "broadcasts.jsonl"
        if bcast_src.exists():
            dst = backup_path / "broadcasts.jsonl"
            lines = bcast_src.read_text(encoding="utf-8").strip().split("\n")
            kept = lines[-500:]
            dst.write_text("\n".join(kept) + "\n", encoding="utf-8")
            files.append("broadcasts.jsonl")

        # Prune old backups
        all_backups = sorted(SelfHealer.BACKUP_DIR.glob("snapshot_*"),
                             key=lambda p: p.stat().st_mtime)
        while len(all_backups) > SelfHealer.MAX_BACKUPS:
            oldest = all_backups.pop(0)
            shutil.rmtree(str(oldest))
            files.append(f"pruned:{oldest.name}")

        return {
            "status": "done",
            "backup_path": str(backup_path),
            "files": files,
            "timestamp": time.time(),
            "total_backups": len(list(SelfHealer.BACKUP_DIR.glob("snapshot_*"))),
        }

    @staticmethod
    def repair() -> dict:
        """自动修复可修复的问题"""
        report = SelfHealer.integrity_check()
        repairs = []
        base = Path(__file__).parent.parent

        if not report["overall"] == "pass":
            # Repair SQLite (re-create missing DB)
            db_path = base / "workspace" / "store.db"
            if not db_path.exists():
                from .sqlite_store import init_db
                init_db()
                repairs.append("重建 SQLite store.db")

            # Repair missing memory files (create empty)
            agent_dirs = sorted(base.glob("agent_*"))
            for d in agent_dirs:
                if not d.is_dir():
                    continue
                mem_dir = d / "memory"
                mem_dir.mkdir(exist_ok=True)
                for f in ["episodic.json", "semantic.json", "strategies.json"]:
                    path = mem_dir / f
                    if not path.exists():
                        path.write_text("[]", encoding="utf-8")
                        repairs.append(f"创建 {d.name}/memory/{f}")

            # Repair corrupted broadcasts (keep valid lines only)
            bcast_path = base / "workspace" / "broadcasts.jsonl"
            if bcast_path.exists():
                try:
                    valid = []
                    with open(bcast_path, "r", encoding="utf-8") as f:
                        for line in f:
                            line = line.strip()
                            if line:
                                try:
                                    json.loads(line)
                                    valid.append(line)
                                except:
                                    pass
                    with open(bcast_path, "w", encoding="utf-8") as f:
                        f.write("\n".join(valid) + "\n")
                    repairs.append(f"清理 broadcasts.jsonl (保留 {len(valid)} 条有效)")
                except:
                    pass

        return {
            "status": "done" if repairs else "no_repair_needed",
            "repairs": repairs,
            "repair_count": len(repairs),
            "timestamp": time.time(),
        }
