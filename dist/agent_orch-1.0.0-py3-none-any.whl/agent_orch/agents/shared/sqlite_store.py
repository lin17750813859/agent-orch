"""
SQLite 持久化存储 — 替代 JSONL/JSON 文件, 提供跨会话持久化
Tables: global_cache, shared_knowledge, work_queue, agent_states, assessment_records
"""
import sqlite3, json, time, threading, os
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "workspace" / "store.db"
_db_lock = threading.Lock()
_local = threading.local()


def _get_conn():
    if not hasattr(_local, "conn") or _local.conn is None:
        _local.conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        _local.conn.execute("PRAGMA journal_mode=WAL")
        _local.conn.execute("PRAGMA synchronous=NORMAL")
    return _local.conn


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = _get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS global_cache (
            key_hash TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            model TEXT DEFAULT '',
            temp REAL DEFAULT 0.7,
            tag TEXT DEFAULT '',
            created_at REAL NOT NULL,
            expires_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_cache_expires ON global_cache(expires_at);
        CREATE INDEX IF NOT EXISTS idx_cache_tag ON global_cache(tag);

        CREATE TABLE IF NOT EXISTS shared_knowledge (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent TEXT NOT NULL,
            lesson TEXT NOT NULL,
            source TEXT DEFAULT '',
            confidence REAL DEFAULT 0.0,
            pushed_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_shared_agent ON shared_knowledge(agent);
        CREATE INDEX IF NOT EXISTS idx_shared_pushed ON shared_knowledge(pushed_at);

        CREATE TABLE IF NOT EXISTS work_queue (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL,
            description TEXT DEFAULT '',
            priority INTEGER DEFAULT 5,
            agent_target TEXT DEFAULT '',
            agent_claimed TEXT DEFAULT '',
            status TEXT DEFAULT 'pending',
            created REAL,
            started REAL,
            completed REAL,
            result TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_work_status ON work_queue(status);
        CREATE INDEX IF NOT EXISTS idx_work_priority ON work_queue(priority);

        CREATE TABLE IF NOT EXISTS agent_states (
            agent_name TEXT PRIMARY KEY,
            state_json TEXT NOT NULL,
            last_update REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS assessment_records (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL,
            data_json TEXT NOT NULL,
            created_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_assessment_type ON assessment_records(type);
    """)
    conn.commit()


# ─── Global Cache ───────────────────────────────────────────

def cache_get(key_hash: str) -> str | None:
    conn = _get_conn()
    row = conn.execute(
        "SELECT value FROM global_cache WHERE key_hash=? AND expires_at>?",
        (key_hash, time.time())
    ).fetchone()
    return row[0] if row else None


def cache_set(key_hash: str, value: str, tag: str = "", ttl: float = 3600,
              model: str = "", temp: float = 0.7):
    now = time.time()
    with _db_lock:
        conn = _get_conn()
        conn.execute(
            "INSERT OR REPLACE INTO global_cache VALUES (?,?,?,?,?,?,?)",
            (key_hash, value, model, temp, tag, now, now + ttl)
        )
        conn.commit()


def cache_invalidate(tag: str = ""):
    conn = _get_conn()
    if tag:
        conn.execute("DELETE FROM global_cache WHERE tag=?", (tag,))
    else:
        conn.execute("DELETE FROM global_cache")
    conn.commit()


def cache_get_stats() -> dict:
    conn = _get_conn()
    total = conn.execute("SELECT COUNT(*) FROM global_cache").fetchone()[0]
    expired = conn.execute("SELECT COUNT(*) FROM global_cache WHERE expires_at<=?",
                           (time.time(),)).fetchone()[0]
    tags = conn.execute("SELECT tag, COUNT(*) FROM global_cache GROUP BY tag").fetchall()
    return {"total": total, "expired": expired, "tags": dict(tags), "path": str(DB_PATH)}


# ─── Shared Knowledge ───────────────────────────────────────

def shared_push(agent: str, lesson: str, source: str = "", confidence: float = 0.0):
    conn = _get_conn()
    # keep max 500
    count = conn.execute("SELECT COUNT(*) FROM shared_knowledge").fetchone()[0]
    with _db_lock:
        if count >= 500:
            conn.execute("DELETE FROM shared_knowledge WHERE id IN (SELECT id FROM shared_knowledge ORDER BY pushed_at ASC LIMIT ?)",
                         (count - 499,))
        conn.execute(
            "INSERT INTO shared_knowledge (agent, lesson, source, confidence, pushed_at) VALUES (?,?,?,?,?)",
            (agent, lesson[:500], source[:100], confidence, time.time())
        )
        conn.commit()


def shared_get(topic: str = "", agent: str = "", limit: int = 10) -> list:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT agent, lesson, source, confidence, pushed_at FROM shared_knowledge ORDER BY pushed_at DESC LIMIT 500"
    ).fetchall()
    knowledge = [{"agent": r[0], "lesson": r[1], "source": r[2], "confidence": r[3], "pushed_at": r[4]} for r in rows]
    if agent:
        knowledge = [k for k in knowledge if k["agent"] == agent]
    if topic:
        tokens = set(t.lower() for t in topic.split() if len(t) >= 2)
        for i in range(len(topic) - 1):
            pair = topic[i:i+2]
            if all('\u4e00' <= c <= '\u9fff' for c in pair):
                tokens.add(pair)
        scored = []
        for k in knowledge:
            text = (k["lesson"] + " " + k["source"]).lower()
            score = sum(1 for t in tokens if t in text)
            if score > 0:
                scored.append((score, k))
        scored.sort(key=lambda x: -x[0])
        knowledge = [k for _, k in scored]
    return knowledge[:limit]


def shared_get_stats() -> dict:
    conn = _get_conn()
    total = conn.execute("SELECT COUNT(*) FROM shared_knowledge").fetchone()[0]
    agents = conn.execute("SELECT DISTINCT agent FROM shared_knowledge").fetchall()
    return {"total": total, "agents": [r[0] for r in agents], "agent_count": len(agents), "path": str(DB_PATH)}


# ─── Work Queue ─────────────────────────────────────────────

_work_seq = 0

def _work_id():
    global _work_seq
    _work_seq += 1
    return f"sw{int(time.time()*1000)}_{_work_seq % 100000}"

def work_enqueue(type_: str, description: str, priority: int = 5,
                  agent_target: str = "") -> dict:
    entry = {
        "id": _work_id(),
        "type": type_,
        "description": description,
        "priority": priority,
        "agent_target": agent_target,
        "agent_claimed": "",
        "status": "pending",
        "created": time.time(),
        "started": 0.0,
        "completed": 0.0,
        "result": ""
    }
    conn = _get_conn()
    conn.execute(
        "INSERT INTO work_queue VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (entry["id"], type_, description, priority, agent_target, "",
         "pending", entry["created"], 0.0, 0.0, "")
    )
    conn.commit()
    return entry


def work_claim(agent_name: str = "") -> dict | None:
    conn = _get_conn()
    with _db_lock:
        row = conn.execute(
            "SELECT id, type, description, priority, agent_target "
            "FROM work_queue WHERE status='pending' "
            "ORDER BY priority DESC, created ASC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        eid, typ, desc, pri, target = row
        if target and agent_name and target != agent_name:
            return None
        conn.execute(
            "UPDATE work_queue SET status='running', agent_claimed=?, started=? WHERE id=?",
            (agent_name, time.time(), eid)
        )
        conn.commit()
    return {"id": eid, "type": typ, "description": desc, "priority": pri}


def work_complete(task_id: str, result: str = "", status: str = "done"):
    conn = _get_conn()
    conn.execute(
        "UPDATE work_queue SET status=?, completed=?, result=? WHERE id=?",
        (status, time.time(), result[:1000], task_id)
    )
    conn.commit()


def work_get_stats() -> dict:
    conn = _get_conn()
    total = conn.execute("SELECT COUNT(*) FROM work_queue").fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM work_queue WHERE status='pending'").fetchone()[0]
    running = conn.execute("SELECT COUNT(*) FROM work_queue WHERE status='running'").fetchone()[0]
    done = conn.execute("SELECT COUNT(*) FROM work_queue WHERE status='done'").fetchone()[0]
    return {"total": total, "pending": pending, "running": running, "done": done}


def work_get_pending(limit: int = 10) -> list:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT id, type, description, priority FROM work_queue "
        "WHERE status='pending' ORDER BY priority DESC, created ASC LIMIT ?",
        (limit,)
    ).fetchall()
    return [{"id": r[0], "type": r[1], "description": r[2], "priority": r[3]} for r in rows]


# ─── Agent States ───────────────────────────────────────────

def state_set(agent_name: str, state: dict):
    conn = _get_conn()
    conn.execute(
        "INSERT OR REPLACE INTO agent_states VALUES (?,?,?)",
        (agent_name, json.dumps(state, ensure_ascii=False), time.time())
    )
    conn.commit()


def state_get(agent_name: str = "") -> dict:
    conn = _get_conn()
    if agent_name:
        row = conn.execute("SELECT state_json FROM agent_states WHERE agent_name=?", (agent_name,)).fetchone()
        return json.loads(row[0]) if row else {}
    rows = conn.execute("SELECT agent_name, state_json FROM agent_states").fetchall()
    return {r[0]: json.loads(r[1]) for r in rows}


# ─── Assessment Records ─────────────────────────────────────

def assessment_save(type_: str, data: dict):
    eid = f"as_{type_}_{int(time.time())}"
    conn = _get_conn()
    conn.execute(
        "INSERT INTO assessment_records VALUES (?,?,?,?)",
        (eid, type_, json.dumps(data, ensure_ascii=False), time.time())
    )
    conn.commit()
    return eid


def assessment_get_all(type_: str = "") -> list:
    """Return ALL assessment records (no limit), for longitudinal analysis"""
    conn = _get_conn()
    if type_:
        rows = conn.execute(
            "SELECT id, type, data_json, created_at FROM assessment_records "
            "WHERE type=? ORDER BY created_at ASC",
            (type_,)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, type, data_json, created_at FROM assessment_records "
            "ORDER BY created_at ASC"
        ).fetchall()
    return [{"id": r[0], "type": r[1], "data": json.loads(r[2]), "created_at": r[3]} for r in rows]


def assessment_get_last(type_: str = "", limit: int = 5) -> list:
    conn = _get_conn()
    if type_:
        rows = conn.execute(
            "SELECT id, type, data_json, created_at FROM assessment_records "
            "WHERE type=? ORDER BY created_at DESC LIMIT ?",
            (type_, limit)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, type, data_json, created_at FROM assessment_records "
            "ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [{"id": r[0], "type": r[1], "data": json.loads(r[2]), "created_at": r[3]} for r in rows]


# ─── Migration from JSON ────────────────────────────────────

def migrate_from_json():
    """将现有JSON数据迁移到SQLite (幂等)"""
    from .global_workspace import WORKSPACE_DIR
    init_db()
    conn = _get_conn()

    # Shared knowledge
    shared_path = WORKSPACE_DIR / "shared_knowledge.json"
    if shared_path.exists():
        existing = conn.execute("SELECT COUNT(*) FROM shared_knowledge").fetchone()[0]
        if existing == 0:
            try:
                import json as jmod
                data = jmod.loads(shared_path.read_text(encoding="utf-8"))
                for entry in data:
                    conn.execute(
                        "INSERT INTO shared_knowledge (agent, lesson, source, confidence, pushed_at) VALUES (?,?,?,?,?)",
                        (entry.get("agent", ""), entry.get("lesson", ""), entry.get("source", ""),
                         entry.get("confidence", 0.0), entry.get("pushed_at", time.time()))
                    )
                conn.commit()
                print(f"  migrated {len(data)} shared knowledge entries")
            except: pass

    # Work queue
    wq_path = WORKSPACE_DIR / "self_work_queue.json"
    if wq_path.exists():
        existing = conn.execute("SELECT COUNT(*) FROM work_queue").fetchone()[0]
        if existing == 0:
            try:
                import json as jmod
                data = jmod.loads(wq_path.read_text(encoding="utf-8"))
                for entry in data:
                    conn.execute(
                        "INSERT OR IGNORE INTO work_queue VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        (entry.get("id", f"sw{int(time.time())}"), entry.get("type", ""),
                         entry.get("description", ""), entry.get("priority", 5),
                         entry.get("agent_target", ""), entry.get("agent_claimed", ""),
                         entry.get("status", "pending"), entry.get("created", time.time()),
                         entry.get("started", 0.0), entry.get("completed", 0.0),
                         entry.get("result", ""))
                    )
                conn.commit()
                print(f"  migrated {len(data)} work queue entries")
            except: pass

    # Agent states
    states_path = WORKSPACE_DIR / "agents_state.json"
    if states_path.exists():
        existing = conn.execute("SELECT COUNT(*) FROM agent_states").fetchone()[0]
        if existing == 0:
            try:
                import json as jmod
                data = jmod.loads(states_path.read_text(encoding="utf-8"))
                for agent_name, state in data.items():
                    conn.execute(
                        "INSERT OR IGNORE INTO agent_states VALUES (?,?,?)",
                        (agent_name, jmod.dumps(state, ensure_ascii=False), time.time())
                    )
                conn.commit()
                print(f"  migrated {len(data)} agent states")
            except: pass

    print("  migration complete")
    return True
