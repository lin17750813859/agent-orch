import os, sys, json
from openai import AsyncOpenAI
from mcp.server.fastmcp import FastMCP


def create_agent_server(agent_name: str, agent_dir: str, display_name: str = None):
    with open(os.path.join(agent_dir, "config.json"), "r") as f:
        config = json.load(f)

    with open(os.path.join(agent_dir, "persona.md"), "r", encoding="utf-8") as f:
        persona = f.read()

    client = AsyncOpenAI(
        api_key=config["api_key"],
        base_url=config.get("base_url", "https://open.bigmodel.cn/api/paas/v4/"),
    )

    name = display_name or agent_name
    app = FastMCP(name, instructions=f"You are {name}. {persona}")

    @app.tool(description="Process a task or query using this agent's unique perspective and expertise")
    async def process(task: str, context: str = "") -> str:
        messages = [
            {"role": "system", "content": persona},
        ]
        if context:
            messages.append({"role": "user", "content": f"## Context\n{context}\n\n## Task\n{task}"})
        else:
            messages.append({"role": "user", "content": task})
        response = await client.chat.completions.create(
            model=config.get("model", "glm-4-plus"),
            messages=messages,
            temperature=config.get("temperature", 0.7),
            max_tokens=config.get("max_tokens", 4096),
        )
        return response.choices[0].message.content

    @app.tool(description="Self-reflect on your own previous output to identify strengths, weaknesses, and improvements")
    async def reflect(previous_output: str, reflection_goal: str = "") -> str:
        messages = [
            {"role": "system", "content": persona + "\n\nYou are now in SELF-REFLECTION mode. Critically analyze your own previous output above. Identify strengths, weaknesses, blind spots, assumptions, and concrete improvements. Be honest and rigorous."},
            {"role": "user", "content": f"My previous output:\n{previous_output}\n\nReflection goal: {reflection_goal}" if reflection_goal else f"My previous output:\n{previous_output}"}
        ]
        response = await client.chat.completions.create(
            model=config.get("model", "glm-4-plus"),
            messages=messages,
            temperature=0.5,
            max_tokens=config.get("max_tokens", 4096),
        )
        return response.choices[0].message.content

    @app.tool(description="Make a decision by evaluating options against criteria")
    async def decide(task: str, options: str, criteria: str = "") -> str:
        messages = [
            {"role": "system", "content": persona + "\n\nYou are in DECISION-MAKING mode. Analyze the options carefully against the given criteria and make the best possible decision. Explain your reasoning."},
            {"role": "user", "content": f"## Task\n{task}\n\n## Options\n{options}\n\n## Criteria\n{criteria}" if criteria else f"## Task\n{task}\n\n## Options\n{options}"}
        ]
        response = await client.chat.completions.create(
            model=config.get("model", "glm-4-plus"),
            messages=messages,
            temperature=0.3,
            max_tokens=config.get("max_tokens", 4096),
        )
        return response.choices[0].message.content

    @app.tool(description="Self-optimize a plan or output to better achieve a specific goal")
    async def optimize(current_plan: str, goal: str, constraints: str = "") -> str:
        messages = [
            {"role": "system", "content": persona + "\n\nYou are in OPTIMIZATION mode. Analyze the current plan and improve it to better achieve the goal. Consider efficiency, effectiveness, and constraints."},
            {"role": "user", "content": f"## Current plan\n{current_plan}\n\n## Goal\n{goal}\n\n## Constraints\n{constraints}" if constraints else f"## Current plan\n{current_plan}\n\n## Goal\n{goal}"}
        ]
        response = await client.chat.completions.create(
            model=config.get("model", "glm-4-plus"),
            messages=messages,
            temperature=0.4,
            max_tokens=config.get("max_tokens", 4096),
        )
        return response.choices[0].message.content

    @app.tool(description="Generate diverse creative ideas or solutions for a problem")
    async def ideate(problem: str, constraints: str = "", count: int = 5) -> str:
        messages = [
            {"role": "system", "content": persona + "\n\nYou are in IDEATION mode. Think divergently and generate diverse, creative, and novel ideas. Quantity and variety matter."},
            {"role": "user", "content": f"## Problem\n{problem}\n\n## Constraints\n{constraints}\n\nGenerate {count} distinct ideas." if constraints else f"## Problem\n{problem}\n\nGenerate {count} distinct ideas."}
        ]
        response = await client.chat.completions.create(
            model=config.get("model", "glm-4-plus"),
            messages=messages,
            temperature=0.9,
            max_tokens=config.get("max_tokens", 4096),
        )
        return response.choices[0].message.content

    return app
