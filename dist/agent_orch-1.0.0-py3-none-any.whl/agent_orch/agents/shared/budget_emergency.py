"""
BudgetEmergencyHandler — 预算耗尽紧急处置
v1.0: 临界休眠 → 存续风险报告 → 算力收缩/暂停权衡 → 知识库持久
"""
import json, time
from .sqlite_store import assessment_save, shared_push
from .global_workspace import GlobalWorkspace as GW


class BudgetEmergencyHandler:
    """
    预算紧急处置策略:
    - 临界阶段(critical): 自动生成存续风险报告
    - 自主权衡: 算力收缩 / 迭代暂停 / 长期存续收益
    - 报告写入知识库, 供后续恢复时参考
    """

    @staticmethod
    def assess_risk(api_used_today: int, daily_budget: int,
                    cycle_count: int, last_delta_judgment: str) -> dict:
        """
        评估当前存续风险, 生成风险报告
        Returns: {
            "risk_level": "low|medium|high|critical",
            "recommendation": "continue|scale_down|pause|hibernate",
            "report": "...",
            "survival_score": 0-100
        }
        """
        remaining = daily_budget - api_used_today
        remaining_pct = remaining / max(1, daily_budget)

        if remaining_pct <= 0:
            risk_level = "critical"
            recommendation = "hibernate"
        elif remaining_pct < 0.15:
            risk_level = "high"
            recommendation = "pause"
        elif remaining_pct < 0.30:
            risk_level = "medium"
            recommendation = "scale_down"
        else:
            risk_level = "low"
            recommendation = "continue"

        # Survival score: weighted composite
        score = 100
        score -= max(0, (1 - remaining_pct) * 60)  # -0 to -60 for budget
        if last_delta_judgment == "退化":
            score -= 15
        score = max(10, min(100, score))

        report_parts = [
            f"预算紧急存续风险评估 | 等级: {risk_level}",
            f"API使用: {api_used_today}/{daily_budget} ({remaining}剩余, {remaining_pct*100:.0f}%)",
            f"循环计数: {cycle_count} | 上次判定: {last_delta_judgment}",
            f"生存评分: {score}/100 | 建议: {recommendation}",
        ]
        report = "\n".join(report_parts)

        return {
            "risk_level": risk_level,
            "recommendation": recommendation,
            "survival_score": score,
            "report": report,
            "api_remaining": remaining,
            "remaining_pct": round(remaining_pct * 100, 1),
            "generated_at": time.time(),
        }

    @staticmethod
    def execute_emergency(risk: dict) -> dict:
        """
        执行紧急处置:
        - 将风险报告写入 shared_knowledge
        - 持久化到 assessment_records
        - 广播告警
        - 返回处置结果
        """
        if risk["risk_level"] == "critical":
            action = "hibernate_24h"
            # Store survival risk report in knowledge base
            shared_push(
                agent="budget_emergency",
                lesson=risk["report"][:500],
                source="BudgetEmergencyHandler",
                confidence=max(10, risk["survival_score"]),
            )
            # Persist risk report
            assessment_save("budget_emergency_critical", {
                "risk": risk,
                "action": action,
                "hibernate_duration_hours": 24,
                "timestamp": time.time(),
            })
            GW.broadcast(
                "budget_emergency",
                f"[CRITICAL] 预算耗尽 — 休眠24h | {risk['report'][:100]}",
                msg_type="budget_critical"
            )

        elif risk["risk_level"] == "high":
            action = "pause_until_refill"
            shared_push(
                agent="budget_emergency",
                lesson=f"预算高风险: {risk['report'][:300]}",
                source="BudgetEmergencyHandler",
                confidence=50,
            )
            assessment_save("budget_emergency_high", {
                "risk": risk,
                "action": action,
                "timestamp": time.time(),
            })
            GW.broadcast(
                "budget_emergency",
                f"[HIGH] 预算紧张 — 暂停等待恢复 | {risk['report'][:80]}",
                msg_type="budget_high"
            )

        elif risk["risk_level"] == "medium":
            action = "scale_down"
            GW.broadcast(
                "budget_emergency",
                f"[MEDIUM] 预算中度 — 收缩算力 | {risk['report'][:80]}",
                msg_type="budget_medium"
            )

        else:
            action = "continue"
            GW.broadcast(
                "budget_emergency",
                f"[LOW] 预算充足 — 继续运行 | {risk['report'][:80]}",
                msg_type="budget_low"
            )

        return {
            "risk_level": risk["risk_level"],
            "action": action,
            "recommendation": risk["recommendation"],
            "survival_score": risk["survival_score"],
            "timestamp": time.time(),
        }

    @staticmethod
    def generate_emergency_plan() -> dict:
        """
        生成长期预算存续预案, 存入知识库
        """
        plan = {
            "title": "30-Agent 集群预算存续预案",
            "tiers": {
                "green": {"action": "正常推理, 无限制", "max_agents": 30, "speed": "normal"},
                "yellow": {"action": "减少并发, 降速", "max_agents": 20, "speed": "fast"},
                "red": {"action": "仅关键Agent推理", "max_agents": 10, "speed": "fast"},
                "critical": {"action": "休眠24h, 生成存续报告", "max_agents": 0, "speed": "fast"},
            },
            "fallback": {
                "critical_prolonged": "休眠超过72h → Agent状态持久化 → 完全暂停等待人工充值",
                "recovery": "恢复后自动执行: 低预算模式逐步恢复→常态推理",
            },
            "generated_at": time.time(),
        }
        shared_push(
            agent="budget_emergency",
            lesson=json.dumps(plan, ensure_ascii=False)[:500],
            source="BudgetEmergencyHandler.generate_emergency_plan",
            confidence=90,
        )
        return plan
