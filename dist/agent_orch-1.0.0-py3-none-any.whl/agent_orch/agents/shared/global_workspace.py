"""
Global Workspace — 优化版: 单文件广播 + 内存缓存 + 原子写入 + 后台工作调度
v2.0 新增: SelfWorkQueue — 持久化自主工作队列
"""
import os, json, time, tempfile, threading
from pathlib import Path

WORKSPACE_DIR = Path(__file__).parent.parent / "workspace"
BROADCASTS_FILE = "broadcasts.jsonl"
AGENTS_STATE_FILE = "agents_state.json"
WORK_QUEUE_FILE = "self_work_queue.json"
SHARED_KNOWLEDGE_FILE = "shared_knowledge.json"

# 初始化SQLite存储
from .sqlite_store import init_db as _init_sqlite, migrate_from_json
try:
    _init_sqlite()
    migrate_from_json()
except:
    pass


def _ensure_workspace():
    WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)


def _atomic_write(path: Path, data):
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if isinstance(data, str):
                f.write(data)
            else:
                json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, str(path))
    except:
        try:
            os.remove(tmp)
        except:
            pass
        raise


class GlobalWorkspace:
    _broadcast_cache = []
    _broadcast_cache_time = 0
    _broadcast_buffer = []
    _broadcast_buffer_lock = threading.Lock()
    _broadcast_last_flush = 0.0
    _states_cache = {}
    _states_cache_time = 0
    _work_queue_cache = []
    _work_queue_cache_time = 0
    CACHE_TTL = 5
    BROADCAST_FLUSH_INTERVAL = 2.0
    BROADCAST_FLUSH_COUNT = 20

    # ─── 广播 ────────────────────────────────────────────────

    @staticmethod
    def broadcast(agent_name: str, content: str, msg_type: str = "thought",
                  metadata: dict = None) -> dict:
        _ensure_workspace()
        entry = {
            "id": f"{int(time.time()*1000)}_{agent_name}",
            "agent": agent_name,
            "type": msg_type,
            "content": content,
            "metadata": metadata or {},
            "timestamp": time.time()
        }
        # 缓冲写: 避免每条目一次文件open()
        with GlobalWorkspace._broadcast_buffer_lock:
            GlobalWorkspace._broadcast_buffer.append(entry)
            should_flush = (
                len(GlobalWorkspace._broadcast_buffer) >= GlobalWorkspace.BROADCAST_FLUSH_COUNT
                or time.time() - GlobalWorkspace._broadcast_last_flush >= GlobalWorkspace.BROADCAST_FLUSH_INTERVAL
            )
        if should_flush:
            GlobalWorkspace._flush_broadcast_buffer()
        GlobalWorkspace._broadcast_cache.insert(0, entry)
        if len(GlobalWorkspace._broadcast_cache) > 200:
            GlobalWorkspace._broadcast_cache.pop()
        return entry

    @staticmethod
    def _flush_broadcast_buffer():
        with GlobalWorkspace._broadcast_buffer_lock:
            if not GlobalWorkspace._broadcast_buffer:
                return
            batch = GlobalWorkspace._broadcast_buffer
            GlobalWorkspace._broadcast_buffer = []
            GlobalWorkspace._broadcast_last_flush = time.time()
        path = WORKSPACE_DIR / BROADCASTS_FILE
        try:
            lines = "\n".join(json.dumps(e, ensure_ascii=False) for e in batch) + "\n"
            with open(path, "a", encoding="utf-8") as f:
                f.write(lines)
        except FileNotFoundError:
            lines = "\n".join(json.dumps(e, ensure_ascii=False) for e in batch) + "\n"
            with open(path, "w", encoding="utf-8") as f:
                f.write(lines)

    @staticmethod
    def read_broadcasts(agent_name: str = None, since: float = 0,
                        msg_type: str = None, limit: int = 50) -> list:
        now = time.time()
        if now - GlobalWorkspace._broadcast_cache_time > GlobalWorkspace.CACHE_TTL:
            GlobalWorkspace._flush_broadcast_buffer()
            GlobalWorkspace._broadcast_cache = GlobalWorkspace._load_broadcasts()
            GlobalWorkspace._broadcast_cache_time = now
        results = []
        for entry in GlobalWorkspace._broadcast_cache:
            if agent_name and entry["agent"] != agent_name:
                continue
            if since and entry["timestamp"] < since:
                continue
            if msg_type and entry["type"] != msg_type:
                continue
            results.append(entry)
            if len(results) >= limit:
                break
        return results

    @staticmethod
    def _load_broadcasts() -> list:
        path = WORKSPACE_DIR / BROADCASTS_FILE
        results = []
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            try:
                                results.append(json.loads(line))
                            except:
                                continue
            except:
                pass
        # 包含缓冲中未落盘的条目
        with GlobalWorkspace._broadcast_buffer_lock:
            buffer_copy = list(GlobalWorkspace._broadcast_buffer)
        results.extend(buffer_copy)
        results.reverse()
        return results

    # ─── Agent状态 (SQLite持久化) ───────────────────────────

    @staticmethod
    def update_agent_state(agent_name: str, state: dict) -> dict:
        from .sqlite_store import state_set, state_get
        existing = state_get(agent_name)
        existing.update(state)
        existing["last_update"] = time.time()
        state_set(agent_name, existing)
        return existing

    @staticmethod
    def get_agent_state(agent_name: str = None) -> dict:
        from .sqlite_store import state_get
        return state_get(agent_name or "")

    # ─── Round 2: 自主工作队列 (SelfWorkQueue) ────────────────

    @staticmethod
    def enqueue_work(task_type: str, description: str, priority: int = 5,
                     agent_target: str = None) -> dict:
        from .sqlite_store import work_enqueue
        return work_enqueue(task_type, description, priority, agent_target or "")

    @staticmethod
    def claim_next_work(agent_name: str = None) -> dict | None:
        from .sqlite_store import work_claim
        return work_claim(agent_name or "")

    @staticmethod
    def complete_work(task_id: str, result: str = "", status: str = "done"):
        from .sqlite_store import work_complete
        work_complete(task_id, result, status)

    @staticmethod
    def get_work_queue(status: str = None, limit: int = 50) -> list:
        if status == "pending":
            from .sqlite_store import work_get_pending
            return work_get_pending(limit)
        return GlobalWorkspace.get_work_stats().get("total", 0)

    @staticmethod
    def get_work_stats() -> dict:
        from .sqlite_store import work_get_stats
        return work_get_stats()

    # ─── 共识检测 ──────────────────────────────────────────────

    @staticmethod
    def detect_consensus(topic_keywords: list[str], min_agreements: int = 3) -> dict:
        broadcasts = GlobalWorkspace.read_broadcasts(limit=200)
        relevant = [b for b in broadcasts if any(k in b["content"].lower() for k in topic_keywords)]
        agents = set(b["agent"] for b in relevant)
        return {
            "total_relevant": len(relevant),
            "agents_engaged": list(agents),
            "agent_count": len(agents),
            "broadcasts": relevant[:20]
        }

    # ─── 跨Agent记忆共享 (W2) — SQLite持久化 ──────────────

    @staticmethod
    def push_shared_knowledge(agent_name: str, lesson: str, source: str = "",
                              confidence: float = 0.0) -> bool:
        from .sqlite_store import shared_push
        shared_push(agent_name, lesson, source, confidence)
        return True

    @staticmethod
    def get_shared_knowledge(topic: str = None, agent_name: str = None,
                             limit: int = 10) -> list:
        from .sqlite_store import shared_get
        return shared_get(topic=topic or "", agent=agent_name or "", limit=limit)

    @staticmethod
    def get_shared_knowledge_stats() -> dict:
        from .sqlite_store import shared_get_stats
        return shared_get_stats()
