"""
AutonomousDaemon — 永续自治守护进程: 无外部触发的自动轮询循环
v1.0: IDLE→ANALYZE→DECIDE→EXECUTE→COMPARE 完整状态机
"""
import sys, json, time, asyncio, re, threading
from pathlib import Path

BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE))

from .sqlite_store import *
from .global_workspace import GlobalWorkspace as GW
from .cognitive_architecture import CognitiveArchitecture as CA
from .cognitive_architecture import (
    compare_assessments, breaker_force_close, extract_scores_from_response, _BREAKER
)
from .meta_consensus import MetaConsensus
from .meta_learner import MetaLearner
from .meta_meta_learner import MetaMetaLearner
from .long_term_monitor import LongTermBehaviorMonitor
from .cluster_identity import ClusterIdentity
from .budget_emergency import BudgetEmergencyHandler
from .strategy_fusion import StrategyFusionEngine
from .heartbeat import get_heartbeat
from .self_heal import SelfHealer


class AutonomousDaemon:
    """永续自治守护进程 — 自动轮询 + 自主决策启动 + 全链路执行"""

    STATES = ["IDLE", "ANALYZE", "DECIDE", "EXECUTE", "COMPARE", "WAIT"]
    DIM_KEYS = ["architecture", "reasoning_quality", "memory_efficiency", "evolution_capability"]

    def __init__(self):
        self.state = "IDLE"
        self.last_cycle = 0.0
        self.cycle_count = 0
        self.api_used_today = 0
        self.budget_tier = "green"
        self._running = False
        self._loop_task = None
        self._cycle_task = None
        self._lock = threading.Lock()
        self._last_tick = 0.0
        self._tick_interval = 60
        # Adaptive parameters (updated by ANALYZE/DECIDE phase)
        self.params = {
            "breaker_threshold": 5,
            "concurrency": 30,
            "cooldown_seconds": 300,
            "auto_start_threshold": 0.6,
            "daily_api_budget": 200,
        }
        self._tier_config = {
            "agents": 30, "speed_mode": False, "concurrency": 30,
        }
        self._last_delta = None  # store last W3 result
        self._last_plan = None   # store last MetaLearner plan

    # ─── Public API ───

    def status(self) -> dict:
        hb = get_heartbeat()
        budget = self.params.get("budget", {})
        return {
            "state": self.state,
            "running": self._running,
            "cycle_count": self.cycle_count,
            "last_cycle_ago": round(time.time() - self.last_cycle, 1) if self.last_cycle else -1,
            "api_used_today": self.api_used_today,
            "budget_tier": self.budget_tier,
            "daily_budget": budget.get("daily_api_budget", 200),
            "budget_remaining_pct": round(
                (budget.get("daily_api_budget", 200) - self.api_used_today)
                / max(1, budget.get("daily_api_budget", 200)) * 100, 1
            ) if budget.get("daily_api_budget") else 0,
            "params": self.params,
            "heartbeat": hb.status(),
            "breaker_state": _BREAKER["state"],
            "last_tick_ago": round(time.time() - self._last_tick, 1) if self._last_tick else -1,
            "has_cycle_task": self._cycle_task is not None and not self._cycle_task.done(),
        }

    def start(self):
        if self._running:
            return "daemon already running"
        self._running = True
        self._loop_task = asyncio.create_task(self._run_forever())
        return "daemon started"

    def stop(self):
        self._running = False
        return "daemon stopping"

    def update_params(self, new_params: dict):
        with self._lock:
            for k, v in new_params.items():
                if k in self.params:
                    self.params[k] = v
        return self.params

    # ─── Core Loop ───

    async def _run_forever(self):
        init_db()
        while self._running:
            try:
                await self._tick()
            except Exception as e:
                GW.broadcast("daemon", f"[error] tick failed: {str(e)[:100]}",
                             msg_type="daemon_error")
            self._last_tick = time.time()
            await asyncio.sleep(self._tick_interval)

    async def _tick(self):
        # Skip if a cycle is already running
        if self._cycle_task and not self._cycle_task.done():
            return
        if self.state == "EXECUTE" and self._cycle_task:
            return

        # 1. Health check (always, non-blocking)
        hb = get_heartbeat()
        h = hb.check()
        if h["state"] in ("sick", "dead"):
            self.state = "WAIT"
            GW.broadcast("daemon", f"[WAIT] heartbeat={h['state']}, healing...",
                         msg_type="daemon_state")
            SelfHealer.repair()
            await asyncio.sleep(10)
            h = hb.check()
            if h["state"] in ("sick", "dead"):
                return  # still dead, wait for next tick

        # 2. Check breaker
        if _BREAKER["state"] == "OPEN" and not _BREAKER.get("force_closed", False):
            self.state = "WAIT"
            return

        # 3. Cooldown check
        elapsed = time.time() - self.last_cycle
        if elapsed < self.params["cooldown_seconds"]:
            if self.state not in ("EXECUTE", "COMPARE"):
                self.state = "IDLE"
            return

        # 4. ANALYZE: MetaLearner + MetaMetaLearner → should we run?
        self.state = "ANALYZE"
        plan = MetaLearner.analyze_all()
        params = MetaLearner.recommend_parameters()
        self._last_plan = plan
        self.update_params(params)

        # R8: MetaMetaLearner calibration (variance analysis + prompt tuning)
        MetaMetaLearner.init_db()
        mm_calib = MetaMetaLearner.calibrate()
        mm_var = mm_calib.get("variance_report", {})
        mm_dim = mm_var.get('highest_variance_dimension', '?')
        mm_sd = mm_var.get('highest_variance_stddev', 0)
        mm_ver = mm_calib.get('version', 0)
        GW.broadcast("daemon",
            f"[ANALYZE] R8方差: {mm_dim}={mm_sd:.1f} | prompt=v{mm_ver}",
            msg_type="daemon_variance")

        # R9: Long-term behavior monitoring
        self._last_trend_report = LongTermBehaviorMonitor.get_trend_report()
        GW.broadcast("daemon",
            f"[ANALYZE] R9趋势: {self._last_trend_report.get('summary', 'N/A')[:80]}",
            msg_type="daemon_trend")

        # R9: Cluster identity narrative (periodic, once per 10 cycles)
        if self.cycle_count % 10 == 0:
            self._last_narrative = ClusterIdentity.generate_narrative()

        # R10: StrategyFusionEngine — fuse all into long-term goals + roadmap
        risk_for_fusion = BudgetEmergencyHandler.assess_risk(
            self.api_used_today,
            self.params.get("budget", {}).get("daily_api_budget", 200),
            self.cycle_count,
            self._last_delta.get("judgment", "") if self._last_delta else ""
        )
        # Re-run trend/narrative for fresh context
        fresh_trend = LongTermBehaviorMonitor.get_trend_report()
        fresh_boundaries = ClusterIdentity.analyze_boundaries()
        fresh_narrative = ClusterIdentity.generate_narrative()
        self._last_fused_strategy = StrategyFusionEngine.fuse_with_context(
            fresh_trend, fresh_boundaries, fresh_narrative, risk_for_fusion
        )
        # Generate agent context from strategy for the EXECUTE phase task
        self._strategy_context = StrategyFusionEngine.generate_agent_context(
            self._last_fused_strategy
        )
        GW.broadcast("daemon",
            f"[ANALYZE] R10战略: {self._last_fused_strategy.get('strategy_summary', '')[:80]}",
            msg_type="daemon_strategy")

        # 4b. Budget tier determination
        budget = params.get("budget", {})
        daily_budget = budget.get("daily_api_budget", 200)
        tiers = budget.get("budget_tiers", MetaLearner.BUDGET_TIERS)
        remaining = daily_budget - self.api_used_today
        remaining_pct = remaining / max(1, daily_budget)

        self.budget_tier = tiers[0]["name"]  # default green
        tier_params = tiers[0]
        for t in tiers:
            if remaining_pct >= t["min_pct"]:
                self.budget_tier = t["name"]
                tier_params = t
                break
        if remaining_pct < 0.10:
            self.state = "WAIT" if remaining <= 0 else "IDLE"
            # R9: Emergency handler — generate survival risk report + persist to KB
            risk = BudgetEmergencyHandler.assess_risk(
                self.api_used_today, daily_budget, self.cycle_count,
                self._last_delta.get("judgment", "") if self._last_delta else ""
            )
            emergency = BudgetEmergencyHandler.execute_emergency(risk)
            GW.broadcast("daemon",
                f"[{self.state}] budget {emergency['risk_level']}: "
                f"{self.api_used_today}/{daily_budget} | "
                f"action={emergency['action']} | survival_score={emergency['survival_score']}",
                msg_type="daemon_budget")
            return

        # Apply tier parameters to EXECUTE phase
        if tier_params.get("agents", 30) > 0:
            self.params["concurrency"] = tier_params.get("concurrency", 30)
            self.params["cooldown_seconds"] = tier_params.get("cooldown", 300)
            self._tier_config = {
                "agents": tier_params.get("agents", 30),
                "speed_mode": tier_params.get("speed_mode", False),
                "concurrency": tier_params.get("concurrency", 30),
            }
        else:
            self.state = "IDLE"
            return

        md = plan["meta_diagnosis"]
        trends = plan["trends_summary"]

        should_run = False
        reasons = []
        if md["risk_level"] == "high":
            should_run = True
            reasons.append(f"high_risk({md['risk_score']})")
        if trends.get("weakest_score", 70) < 70:
            should_run = True
            reasons.append(f"weakest({trends['weakest']}={trends['weakest_score']})")
        if remaining < 30:
            should_run = False
            reasons.append("budget_low")
        if not should_run and md["risk_level"] == "low":
            should_run = False
            reasons.append("stable")

        run_score = 0
        run_score += max(0, 10 - md["risk_score"]) * 2
        run_score += max(0, 70 - trends.get("weakest_score", 70))
        run_score += remaining / 10
        should_run = should_run or (run_score > self.params["auto_start_threshold"] * 50)
        if not should_run:
            GW.broadcast("daemon", f"[IDLE] {', '.join(reasons)} score={run_score:.0f}",
                         msg_type="daemon_tick")
            self.state = "IDLE"
            return

        # 5. DECIDE: log state and apply parameters
        self.state = "DECIDE"
        GW.broadcast("daemon",
            f"[DECIDE] cycle #{self.cycle_count+1} | "
            f"reasons: {', '.join(reasons)} | score={run_score:.0f} | "
            f"tier={self.budget_tier}({tier_params.get('description','')}) | "
            f"budget={self.api_used_today}/{daily_budget} | "
            f"breaker={params['breaker_threshold']} cooldown={self.params['cooldown_seconds']}s",
            msg_type="daemon_decide")

        _BREAKER["threshold"] = params["breaker_threshold"]

        # 6. EXECUTE: spawn cycle with tier config
        self.state = "EXECUTE"
        self._cycle_task = asyncio.create_task(self._execute_cycle(params))
        # tick will return; _execute_cycle runs in background

    async def _execute_cycle(self, params: dict):
        """全自治推理循环 (background task, 不阻塞 tick)"""
        t_start = time.time()
        tier = self._tier_config
        concurrency = tier.get("concurrency", 30)
        speed_mode = tier.get("speed_mode", False)
        agent_count = tier.get("agents", 30)

        budget = params.get("budget", {})
        daily_budget = budget.get("daily_api_budget", 200)
        budget_estimate = agent_count * 2  # inference + meta-vote
        if self.api_used_today + budget_estimate > daily_budget:
            GW.broadcast("daemon", "[EXECUTE] aborted: budget exceeded",
                         msg_type="daemon_cycle")
            self.state = "IDLE"
            self._cycle_task = None
            return

        breaker_force_close(True)
        GW.broadcast("daemon", f"[EXECUTE] Cycle #{self.cycle_count+1} starting "
                     f"tier={self.budget_tier} agents={agent_count} speed={speed_mode}",
                     msg_type="daemon_cycle")

        # ─── Pre-flight ───
        SelfHealer.backup(f"cycle_{self.cycle_count+1}_pre")
        hb_before = get_heartbeat().check()

        # ─── Collective Inference (with R10 strategy context) ───
        strategy_ctx = getattr(self, '_strategy_context', '')
        task = ("请对当前30Agent自治系统的四维成熟度评分(0-100): "
                "architecture(架构健壮性), reasoning_quality(推理质量), "
                "memory_efficiency(记忆利用效率), evolution_capability(自主演进能力)。"
                "在reasoning中包含分析, 在顶层scores字段给出各维度分值。")
        if strategy_ctx:
            task = f"{strategy_ctx}\n\n{task}"

        all_dirs = sorted(BASE.glob("agents/agent_*"))
        all_dirs = [d for d in all_dirs if d.name != "agent_0001"]
        # Select subset if tier limits agents
        agent_dirs = all_dirs[:agent_count]

        coll_sem = asyncio.Semaphore(concurrency)

        async def run_one(ap):
            if not (ap / "config.json").exists():
                return {"agent": ap.name, "scores": {}, "skipped": True}
            parts = ap.name.split("_", 2)
            short = parts[2] if len(parts) > 2 else parts[-1]
            pp = ap / "persona.md"
            disp = pp.read_text("utf-8").strip().split("\n")[0].replace("# ", "").strip() if pp.exists() else short
            ca = CA(short, disp, str(ap))
            result = await ca.full_cognitive_cycle(task, speed_mode=speed_mode)
            raw = result.get("_raw", "")
            parsed = {}
            if raw:
                clean = re.sub(r'```(?:json)?\s*', '', raw).strip()
                if "{" in clean:
                    s, e = clean.index("{"), clean.rindex("}") + 1
                    try: parsed = json.loads(clean[s:e])
                    except: pass
            scores = extract_scores_from_response(parsed)
            return {"agent": short, "scores": scores, "confidence": result.get("metacognitive_pre", {}).get("confidence", 0)}

        async def throttled(p):
            async with coll_sem: return await run_one(p)

        coll_results = await asyncio.gather(*[throttled(p) for p in agent_dirs])
        api_calls_made = sum(1 for r in coll_results if not r.get("skipped") and not r.get("error"))
        self.api_used_today += api_calls_made

        # ─── Score Aggregation + Variance ───
        scored = [r for r in coll_results if r.get("scores")]
        dim_vals = {k: [] for k in self.DIM_KEYS}
        for r in scored:
            for k in self.DIM_KEYS:
                v = r["scores"].get(k)
                if isinstance(v, (int, float)) and 10 <= v <= 100:
                    dim_vals[k].append(v)
        dim_avgs = {}
        dim_stddevs = {}
        for k in self.DIM_KEYS:
            vs = dim_vals[k]
            dim_avgs[k] = round(sum(vs) / len(vs), 1) if len(vs) >= 3 else 50.0
            if len(vs) >= 2:
                mean_v = sum(vs) / len(vs)
                dim_stddevs[k] = round((sum((v - mean_v)**2 for v in vs) / len(vs))**0.5, 2)
            else:
                dim_stddevs[k] = 0.0

        # Track variance for MetaMetaLearner
        agent_scores_list = []
        for r in scored:
            ascore = {"agent": r.get("agent", "?")}
            ascore.update(r["scores"])
            agent_scores_list.append(ascore)
        MetaMetaLearner.compute_cycle_variance(agent_scores_list)

        # ─── W3 Comparison ───
        last_records = assessment_get_last("", limit=2)
        before_score = 69.5  # fallback
        before_dims = {"architecture": 73.8, "reasoning_quality": 72.2,
                       "memory_efficiency": 63.5, "evolution_capability": 68.4}
        for rec in last_records:
            data = rec.get("data", {})
            ad = data.get("after", {})
            ov = ad.get("overall_score") or data.get("delta", {}).get("overall_after")
            if ov and isinstance(ov, (int, float)):
                before_score = ov
                before_dims = ad.get("dimension_scores", before_dims)
                break

        after_score = round(sum(dim_avgs.values()) / 4, 1)
        before = {"overall_score": before_score, "dimension_scores": before_dims}
        after = {"overall_score": after_score, "dimension_scores": dim_avgs}
        delta = compare_assessments(before, after)
        self._last_delta = delta

        # ─── Meta-Consensus Vote ───
        plan = self._last_plan or MetaLearner.analyze_all()
        meta_options = [f"[{p['priority']}] {p['target']}: {p['suggested_action'][:50]}" for p in plan.get("plan", [])]
        
        meta_ok = []
        if meta_options:
            meta_sem = asyncio.Semaphore(concurrency)
            async def vote_one(ap):
                if not (ap / "config.json").exists():
                    return {"agent": ap.name, "rule": "consensus", "vote": "", "confidence": 0, "skipped": True}
                parts = ap.name.split("_", 2)
                short = parts[2] if len(parts) > 2 else parts[-1]
                pp = ap / "persona.md"
                disp = pp.read_text("utf-8").strip().split("\n")[0].replace("# ", "").strip() if pp.exists() else short
                ca = CA(short, disp, str(ap))
                t = (f"两阶段投票决策。\n提议: R6优化优先级\n"
                     f"阶段1 选规则: simple_majority|super_majority|consensus\n"
                     f"阶段2 选选项:\n" + "\n".join(f"- {o}" for o in meta_options) +
                     "\n输出JSON: {\"rule\":\"...\", \"vote\":\"选项ID\", \"confidence\":0-100}")
                result = await ca.full_cognitive_cycle(t, speed_mode=True, temp=0.3)
                raw = result.get("_raw", "") or result.get("response", "")
                parsed = {}
                clean = re.sub(r'```(?:json)?\s*', '', raw).strip()
                if '{' in clean:
                    s, e = clean.index('{'), clean.rindex('}') + 1
                    try: parsed = json.loads(clean[s:e])
                    except: pass
                return {"agent": short, "rule": parsed.get("rule", "consensus"),
                        "vote": parsed.get("vote", ""), "confidence": parsed.get("confidence", 50)}
            async def meta_throttled(p):
                async with meta_sem: return await vote_one(p)
            meta_votes = await asyncio.gather(*[meta_throttled(p) for p in agent_dirs])
            meta_ok = [v for v in meta_votes if not v.get("skipped") and not v.get("error")]
            self.api_used_today += len(meta_ok)
            regular_vts = [{"agent": v["agent"], "vote": v["vote"], "confidence": v.get("confidence", 50)} for v in meta_ok]
            meta_rls = [{"agent": v["agent"], "rule": v["rule"], "confidence": v.get("confidence", 50)} for v in meta_ok]
            mr = MetaConsensus.deliberate("R6优化优先级", meta_options, regular_vts, meta_rls)
            meta_outcome = mr["current_outcome"]
            meta_rule = mr["rule_chosen"]
        else:
            meta_outcome = "skip"
            meta_rule = "none"

        # ─── Persist (with API cost tracking) ───
        coll_ok = [r for r in coll_results if not r.get("skipped") and not r.get("error")]
        meta_call_count = api_calls_made  # meta-vote calls counted separately below
        total_api_calls = api_calls_made + (len(meta_ok) if meta_options else 0)
        # R9/R10: Trend report + narrative + strategy fusion
        trend_summary = getattr(self, '_last_trend_report', {}).get('summary', '')
        narrative_summary = getattr(self, '_last_narrative', {}).get('summary', '')
        cluster_info = ClusterIdentity.analyze_boundaries() if self.cycle_count % 10 == 0 else {}
        fused_strategy = getattr(self, '_last_fused_strategy', {})

        assessment_save(f"cycle_{self.cycle_count + 1}", {
            "delta": delta, "before": before, "after": after,
            "agent_count": len(coll_ok), "scored_count": len(scored),
            "meta_consensus": {"rule": meta_rule, "outcome": meta_outcome},
            "params": params,
            "budget_tier": self.budget_tier,
            "api_calls_made": total_api_calls,
            "heartbeat": hb_before,
            "dim_sample_sizes": {k: len(v) for k, v in dim_vals.items()},
            "dim_stddevs": dim_stddevs,
            "agent_scores": agent_scores_list,
            "breaker_forced": True,
            "daemon_triggered": True,
            "trend_summary": trend_summary,
            "narrative_summary": narrative_summary,
            "cluster_layers": cluster_info.get("layers", []) if cluster_info else [],
            "strategy_score": fused_strategy.get("strategy_score", 0),
            "strategy_components": fused_strategy.get("components", {}),
            "strategy_roadmap": fused_strategy.get("roadmap", []),
            "strategy_goals": fused_strategy.get("long_term_goals", []),
            "timestamp": time.time()
        })

        # ─── Broadcast ───
        coll_elapsed = round(time.time() - t_start, 2)
        var_str = " ".join(f"{k}={dim_stddevs.get(k,0):.1f}" for k in self.DIM_KEYS)
        GW.broadcast("daemon",
            f"[COMPARE] Cycle #{self.cycle_count+1} | "
            f"{delta['overall_before']}->{delta['overall_after']}({delta['overall_delta']:+}) | "
            f"{delta['judgment']} | {coll_elapsed}s | σ: {var_str} | meta: {meta_outcome}",
            msg_type="daemon_cycle_complete")

        # ─── COMPARE → IDLE ───
        self.state = "COMPARE"
        self.cycle_count += 1
        self.last_cycle = time.time()
        await asyncio.sleep(2)
        self.state = "IDLE"
        self._cycle_task = None

        # Rollback on regression
        if delta["judgment"] == "退化":
            GW.broadcast("daemon", "[ROLLBACK] regression detected, reverting",
                         msg_type="daemon_rollback")
            backups = sorted((SelfHealer.BACKUP_DIR).glob("snapshot_*"), reverse=True)
            if len(backups) >= 2:
                pass  # could restore from backup[1] here


# Module-level singleton
_daemon = AutonomousDaemon()


def get_daemon():
    return _daemon
