"""
Phase 4: 动态负载均衡器 — 30个Agent自动调度
集体自我诊断出的 #1 需求: 闲置Agent自动分配任务
"""
import json, os, time, random
from pathlib import Path

BASE = Path(r"E:\root\doubao")

# 加载集体推理结果中的置信度数据作为初始基线
try:
    results_file = BASE / "agents" / "workspace" / "collective_full.json"
    results = json.loads(results_file.read_text(encoding="utf-8"))
    agent_performance = {
        r["agent"]: {
            "confidence": r.get("confidence", 50),
            "quality": r.get("quality", "中"),
            "task_level": r.get("task_level", "?"),
            "load": 0,  # 当前负载 (并发任务数)
            "total_tasks": 0,
            "avg_latency": 0,
            "last_active": 0,
        } for r in results
    }
except:
    agent_performance = {}


class DynamicScheduler:
    def __init__(self):
        self.agents = agent_performance.copy()
        self._lock = False

    def get_available(self, needed=1):
        """获取当前最空闲的N个Agent"""
        sorted_agents = sorted(self.agents.items(),
                               key=lambda x: (x[1]["load"], -x[1]["confidence"]))
        return [name for name, _ in sorted_agents[:needed]]

    def assign(self, agent_name):
        """标记Agent为忙碌"""
        if agent_name in self.agents:
            self.agents[agent_name]["load"] += 1
            self.agents[agent_name]["total_tasks"] += 1
            self.agents[agent_name]["last_active"] = time.time()

    def complete(self, agent_name, latency=0, confidence=0):
        """标记Agent为空闲, 更新性能数据"""
        if agent_name in self.agents:
            a = self.agents[agent_name]
            a["load"] = max(0, a["load"] - 1)
            a["avg_latency"] = (a["avg_latency"] * (a["total_tasks"] - 1) + latency) / max(a["total_tasks"], 1)
            if confidence > 0:
                a["confidence"] = int((a["confidence"] * 0.7 + confidence * 0.3))

    def status_report(self):
        """生成负载报告"""
        total_load = sum(a["load"] for a in self.agents.values())
        active = sum(1 for a in self.agents.values() if a["load"] > 0)
        idle = len(self.agents) - active
        report = {
            "total_agents": len(self.agents),
            "active": active,
            "idle": idle,
            "total_concurrent_load": total_load,
            "avg_confidence": sum(a["confidence"] for a in self.agents.values()) / max(len(self.agents), 1),
            "agents": {
                name: {
                    "load": a["load"],
                    "confidence": a["confidence"],
                    "total_tasks": a["total_tasks"],
                    "avg_latency": round(a["avg_latency"], 1),
                }
                for name, a in sorted(self.agents.items(),
                                      key=lambda x: -x[1]["load"])
            }
        }
        return report


# 测试调度器
scheduler = DynamicScheduler()
print("=" * 60)
print("动态负载均衡器 v1 初始化完成")
print("=" * 60)
report = scheduler.status_report()
print(f"   30个Agent, 当前活跃: {report['active']}, 空闲: {report['idle']}")
print(f"   平均置信度: {report['avg_confidence']:.0f}")
print(f"\n   负载最高的5个Agent:")
for i, (name, data) in enumerate(list(report['agents'].items())[:5]):
    print(f"     {name}: 负载={data['load']} 置信度={data['confidence']} 总任务={data['total_tasks']}")

# 保存调度器状态以备collective_process使用
scheduler_file = BASE / "agents" / "shared" / "_scheduler_state.json"
scheduler_file.write_text(json.dumps({
    "version": "v1",
    "timestamp": time.time(),
    "strategy": "least-loaded-first",
    "description": "自动将任务分配给当前负载最低的Agent",
    "agents": {name: {"load": 0, "confidence": a.get("confidence", 50)}
               for name, a in scheduler.agents.items()}
}, indent=2, ensure_ascii=False), encoding="utf-8")
print(f"\n📦 调度器状态持久化: {scheduler_file}")

# 集成到认知架构: 在cognitive_architecture.py中导入此调度器
print(f"\n🔄 下一步: 在cognitive_architecture.py中集成后自动调度")
print(f"    当前瓶颈是: opencode未重启, 30个MCP未加载")
