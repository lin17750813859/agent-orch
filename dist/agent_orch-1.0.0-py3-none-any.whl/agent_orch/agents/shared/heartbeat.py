"""
Heartbeat Monitor — 心跳检测: 区分 idle 休眠 vs 通道故障
v1.0: 分层健康状态 + 自动恢复 + 调度器集成
"""
import json, time, sqlite3, threading
from pathlib import Path


class HeartbeatMonitor:
    """心跳检测器 — 区分'系统空闲'和'通道故障'"""

    STATES = {
        "healthy":    "API/DB均正常, 系统可用",
        "degraded":   "部分功能异常, 降级运行",
        "sick":       "持续异常, 需干预",
        "dead":       "完全不可用",
    }

    DEGRADE_THRESHOLD = 3      # 连续 3 次异常 → degraded
    SICK_THRESHOLD = 6         # 连续 6 次 → sick
    DEAD_THRESHOLD = 10        # 连续 10 次 → dead
    RECOVER_THRESHOLD = 2      # 连续 2 次成功 → healthy

    def __init__(self):
        self.state = "healthy"
        self.consecutive_failures = 0
        self.consecutive_successes = 0
        self.last_check = 0.0
        self.last_success = 0.0
        self.last_failure = 0.0
        self.failure_log = []
        self._lock = threading.Lock()

    def check(self, db_path: str | Path | None = None) -> dict:
        """执行一次心跳检测

        检测项:
        1. SQLite DB 可读
        2. (可选) API 密钥文件存在
        3. (可选) Agent 目录完整性
        """
        t0 = time.time()
        results = []

        # 1. SQLite DB 检测
        db_ok = False
        try:
            path = Path(db_path) if db_path else Path(__file__).parent.parent / "workspace" / "store.db"
            if path.exists():
                conn = sqlite3.connect(str(path))
                conn.execute("SELECT 1").fetchone()
                conn.close()
                db_ok = True
                results.append({"check": "sqlite_db", "pass": True})
            else:
                results.append({"check": "sqlite_db", "pass": False, "error": "DB不存在"})
        except Exception as e:
            results.append({"check": "sqlite_db", "pass": False, "error": str(e)[:100]})

        # 2. Agent 配置文件检测 (抽样前3个, 跳过 legacy agent_0001)
        config_ok = True
        try:
            base = Path(__file__).parent.parent
            all_agents = sorted(d for d in base.glob("agent_*") if d.name != "agent_0001")
            agents = all_agents[:3]
            for d in agents:
                cfg = d / "config.json"
                if cfg.exists():
                    data = json.loads(cfg.read_text(encoding="utf-8"))
                    if not data.get("api_key", "").strip():
                        config_ok = False
                        results.append({"check": f"config_{d.name}", "pass": False, "error": "API密钥为空"})
                    else:
                        results.append({"check": f"config_{d.name}", "pass": True})
                else:
                    config_ok = False
                    results.append({"check": f"config_{d.name}", "pass": False, "error": "config.json不存在"})
        except Exception as e:
            config_ok = False
            results.append({"check": "agent_configs", "pass": False, "error": str(e)[:100]})

        all_ok = db_ok and config_ok
        elapsed = round(time.time() - t0, 3)

        with self._lock:
            self.last_check = time.time()
            if all_ok:
                self.consecutive_failures = 0
                self.consecutive_successes += 1
                self.last_success = time.time()
                if self.consecutive_successes >= self.RECOVER_THRESHOLD:
                    self.state = "healthy"
            else:
                self.consecutive_failures += 1
                self.consecutive_successes = 0
                self.last_failure = time.time()
                self.failure_log.append({"time": time.time(), "results": results})
                if len(self.failure_log) > 20:
                    self.failure_log = self.failure_log[-20:]
                if self.consecutive_failures >= self.DEAD_THRESHOLD:
                    self.state = "dead"
                elif self.consecutive_failures >= self.SICK_THRESHOLD:
                    self.state = "sick"
                elif self.consecutive_failures >= self.DEGRADE_THRESHOLD:
                    self.state = "degraded"

        return {
            "state": self.state,
            "all_ok": all_ok,
            "db_ok": db_ok,
            "config_ok": config_ok,
            "consecutive_failures": self.consecutive_failures,
            "consecutive_successes": self.consecutive_successes,
            "elapsed_ms": round(elapsed * 1000, 1),
            "checks": results,
            "last_success_ago": round(time.time() - self.last_success, 1) if self.last_success else -1,
            "last_failure_ago": round(time.time() - self.last_failure, 1) if self.last_failure else -1,
        }

    def status(self) -> dict:
        with self._lock:
            return {
                "state": self.state,
                "description": self.STATES.get(self.state, "未知"),
                "consecutive_failures": self.consecutive_failures,
                "consecutive_successes": self.consecutive_successes,
                "last_check_ago": round(time.time() - self.last_check, 1) if self.last_check else -1,
                "last_success_ago": round(time.time() - self.last_success, 1) if self.last_success else -1,
                "last_failure_ago": round(time.time() - self.last_failure, 1) if self.last_failure else -1,
                "failure_count_24h": sum(
                    1 for e in self.failure_log if e["time"] > time.time() - 86400
                ),
            }

    def healthy(self) -> bool:
        return self.state == "healthy"

    def reset(self):
        with self._lock:
            self.state = "healthy"
            self.consecutive_failures = 0
            self.consecutive_successes = 0


# Singleton
_heartbeat = HeartbeatMonitor()


def get_heartbeat():
    return _heartbeat
