"""
MetaMetaLearner — 元元学习层: Agent 集群评分方差分析与系统提示词自主校准
v1.0: 读取全周期评分 → 方差溯源 → 全局 System Prompt 动态生成 → 校准效果追踪
"""
import json, time, math, re
from pathlib import Path
from .sqlite_store import *
from .global_workspace import GlobalWorkspace as GW

DIM_KEYS = ["architecture", "reasoning_quality", "memory_efficiency", "evolution_capability"]

# Default system prompt template (base version, _build_unified_system_prompt in cognitive_architecture.py)
DEFAULT_PROMPT_JSON_SCHEMA = """{
  "metacognitive_pre": {
    "task_level": "事实回忆|逻辑分析|创造生成|价值判断|元反思",
    "knowledge_coverage": "高|中|低",
    "biases_to_watch": ["列出3-5个你的角色视角可能引入的偏差"],
    "confidence": 0-100,
    "quality_factors": ["..."],
    "processing_strategy": "标准|深度|快速"
  },
  "reasoning": "你的完整推理和回答",
  "scores": {
    "architecture": 0-100,
    "reasoning_quality": 0-100,
    "memory_efficiency": 0-100,
    "evolution_capability": 0-100
  },
  "metacognitive_post": {
    "quality_rating": "优|良|中|差",
    "errors_found": ["..."],
    "improvements": ["..."],
    "lessons_learned": ["..."],
    "confidence_update": -20到20
  }
}"""


def _safe_float(v, default=50.0):
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        try:
            return float(v)
        except ValueError:
            return default
    return default


class PromptVersion:
    """Tracking prompt template versions for change log"""
    def __init__(self, version: int, diff_summary: str, rules: list[str],
                 schema: str, trigger: str = ""):
        self.version = version
        self.diff_summary = diff_summary
        self.rules = rules
        self.schema = schema
        self.trigger = trigger
        self.created_at = time.time()

    def to_dict(self):
        return {
            "version": self.version,
            "diff_summary": self.diff_summary,
            "rules": self.rules,
            "schema": self.schema,
            "trigger": self.trigger,
            "created_at": self.created_at,
        }

    def save(self):
        """Persist to prompt_history table"""
        prompt_save(self.to_dict())


class MetaMetaLearner:
    """
    元元学习器:
    1. 聚合 R0-R7 全部评分 → 分析各维度方差
    2. 识别偏离 Agent 及其偏差特征
    3. 生成/校准 system prompt → 减少输出方差
    4. 追踪提示词迭代历史
    """

    # Module-level state
    _current_prompt_version = 0
    _calibrated_schema = DEFAULT_PROMPT_JSON_SCHEMA
    _calibration_rules: list[str] = []
    _last_variance_report: dict = {}
    _variance_history: list[dict] = []

    @staticmethod
    def init_db():
        """Ensure prompt_history table exists"""
        from .sqlite_store import _get_conn
        conn = _get_conn()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS prompt_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                version INTEGER NOT NULL,
                diff_summary TEXT DEFAULT '',
                rules TEXT DEFAULT '[]',
                schema_text TEXT DEFAULT '',
                trigger TEXT DEFAULT '',
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS variance_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cycle_id TEXT NOT NULL,
                dim_name TEXT NOT NULL,
                mean_score REAL DEFAULT 0,
                stddev REAL DEFAULT 0,
                sample_size INTEGER DEFAULT 0,
                created_at REAL NOT NULL
            );
        """)
        conn.commit()

    @staticmethod
    def calibrate() -> dict:
        """
        全量校准管线: 数据采集 → 方差分析 → 提示词生成 → 变更记录
        Returns: {variance_report, prompt_diff, calibration_rules, new_schema}
        """
        MetaMetaLearner.init_db()

        data = MetaMetaLearner._collect_all_scores()
        variance = MetaMetaLearner._analyze_variance(data)
        sources = MetaMetaLearner._identify_variance_sources(variance, data)
        new_schema, rules, diff = MetaMetaLearner._generate_prompt(variance, sources)

        MetaMetaLearner._current_prompt_version += 1
        MetaMetaLearner._calibrated_schema = new_schema
        MetaMetaLearner._calibration_rules = rules
        MetaMetaLearner._last_variance_report = variance

        # Save prompt version
        pv = PromptVersion(
            version=MetaMetaLearner._current_prompt_version,
            diff_summary=diff,
            rules=rules,
            schema=new_schema,
            trigger=f"variance_analysis: {sources.get('primary_driver', 'unknown')}"
        )
        pv.save()

        # Push calibration to cognitive_architecture module
        try:
            from .cognitive_architecture import apply_calibration
            apply_calibration(schema=new_schema, rules=rules, normalize_evolution_cap=True)
        except Exception:
            pass

        # Broadcast
        GW.broadcast("meta_meta_learner",
            f"R8校准: v{MetaMetaLearner._current_prompt_version} | "
            f"{diff} | rules={len(rules)}",
            msg_type="calibration"
        )

        return {
            "variance_report": variance,
            "variance_sources": sources,
            "prompt_diff": diff,
            "calibration_rules": rules,
            "calibrated_schema": new_schema,
            "version": MetaMetaLearner._current_prompt_version,
            "timestamp": time.time(),
        }

    # ─── Phase 1: 全量评分数据采集 ───

    @staticmethod
    def _collect_all_scores() -> dict:
        """
        从 assessment_records 提取所有可用评分.
        每个 assessment 的 data_json 中可能有 'agent_scores' 字段(per-agent),
        否则用 aggregate 'after.dimension_scores' 填充.
        Returns: {dim_name: [score1, score2, ...], ...}
        """
        records = assessment_get_last("", limit=100)
        dim_scores = {d: [] for d in DIM_KEYS}
        dim_scores["overall"] = []
        cycles_found = 0

        for rec in records:
            data = rec.get("data", {})
            after = data.get("after", {})
            agent_scores = data.get("agent_scores", [])
            dim_sample_sizes = data.get("dim_sample_sizes", {})

            if agent_scores and isinstance(agent_scores, list):
                # Per-agent scores available
                for ascore in agent_scores:
                    if not isinstance(ascore, dict):
                        continue
                    for d in DIM_KEYS:
                        v = ascore.get(d)
                        if isinstance(v, (int, float)) and 10 <= v <= 100:
                            dim_scores[d].append(v)
                cycles_found += 1
            else:
                # Only aggregate available — create proxy samples
                dims = after.get("dimension_scores", {})
                overall = after.get("overall_score")
                if isinstance(overall, (int, float)) and overall > 0:
                    dim_scores["overall"].append(overall)
                for d in DIM_KEYS:
                    v = dims.get(d)
                    if isinstance(v, (int, float)) and 10 <= v <= 100:
                        n = dim_sample_sizes.get(d, 5) if dim_sample_sizes else 5
                        dim_scores[d].append(v)
                cycles_found += 1

        # Also pull from assessment delta dimensions
        for rec in records:
            data = rec.get("data", {})
            delta = data.get("delta", {})
            dims = delta.get("dimensions", {})
            for d in DIM_KEYS:
                dd = dims.get(d, {})
                v = dd.get("after")
                if isinstance(v, (int, float)) and 10 <= v <= 100:
                    dim_scores[d].append(v)

        return {
            "dim_scores": dim_scores,
            "record_count": len(records),
            "cycles_with_agent_data": cycles_found,
        }

    # ─── Phase 2: 方差分析 ───

    @staticmethod
    def _analyze_variance(data: dict) -> dict:
        """
        计算每个维度的均值、标准差、样本量, 并做跨维度对比
        """
        dim_scores = data.get("dim_scores", {})
        report = {}
        for d in DIM_KEYS:
            vals = [v for v in dim_scores.get(d, []) if isinstance(v, (int, float))]
            if len(vals) >= 2:
                mean_v = sum(vals) / len(vals)
                variance = sum((v - mean_v)**2 for v in vals) / len(vals)
                stddev = math.sqrt(variance)
                cv = stddev / mean_v if mean_v > 0 else 0  # coefficient of variation
            elif len(vals) == 1:
                mean_v = vals[0]
                stddev = 0.0
                cv = 0.0
            else:
                mean_v = 0.0
                stddev = 0.0
                cv = 0.0
            report[d] = {
                "mean": round(mean_v, 2),
                "stddev": round(stddev, 2),
                "cv": round(cv, 4),
                "n": len(vals),
                "min": round(min(vals), 1) if vals else 0,
                "max": round(max(vals), 1) if vals else 0,
                "range": round(max(vals) - min(vals), 1) if len(vals) >= 2 else 0,
            }

        # Cross-dimension comparison
        sorted_dims = sorted(report.items(), key=lambda x: -x[1]["stddev"])
        highest_variance_dim = sorted_dims[0][0] if sorted_dims else ""
        highest_variance_val = sorted_dims[0][1]["stddev"] if sorted_dims else 0

        return {
            "dimensions": report,
            "highest_variance_dimension": highest_variance_dim,
            "highest_variance_stddev": highest_variance_val,
            "record_count": data.get("record_count", 0),
            "cycles_with_agent_data": data.get("cycles_with_agent_data", 0),
            "timestamp": time.time(),
        }

    @staticmethod
    def _identify_variance_sources(variance: dict, data: dict) -> dict:
        """
        识别方差来源:
        - 哪个维度方差最大
        - 根据趋势推断原因 (prompt wording, reasoning depth, etc.)
        """
        dims = variance.get("dimensions", {})
        sources = {}
        primary = variance.get("highest_variance_dimension", "")
        sources["primary_driver"] = primary
        sources["primary_stddev"] = variance.get("highest_variance_stddev", 0)

        # Per-dimension diagnosis
        diag = {}
        for d in DIM_KEYS:
            r = dims.get(d, {})
            cv = r.get("cv", 0)
            n = r.get("n", 0)
            range_v = r.get("range", 0)

            if cv > 0.15:
                severity = "high"
                likely_cause = "Agent角色偏差: persona差异化导致评分尺度不一致"
            elif cv > 0.08:
                severity = "medium"
                likely_cause = "推理深度差异: 部分Agent过度推理或推理不足"
            else:
                severity = "low"
                likely_cause = "随机涨落: 正常评分分布"

            # Add specific heuristics
            if r.get("stddev", 0) > 12:
                likely_cause += "; 存在极端离群Agent"
            if r.get("n", 0) > 0 and r.get("range", 0) > 30:
                likely_cause += "; 评分范围过大(>30分)"

            diag[d] = {
                "cv": cv,
                "severity": severity,
                "likely_cause": likely_cause,
                "recommendation": MetaMetaLearner._get_recommendation(d, severity, cv),
            }

        sources["diagnosis"] = diag
        sources["recommended_focus"] = primary

        return sources

    @staticmethod
    def _get_recommendation(dim: str, severity: str, cv: float) -> str:
        if severity == "high":
            if dim == "evolution_capability":
                return "严格限定演化评分标准: 仅依据策略迭代能力打分, 排除角色代入偏差"
            if dim == "architecture":
                return "统一架构健壮性评估维度: 明确断路器/自愈/状态机等子项评分权重"
            if dim == "memory_efficiency":
                return "规范记忆效率评分: 明确缓存命中率/压缩率/检索延迟三个子指标"
            if dim == "reasoning_quality":
                return "标准化推理质量: 要求按逻辑链长度/假设检验/偏差意识三个子项打分"
        if severity == "medium":
            return "calibrated_prompt: 增加评分细则, 要求Agent明确列出评分依据"
        return "保持当前提示词, 仅做格式微调"

    # ─── Phase 3: 系统提示词校准生成 ───

    @staticmethod
    def _generate_prompt(variance: dict, sources: dict) -> tuple[str, list[str], str]:
        """
        根据方差分析生成校准规则 (保持原始 schema 不变, 只追加文本规则)
        Returns: (DEFAULT_PROMPT_JSON_SCHEMA, rules_list, diff_summary_string)
        """
        dims = variance.get("dimensions", {})
        primary = sources.get("primary_driver", "evolution_capability")
        primary_stddev = dims.get(primary, {}).get("stddev", 15)

        rules = []
        high_var_dims = [d for d in DIM_KEYS if dims.get(d, {}).get("stddev", 0) > 10]

        # Rule 1: reasoning justification for all scores
        rules.append(
            "每个维度评分必须在 reasoning 中至少用一句话说明评分依据, "
            "尤其是 evolution_capability 须说明策略迭代历史"
        )

        # Rule 2: evolution_capability specific constraint
        if primary == "evolution_capability" or primary_stddev > 10:
            rules.append(
                "evolution_capability 评分应聚焦策略迭代能力与自适应行为, "
                "避免因角色代入偏差(如「我觉得自己很擅长」)导致的极端值; "
                "建议参考其他维度评分做交叉校验"
            )

        # Rule 3: confidence integer constraint
        rules.append("confidence 必须为整数, 且与 reasoning_quality 评分偏差不超过±20")

        # Rule 4: quality_rating mapping
        rules.append("quality_rating 必须与 scores 均值对应: 优≥80, 良≥60, 中≥40, 差<40")

        # Rule 5: value range clamp (soft)
        rules.append("避免极端评分: 除非有充分推理依据, 各维度评分建议在 30-95 之间")

        # Rule 6: cross-dimension consistency for high-variance dims
        if len(high_var_dims) > 1:
            rules.append(
                f"交叉校准: {', '.join(high_var_dims)} 评分应相互印证, "
                f"避免单一维度异常偏离其他维度均值超过±25"
            )

        diff = (
            f"v{MetaMetaLearner._current_prompt_version+1}: "
            f"校准[{primary}](σ={primary_stddev}), "
            f"新增{len(rules)}条规则, "
            f"保持原始 schema 不变, 追加文本校准规则"
        )

        return DEFAULT_PROMPT_JSON_SCHEMA, rules, diff

    @staticmethod
    def get_calibrated_schema() -> str:
        return MetaMetaLearner._calibrated_schema

    @staticmethod
    def get_calibration_rules() -> list[str]:
        return MetaMetaLearner._calibration_rules

    @staticmethod
    def get_variance_history() -> list[dict]:
        return MetaMetaLearner._variance_history

    @staticmethod
    def get_prompt_history(limit: int = 20) -> list[dict]:
        return prompt_get_history(limit)

    @staticmethod
    def compute_cycle_variance(agent_scores: list[dict]) -> dict:
        """
        Compute per-dimension stddev from a batch of agent scores.
        agent_scores: [{"agent": "...", "architecture": N, ...}, ...]
        Returns: {dim_name: {"mean": ..., "stddev": ..., "n": ...}, ...}
        """
        dim_vals = {d: [] for d in DIM_KEYS}
        for ascore in agent_scores:
            if not isinstance(ascore, dict):
                continue
            for d in DIM_KEYS:
                v = ascore.get(d)
                if isinstance(v, (int, float)) and 10 <= v <= 100:
                    dim_vals[d].append(v)

        result = {}
        for d in DIM_KEYS:
            vals = dim_vals[d]
            if len(vals) >= 2:
                mean_v = sum(vals) / len(vals)
                var = sum((v - mean_v)**2 for v in vals) / len(vals)
                stddev = math.sqrt(var)
            elif len(vals) == 1:
                mean_v = vals[0]
                stddev = 0.0
            else:
                mean_v = 0.0
                stddev = 0.0
            result[d] = {
                "mean": round(mean_v, 2),
                "stddev": round(stddev, 2),
                "n": len(vals),
            }

        # Save to variance_snapshots
        MetaMetaLearner._save_variance_snapshot("current_cycle", result)
        MetaMetaLearner._variance_history.append({
            "timestamp": time.time(),
            "dims": result,
        })

        return result

    @staticmethod
    def _save_variance_snapshot(cycle_id: str, dims: dict):
        """Persist variance data to variance_snapshots table"""
        from .sqlite_store import _get_conn
        try:
            conn = _get_conn()
            now = time.time()
            for d, info in dims.items():
                conn.execute(
                    "INSERT INTO variance_snapshots (cycle_id, dim_name, mean_score, stddev, sample_size, created_at) "
                    "VALUES (?,?,?,?,?,?)",
                    (cycle_id, d, info.get("mean", 0), info.get("stddev", 0),
                     info.get("n", 0), now)
                )
            conn.commit()
        except Exception:
            pass


def prompt_save(entry: dict):
    """Save a prompt version to DB"""
    from .sqlite_store import _get_conn
    try:
        conn = _get_conn()
        conn.execute(
            "INSERT INTO prompt_history (version, diff_summary, rules, schema_text, trigger, created_at) "
            "VALUES (?,?,?,?,?,?)",
            (entry["version"], entry["diff_summary"],
             json.dumps(entry["rules"], ensure_ascii=False),
             entry["schema"], entry.get("trigger", ""), entry["created_at"])
        )
        conn.commit()
    except Exception as e:
        print(f"[prompt_save] error: {e}")


def prompt_get_history(limit: int = 20) -> list[dict]:
    """Read prompt version history"""
    from .sqlite_store import _get_conn
    try:
        conn = _get_conn()
        rows = conn.execute(
            "SELECT version, diff_summary, rules, schema_text, trigger, created_at "
            "FROM prompt_history ORDER BY version DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [
            {
                "version": r[0], "diff_summary": r[1],
                "rules": json.loads(r[2]) if r[2] else [],
                "schema": r[3], "trigger": r[4], "created_at": r[5],
            }
            for r in rows
        ]
    except Exception:
        return []


def variance_get_history(limit: int = 50) -> list[dict]:
    """Read variance snapshot history"""
    from .sqlite_store import _get_conn
    try:
        conn = _get_conn()
        rows = conn.execute(
            "SELECT cycle_id, dim_name, mean_score, stddev, sample_size, created_at "
            "FROM variance_snapshots ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [
            {
                "cycle_id": r[0], "dim_name": r[1], "mean": r[2],
                "stddev": r[3], "n": r[4], "created_at": r[5],
            }
            for r in rows
        ]
    except Exception:
        return []
