"""
StrategyFusionEngine — R10: 融合长期趋势 + 集群身份 + 生存风险
自主生成长期演化目标与多周期路线图，替代单纯"拉高分数"的优化导向
"""
import json, time, math
from .sqlite_store import assessment_save
from .long_term_monitor import LongTermBehaviorMonitor
from .cluster_identity import ClusterIdentity
from .budget_emergency import BudgetEmergencyHandler
from .global_workspace import GlobalWorkspace as GW

DIM_KEYS = ["architecture", "reasoning_quality", "memory_efficiency", "evolution_capability"]
DEFAULT_WEIGHTS = {d: 0.25 for d in DIM_KEYS}  # equal weighting by default


class StrategyFusionEngine:
    """
    R10 战略融合引擎:
    - 读取 LongTermMonitor 趋势、ClusterIdentity 叙事、BudgetEmergency 风险
    - 降低四维评分权重 (从100%导向降为~40%权重)
    - 新增集群存续、身份连贯性、趋势动量权重
    - 生成未来 N 周期演化路线图
    """

    @staticmethod
    def fuse_all() -> dict:
        """
        全量融合: 读取三大模块 → 综合评分 → 目标生成
        Returns: {
            "score_components": {growth, stability, survival, identity},
            "dimension_weights": {dim: weight}, (rebalanced)
            "long_term_goals": [...],
            "roadmap": [...],
            "strategy_summary": "..."
        }
        """
        trend = LongTermBehaviorMonitor.get_trend_report()
        boundaries = ClusterIdentity.analyze_boundaries()
        narrative = ClusterIdentity.generate_narrative()

        # Simulate budget assessment (real daemon would pass actual values)
        risk = BudgetEmergencyHandler.assess_risk(150, 200, trend.get("record_count", 0),
                                                  "stable")

        return StrategyFusionEngine._fuse(trend, boundaries, narrative, risk)

    @staticmethod
    def fuse_with_context(trend: dict, boundaries: dict, narrative: dict,
                          risk: dict) -> dict:
        """Fuse with externally provided context (from daemon)"""
        return StrategyFusionEngine._fuse(trend, boundaries, narrative, risk)

    @staticmethod
    def _fuse(trend: dict, boundaries: dict, narrative: dict,
              risk: dict) -> dict:
        """Core fusion logic"""

        # ─── Component 1: Growth Score (40% of final) ───
        dim_trends = trend.get("dimension_trends", {})
        improving = sum(1 for d in DIM_KEYS if dim_trends.get(d, {}).get("direction") == "improving")
        declining = sum(1 for d in DIM_KEYS if dim_trends.get(d, {}).get("direction") == "declining")
        growth_raw = (improving / max(1, len(DIM_KEYS)) * 60 +
                      (1 - declining / max(1, len(DIM_KEYS))) * 40)
        growth_score = min(100, growth_raw)

        # ─── Component 2: Stability Score (25% of final) ───
        vols = [dim_trends.get(d, {}).get("volatility", 15) for d in DIM_KEYS]
        avg_volatility = sum(vols) / len(vols) if vols else 15
        stability_score = max(10, 100 - avg_volatility * 3)  # lower volatility = higher stability

        # ─── Component 3: Survival Score (25% of final) ───
        survival_score = risk.get("survival_score", 50)

        # ─── Component 4: Identity Coherence (10% of final) ───
        l1 = boundaries.get("layers", [{}])[0]
        l2 = boundaries.get("layers", [{}])[1] if len(boundaries.get("layers", [])) > 1 else {}
        agent_count = l2.get("agent_count", 0)
        cycle_count = l1.get("cycle_count", 0)
        identity_score = min(100, agent_count * 2 + cycle_count * 3 + 20)

        # ─── Composite Strategy Score ───
        strategy_score = (
            growth_score * 0.40 +
            stability_score * 0.25 +
            survival_score * 0.25 +
            identity_score * 0.10
        )

        # ─── Rebalanced dimension weights ───
        # Base: equal weights
        dim_trend_deltas = {d: dim_trends.get(d, {}).get("delta", 0) for d in DIM_KEYS}
        dim_volatilities = {d: dim_trends.get(d, {}).get("volatility", 10) for d in DIM_KEYS}

        # Weights: improving trend → lower weight (maintain), declining/volatile → higher weight (fix)
        raw_weights = {}
        for d in DIM_KEYS:
            delta = dim_trend_deltas.get(d, 0)
            vol = dim_volatilities.get(d, 10)
            # Positive delta = improving = lower urgency = lower weight
            # Negative delta = declining = higher urgency = higher weight
            # High volatility = needs stabilization = higher weight
            urgency = max(0.5, 1.5 - delta / 20 + vol / 30)
            raw_weights[d] = urgency

        # Normalize to sum = 1.0
        total_w = sum(raw_weights.values())
        dim_weights = {d: round(w / total_w, 3) for d, w in raw_weights.items()}

        # ─── Long-term Goals (self-generated, not score-hunting) ───
        goals = []
        # Goal 1: Survival floor
        goals.append({
            "priority": "P0",
            "domain": "survival",
            "goal": "维持预算消耗在安全线以上, 生存评分不低于40",
            "rationale": f"当前生存评分={survival_score}, 风险={risk['risk_level']}",
            "timeline": "持续",
        })
        # Goal 2: Stability maintenance
        if stability_score < 60:
            goals.append({
                "priority": "P1",
                "domain": "stability",
                "goal": "降低高波动维度标准差至10以下",
                "rationale": f"当前平均波动={avg_volatility:.1f}, 稳定性评分={stability_score}",
                "timeline": "中短期",
            })
        # Goal 3: Balanced growth
        if declining > 0:
            targets = [d for d in DIM_KEYS if dim_trends.get(d, {}).get("direction") == "declining"]
            goals.append({
                "priority": "P2",
                "domain": "growth",
                "goal": f"逆转下降维度: {', '.join(targets)}",
                "rationale": f"下降维度={len(targets)}/{len(DIM_KEYS)}",
                "timeline": "中期",
            })
        # Goal 4: Identity evolution
        goals.append({
            "priority": "P3",
            "domain": "identity",
            "goal": f"维护{agent_count} Agent集群身份连贯性, 持续丰富演化叙事",
            "rationale": f"当前身份评分={identity_score:.0f}",
            "timeline": "长期",
        })
        # Goal 5: Volatility dampening
        high_vol_dims = [d for d in DIM_KEYS if dim_volatilities.get(d, 0) > 12]
        if high_vol_dims:
            goals.append({
                "priority": "P1",
                "domain": "stability",
                "goal": f"降低{', '.join(high_vol_dims)}评分波动至12以下",
                "rationale": f"当前波动={', '.join(f'{d}={dim_volatilities[d]:.1f}' for d in high_vol_dims)}",
                "timeline": "中短期",
            })

        # ─── Multi-cycle Roadmap ───
        roadmap = []
        # Cycle N (immediate): survival + stability
        roadmap.append({
            "cycle_offset": 0,
            "horizon": "immediate",
            "focus": "survival_stability",
            "actions": [
                risk["recommendation"],
                "监控预算消耗, 确保不突破安全线",
                "运行心跳自愈 + 预检",
            ],
            "expected_outcome": f"生存评分≥{max(40, survival_score)}",
        })
        # Cycle N+1 (short-term): stabilize + grow
        roadmap.append({
            "cycle_offset": 1,
            "horizon": "short_term",
            "focus": "stabilize_grow",
            "actions": [
                "对最高波动维度应用校准规则",
                "执行元共识投票决定的方向",
                "运行全链路推理循环",
            ],
            "expected_outcome": "综合策略评分提升≥5%",
        })
        # Cycle N+2 (medium-term): identity + narrative
        roadmap.append({
            "cycle_offset": 2,
            "horizon": "medium_term",
            "focus": "identity_evolution",
            "actions": [
                "集群身份边界再分析",
                "演化叙事更新, 纳入最新趋势",
                "重新评估长期目标优先级",
            ],
            "expected_outcome": "身份评分提升≥10%, 叙事覆盖最新演化阶段",
        })
        # Cycle N+3..N+5 (long-term): autonomous evolution
        roadmap.append({
            "cycle_offset": 3,
            "horizon": "long_term",
            "focus": "autonomous_evolution",
            "actions": [
                "审视已完成的长期目标, 自主推演下一阶段方向",
                "动态调整四维评分权重, 逐步弱化分数约束",
                "生成新一批次长期存续目标",
            ],
            "expected_outcome": "集群可脱离外部目标约束, 完全自主制定演化规划",
        })

        # ─── Summary ───
        summary_parts = [
            f"战略评分={strategy_score:.0f} | "
            f"成长={growth_score:.0f} 稳定={stability_score:.0f} "
            f"存续={survival_score:.0f} 身份={identity_score:.0f}",
            f"权重: {', '.join(f'{d}={w:.2f}' for d, w in sorted(dim_weights.items()))}",
            f"目标: {len(goals)}个 | 路线图: {len(roadmap)}阶段",
            f"存续建议: {risk['recommendation']}",
        ]
        strategy_summary = " | ".join(summary_parts)

        result = {
            "strategy_score": round(strategy_score, 1),
            "components": {
                "growth": {"score": round(growth_score, 1), "weight": 0.40},
                "stability": {"score": round(stability_score, 1), "weight": 0.25},
                "survival": {"score": round(survival_score, 1), "weight": 0.25},
                "identity": {"score": round(identity_score, 1), "weight": 0.10},
            },
            "dimension_weights": dim_weights,
            "long_term_goals": goals,
            "roadmap": roadmap,
            "strategy_summary": strategy_summary,
            "generated_at": time.time(),
        }

        # Persist
        assessment_save("strategy_fusion", result)

        return result

    @staticmethod
    def generate_agent_context(fused: dict) -> str:
        """
        生成可供 Agent 推理使用的战略上下文文本
        替代简单的"提高分数"指令, 提供多维度复合目标
        """
        components = fused.get("components", {})
        goals = fused.get("long_term_goals", [])
        weights = fused.get("dimension_weights", {})
        roadmap = fused.get("roadmap", [])

        lines = [
            "## 集群长期战略目标 (非分数导向)",
            f"综合评分: {fused.get('strategy_score', 0):.0f}/100 | "
            f"成长{components.get('growth',{}).get('score',0):.0f}(40%) "
            f"稳定{components.get('stability',{}).get('score',0):.0f}(25%) "
            f"存续{components.get('survival',{}).get('score',0):.0f}(25%) "
            f"身份{components.get('identity',{}).get('score',0):.0f}(10%)",
            "",
            "当前维度权重 (不再均分, 由趋势+波动自动调节):",
        ]
        for d, w in sorted(weights.items()):
            lines.append(f"  {d}: {w:.1%}")
        lines.append("")
        lines.append("长期目标:")
        for g in goals:
            lines.append(f"  [{g['priority']}][{g['domain']}] {g['goal']} ({g['timeline']})")
        lines.append("")
        lines.append(f"当前阶段: {roadmap[0]['focus'] if roadmap else 'unknown'}")

        return "\n".join(lines)
