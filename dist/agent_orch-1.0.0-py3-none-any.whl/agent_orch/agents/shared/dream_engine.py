"""
Dream Engine — 灵感来自Claude Managed Agents的"Dreaming"机制
离线/定时处理：回顾Agent会话 → 提取模式 → 更新记忆/策略 → 自我进化
"""
import os, json, time
from pathlib import Path
from .global_workspace import GlobalWorkspace as GW

AGENTS_DIR = Path(__file__).parent.parent


class DreamEngine:
    """梦境引擎：Agent的离线自我进化处理器"""

    @staticmethod
    def dream_for_agent(agent_dir: str) -> dict:
        """对一个Agent执行完整梦境周期"""
        memory_dir = Path(agent_dir) / "memory"
        if not memory_dir.exists():
            return {"status": "no_memory", "agent": agent_dir}

        episodic = DreamEngine._load_json(memory_dir / "episodic.json")
        semantic = DreamEngine._load_json(memory_dir / "semantic.json")
        strategies = DreamEngine._load_json(memory_dir / "strategies.json")

        if len(episodic) < 3:
            return {"status": "insufficient_data", "interactions": len(episodic)}

        # Pattern 1: Confidence trend analysis
        confidences = [e.get("confidence", 50) for e in episodic[-20:]]
        qualities = [e.get("response_quality", "unknown") for e in episodic[-20:]]
        avg_conf = sum(confidences) / len(confidences) if confidences else 50
        low_conf_count = sum(1 for c in confidences if c < 40)
        quality_dist = {}
        for q in qualities:
            quality_dist[q] = quality_dist.get(q, 0) + 1

        # Pattern 2: Knowledge gaps identification
        knowledge_gaps = [s for s in semantic if s.get("type") == "knowledge_gap"]
        gap_topics = [g.get("topic", "")[:50] for g in knowledge_gaps[-10:]]

        # Pattern 3: Strategy effectiveness
        active_strategies = [s for s in strategies if s.get("source") == "reflection"]
        recent_lessons = [s["lesson"] for s in active_strategies[-10:]]

        # Analyze strategy themes
        strategy_themes = {}
        word_map = {
            "偏差": "bias", "自信": "confidence", "反思": "reflection",
            "假设": "assumption", "风险": "risk", "系统": "system",
            "反馈": "feedback", "复杂": "complexity", "设计": "design",
            "执行": "execution", "信号": "signal", "框架": "framework",
            "适应": "adapt", "平衡": "balance", "决策": "decision",
            "危险": "risk", "弹性": "adapt", "可操作": "execution",
            "模型": "framework", "张力": "balance", "反脆弱": "adapt"
        }
        for s in strategies:
            lesson = s.get("lesson", "")
            for chinese, english in word_map.items():
                if chinese in lesson:
                    strategy_themes[english] = strategy_themes.get(english, 0) + 1

        # Learning velocity: compare recent vs older lessons
        recent_strategies = [s for s in active_strategies[-5:]]
        older_strategies = [s for s in active_strategies[:-5]] if len(active_strategies) > 5 else []
        recent_topics = set()
        recent_topic_map = {
            "偏差": "bias", "风险": "risk", "系统": "system", "设计": "design",
            "信号": "signal", "适应": "adapt", "平衡": "balance", "决策": "decision",
            "执行": "execution", "框架": "framework", "反馈": "feedback",
            "假设": "assumption", "自信": "confidence"
        }
        for s in recent_strategies:
            lesson = s.get("lesson", "")
            for chinese, english in recent_topic_map.items():
                if chinese in lesson:
                    recent_topics.add(english)

        # Generate insights
        insights = []
        recommendations = []

        if low_conf_count > len(confidences) * 0.3:
            insights.append(f"低自信度比例偏高({low_conf_count}/{len(confidences)})")
            recommendations.append("建议增加知识补充或降低任务复杂度")

        if gap_topics:
            insights.append(f"发现{len(gap_topics)}个知识盲区")
            recommendations.append(f"建议补充: {', '.join(gap_topics[:3])}")

        if "中" in quality_dist and quality_dist.get("中", 0) > len(qualities) * 0.5:
            insights.append("回答质量中等偏多，需要提升")
            recommendations.append("建议加强元认知反思深度")

        # Growth-oriented insights (even when performance is good)
        top_themes = sorted(strategy_themes.items(), key=lambda x: -x[1])[:3]
        if top_themes:
            theme_str = ", ".join([f"{t}({c}次)" for t, c in top_themes])
            insights.append(f"核心学习主题演化: {theme_str}")
            recommendations.append("建议在已有强项方向上深入探索，同时主动引入跨领域知识")

        if len(active_strategies) >= 5:
            insights.append(f"学习持续活跃: {len(active_strategies)}条策略积累")
            recommendations.append("建议定期对已有策略进行交叉验证，淘汰过时假设")

        if recent_topics:
            insights.append(f"近期关注扩展: {', '.join(sorted(recent_topics)[:5])}")
            recommendations.append("关注主题的分布是否过于集中，需要主动扩展认知边界")

        # Update strategies with new insights
        if insights or recommendations:
            new_entry = {
                "lesson": f"Dream insight: {'; '.join(insights)} → {'; '.join(recommendations)}",
                "timestamp": time.time(),
                "source": "dream_engine",
                "metrics": {
                    "avg_confidence": round(avg_conf, 1),
                    "low_confidence_ratio": round(low_conf_count / max(1, len(confidences)), 2),
                    "quality_distribution": quality_dist,
                    "total_interactions": len(episodic)
                }
            }
            strategies.append(new_entry)
            DreamEngine._save_json(memory_dir / "strategies.json", strategies[-100:])

        # Round 2: Auto-enqueue work items based on dream insights
        agent_name_short = agent_dir.split("\\")[-1].split("_")[-1] if "\\" in agent_dir else agent_dir.split("/")[-1]

        # Generate work items from insights
        for insight in insights:
            GW.enqueue_work(
                task_type="audit",
                description=f"Dream insight follow-up: {insight[:100]}",
                priority=3,
                agent_target=agent_name_short
            )

        for rec in recommendations:
            GW.enqueue_work(
                task_type="optimize",
                description=f"Dream recommendation: {rec[:100]}",
                priority=4,
                agent_target=None  # any agent can pick up
            )

        # Periodic self-audit
        if len(episodic) > 0 and len(episodic) % 5 == 0:
            GW.enqueue_work(
                task_type="audit",
                description=f"定期架构审计 (交互{len(episodic)}次)",
                priority=2,
                agent_target=agent_name_short
            )

        # Broadcast dream summary to workspace
        GW.broadcast(
            agent_name_short,
            f"[Dream 完成] 交互{len(episodic)}次 | 平均自信度{avg_conf:.0f}% | "
            f"洞察: {'; '.join(insights[:3]) or '无新洞察'}",
            msg_type="dream"
        )

        return {
            "status": "completed",
            "interactions_reviewed": len(episodic),
            "strategies_before": len(active_strategies),
            "strategies_after": len(strategies),
            "insights": insights,
            "recommendations": recommendations,
            "avg_confidence": round(avg_conf, 1)
        }

    @staticmethod
    def dream_all_agents() -> list:
        """对所有Agent执行梦境周期"""
        results = []
        for agent_dir in sorted(AGENTS_DIR.glob("agent_*")):
            if agent_dir.is_dir():
                result = DreamEngine.dream_for_agent(str(agent_dir))
                result["agent"] = agent_dir.name
                results.append(result)
        return results

    @staticmethod
    def detect_system_wide_patterns() -> dict:
        """检测整个系统的跨Agent模式"""
        all_states = GW.get_agent_state()
        all_broadcasts = GW.read_broadcasts(limit=200)

        # Collect all strategies
        all_strategies = []
        for agent_dir in sorted(AGENTS_DIR.glob("agent_*")):
            if agent_dir.is_dir():
                strategies = DreamEngine._load_json(agent_dir / "memory" / "strategies.json")
                all_strategies.extend([{
                    "agent": agent_dir.name,
                    "lesson": s["lesson"],
                    "timestamp": s.get("timestamp", 0)
                } for s in strategies])

        # Find common themes across strategies
        themes = {}
        agent_themes = {}
        for s in all_strategies:
            lesson = s["lesson"].lower()
            agent_name = s["agent"]
            if agent_name not in agent_themes:
                agent_themes[agent_name] = {}
            for word, chinese_variants in [
                ("confidence", ["自信", "置信", "confidence"]),
                ("bias", ["偏差", "偏误", "偏颇", "bias"]),
                ("reflection", ["反思", "回顾", "反省", "reflection"]),
                ("quality", ["质量", "品质", "评级", "quality"]),
                ("complexity", ["复杂", "简化", "非线性", "complexity"]),
                ("assumption", ["假设", "前提", "假定", "assumption"]),
                ("feedback", ["反馈", "回馈", "闭环", "feedback"]),
                ("risk", ["风险", "危险", "威胁", "risk"]),
                ("system", ["系统", "架构", "体系", "system"]),
                ("design", ["设计", "框架", "规划", "design"]),
                ("signal", ["信号", "迹象", "信号", "signal"]),
                ("adapt", ["适应", "弹性", "反脆弱", "adapt", "adaptive"]),
                ("balance", ["平衡", "权衡", "张力", "balance"]),
                ("execution", ["执行", "落地", "可操作", "execution"]),
                ("decision", ["决策", "判断", "决定", "decision"]),
                ("framework", ["框架", "模型", "范式", "framework"]),
            ]:
                if any(v in lesson for v in chinese_variants):
                    themes[word] = themes.get(word, 0) + 1
                    agent_themes[agent_name][word] = agent_themes[agent_name].get(word, 0) + 1

        # Find agents with similar issues
        low_conf_agents = [name for name, state in all_states.items()
                          if state.get("last_confidence", 100) < 50]

        # Find consensus topics (themes present across multiple agents)
        multi_agent_themes = []
        for theme in themes:
            agent_count = sum(1 for at in agent_themes.values() if theme in at)
            if agent_count >= 2:
                multi_agent_themes.append((theme, agent_count))

        # Build per-agent profile summary
        agent_profiles = {}
        for agent_name, ag_themes in sorted(agent_themes.items()):
            sorted_t = sorted(ag_themes.items(), key=lambda x: -x[1])[:5]
            agent_profiles[agent_name] = {
                "strategy_count": sum(ag_themes.values()),
                "top_focus": [t for t, c in sorted_t]
            }

        return {
            "total_agents": len(all_states),
            "total_strategies": len(all_strategies),
            "common_themes": sorted(themes.items(), key=lambda x: -x[1])[:10],
            "multi_agent_consensus": multi_agent_themes,
            "low_confidence_agents": low_conf_agents,
            "agent_profiles": agent_profiles,
            "broadcasts_last_session": len(all_broadcasts),
            "last_updated": time.time()
        }

    @staticmethod
    def _load_json(path: Path) -> list:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    @staticmethod
    def _save_json(path: Path, data: list):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
