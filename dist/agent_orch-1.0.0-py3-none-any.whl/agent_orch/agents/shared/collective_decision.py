"""
Collective Decision Making — 置信加权群体投票共识
v1.0: 投票收敛 + 分歧识别 + 自动决策
"""
import json, time, re, asyncio
from pathlib import Path


class CollectiveDecision:
    """群体决策引擎 — 置信加权投票 + 分歧收敛"""

    AGREE_THRESHOLD = 0.70
    REJECT_THRESHOLD = 0.50
    RE_EXAMINE_GAP = 0.15

    @staticmethod
    def vote(proposal: str, options: list[str], votes: list[dict]) -> dict:
        """置信加权投票收敛"""
        total_weight = sum(max(r.get("confidence", 0), 1) for r in votes if r.get("vote"))
        if total_weight == 0:
            return {"outcome": "error", "action": "无有效投票", "decisions": []}

        weights = {}
        for r in votes:
            raw_v = r.get("vote", "")
            v = str(raw_v) if not isinstance(raw_v, str) else raw_v
            c = max(r.get("confidence", 0), 1)
            if not v:
                continue
            # Try exact match first, then prefix/partial match
            matched = None
            if v in options:
                matched = v
            else:
                v_lower = v.strip().lower()
                for o in options:
                    o_lower = o.strip().lower()
                    if v_lower in o_lower or o_lower in v_lower:
                        matched = o
                        break
                    # Check bracketed IDs like [1] at start
                    import re as _re
                    opt_id = _re.match(r'^\[([^\]]+)\]\s*', o)
                    if opt_id and (opt_id.group(1) == v or v == opt_id.group(1).lower()):
                        matched = o
                        break
            if matched:
                weights[matched] = weights.get(matched, 0) + c

        decisions = sorted([{"option": o, "weight": round(weights.get(o, 0) / total_weight, 3)}
                            for o in options], key=lambda x: -x["weight"])
        top = decisions[0] if decisions else None
        second = decisions[1] if len(decisions) > 1 else None

        if top and top["weight"] >= CollectiveDecision.AGREE_THRESHOLD:
            outcome, action = "adopt", f"采纳: {top['option']} ({top['weight']*100:.0f}%共识)"
        elif top and top["weight"] < CollectiveDecision.REJECT_THRESHOLD:
            outcome, action = "reject", f"拒绝: 最高仅{top['weight']*100:.0f}%"
        elif second and top and (top["weight"] - second["weight"]) < CollectiveDecision.RE_EXAMINE_GAP:
            outcome, action = "re_examine", f"分歧: {top['option']}({top['weight']*100:.0f}%) vs {second['option']}({second['weight']*100:.0f}%)"
        else:
            outcome, action = "defer", f"暂缓: 最高{top['weight']*100:.0f}%"

        return {
            "proposal": proposal[:200], "outcome": outcome, "action": action,
            "decisions": decisions, "total_votes": len(votes),
            "voter_agreement": round(sum(1 for r in votes if r.get("vote") == top["option"]) / max(len(votes), 1), 3) if top else 0
        }

    @staticmethod
    def extract_votes_from_results(agent_results: list[dict], options: list[str]) -> list[dict]:
        """从集体推理结果中提取投票"""
        votes = []
        for r in agent_results:
            agent = r.get("agent", "?")
            raw = r.get("response", r.get("_raw", ""))
            confidence = r.get("confidence", r.get("metacognitive_pre", {}).get("confidence", 50))
            vote = ""
            rationale = ""
            try:
                txt = raw if isinstance(raw, str) else str(raw)
                clean = re.sub(r'```(?:json)?\s*', '', txt).strip()
                if '{' in clean:
                    s, e = clean.index('{'), clean.rindex('}') + 1
                    parsed = json.loads(clean[s:e])
                    vote = parsed.get("vote", "")
                    rationale = parsed.get("rationale", "")[:100]
                    confidence = parsed.get("confidence", confidence)
            except: pass
            votes.append({"agent": agent, "vote": vote, "confidence": confidence, "rationale": rationale})
        return votes
