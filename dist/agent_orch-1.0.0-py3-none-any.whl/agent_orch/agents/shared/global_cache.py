"""
Global Cross-Agent Cache — SQLite持久化缓存
所有30个Agent共享, 相同请求→缓存命中, 零API调用
"""
import json, time, hashlib
from .sqlite_store import cache_get as _sget, cache_set as _sset, cache_get_stats as _sstats, cache_invalidate as _sinval


def _request_hash(messages: list, model: str, temp: float) -> str:
    raw = json.dumps({"m": messages, "model": model, "t": temp}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def get_cache(messages: list, model: str, temp: float) -> str | None:
    return _sget(_request_hash(messages, model, temp))


def set_cache(messages: list, model: str, temp: float, response: str,
              ttl: int = 3600, tag: str = ""):
    key_hash = _request_hash(messages, model, temp)
    _sset(key_hash, response, tag=tag, ttl=ttl, model=model, temp=temp)


def get_cache_stats() -> dict:
    return _sstats()


def invalidate_cache(tag: str = ""):
    _sinval(tag)
