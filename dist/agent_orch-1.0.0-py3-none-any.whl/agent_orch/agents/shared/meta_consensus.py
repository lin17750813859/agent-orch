"""
Meta-Consensus — 元共识协议: Agent 投票决定投票规则本身
v1.0: 多轮协商 + 规则民主 + 分歧收敛
"""
import json, time
from .collective_decision import CollectiveDecision


META_RULES = {
    "simple_majority":  {"label": "简单多数",  "threshold": 0.50, "description": ">50% 采纳"},
    "super_majority":   {"label": "超级多数",  "threshold": 0.66, "description": "≥66% 采纳 (2/3)"},
    "consensus":        {"label": "共识",       "threshold": 0.80, "description": "≥80% 采纳"},
    "unanimous":        {"label": "全体一致",   "threshold": 1.00, "description": "100% 全部同意"},
}


class MetaConsensus:
    """元共识协议 — 先投票决定'怎么投票', 再投提案本身"""

    MAX_ROUNDS = 3
    RE_EXAMINE_GAP = 0.15

    @staticmethod
    def deliberate(proposal: str, options: list[str], votes: list[dict],
                   meta_votes: list[dict] | None = None,
                   history: list[dict] | None = None) -> dict:
        """多轮元共识协商

        meta_votes: 对'用什么规则投票'的投票. 每个vote含
            {"agent": "...", "rule": "simple_majority|super_majority|consensus|unanimous",
             "confidence": 0-100, "rationale": "..."}
        如果不提供, 默认使用 CollectiveDecision 的 70% 阈值 (即 consensus 规则)
        """
        round_num = len(history) + 1 if history else 1
        if round_num > MetaConsensus.MAX_ROUNDS:
            return {
                "outcome": "max_rounds_reached",
                "action": f"已达最大协商轮次 ({MetaConsensus.MAX_ROUNDS}), 取最新结果",
                "round": round_num,
            }

        # ─── Phase 1: Agent 决定"投票规则" ───
        chosen_rule = "consensus"  # default
        rule_details = META_RULES[chosen_rule].copy()
        if meta_votes:
            rule_weights = {}
            for rv in meta_votes:
                rule = rv.get("rule", "consensus")
                conf = max(rv.get("confidence", 0), 1)
                if rule in META_RULES:
                    rule_weights[rule] = rule_weights.get(rule, 0) + conf
            total = sum(rule_weights.values()) or 1
            sorted_rules = sorted(rule_weights.items(), key=lambda x: -x[1])
            if sorted_rules:
                chosen_rule = sorted_rules[0][0]
                # Check if meta consensus is clear enough
                top_pct = sorted_rules[0][1] / total
                second_pct = sorted_rules[1][1] / total if len(sorted_rules) > 1 else 0
                if chosen_rule == "unanimous" and top_pct < 0.90:
                    chosen_rule = "consensus"  # degrade if unanimity not meta-agreed
                rule_details = META_RULES[chosen_rule].copy()
                rule_details["meta_agreement"] = round(top_pct, 3)
                rule_details["rule_weights"] = dict(sorted_rules)

        # ─── Phase 2: 用选定的规则投票 ───
        # Override CollectiveDecision thresholds
        original_agree = CollectiveDecision.AGREE_THRESHOLD
        original_reject = CollectiveDecision.REJECT_THRESHOLD
        CollectiveDecision.AGREE_THRESHOLD = rule_details["threshold"]
        CollectiveDecision.REJECT_THRESHOLD = max(0.30, rule_details["threshold"] - 0.30)

        result = CollectiveDecision.vote(proposal, options, votes)

        # Restore defaults
        CollectiveDecision.AGREE_THRESHOLD = original_agree
        CollectiveDecision.REJECT_THRESHOLD = original_reject

        outcome = result["outcome"]

        # ─── Phase 3: 分歧检测 → 是否进入下一轮 ───
        need_another_round = False
        round_note = ""
        if outcome == "re_examine" and round_num < MetaConsensus.MAX_ROUNDS:
            need_another_round = True
            round_note = f"分歧过大, 进入第 {round_num + 1} 轮协商"
        elif outcome == "reject" and round_num < MetaConsensus.MAX_ROUNDS:
            need_another_round = True
            round_note = f"提案被拒, 允许修改后进入第 {round_num + 1} 轮"

        round_record = {
            "round": round_num,
            "rule_used": chosen_rule,
            "rule_threshold": rule_details["threshold"],
            "rule_label": rule_details["label"],
            "outcome": outcome,
            "action": result.get("action", ""),
            "decisions": result.get("decisions", []),
            "voter_agreement": result.get("voter_agreement", 0),
            "note": round_note,
        }

        new_history = (history or []) + [round_record]

        return {
            "proposal": proposal[:200],
            "current_outcome": outcome,
            "action": result.get("action", ""),
            "decisions": result.get("decisions", []),
            "rule_chosen": chosen_rule,
            "rule_details": rule_details,
            "round": round_num,
            "total_rounds": round_num,
            "need_another_round": need_another_round,
            "round_note": round_note,
            "history": new_history,
            "final": not need_another_round,
        }

    @staticmethod
    def multi_round_deliberation(proposal: str, options: list[str],
                                  vote_rounds: list[list[dict]],
                                  meta_votes_rounds: list[list[dict]] | None = None) -> dict:
        """多轮完整协商 (处理所有轮次)

        vote_rounds: 每轮的投票列表, 如 [round1_votes, round2_votes, ...]
        meta_votes_rounds: 每轮的元投票列表 (可选)
        """
        history = []
        final = None
        for i, round_votes in enumerate(vote_rounds):
            meta = (meta_votes_rounds or [None] * len(vote_rounds))[i]
            result = MetaConsensus.deliberate(proposal, options, round_votes, meta, history)
            final = result
            history = result["history"]
            if result["final"]:
                break

        if final is None:
            return {"outcome": "error", "action": "无投票数据"}

        final["total_rounds"] = len(history)
        final["rounds_used"] = len(history)
        return final
