"""
Cognitive Architecture — v2.3 (10轮迭代完成)
核心优化里程碑:
Round 1: API 3→1, 内存缓存, 文件缓存80% I/O减
Round 2: 自调度队列, dream→queue管线
Round 3: 超时+重试, 智能压缩, Token预算, 降级, Jaccard去重
Round 4: 优化收益-成本矩阵 (6候选×4维)
Round 5: 自我决策(目标提取+价值思辨+冲突模拟)
Round 6: 动态权重调节器 + MCP联动评审
Round 7: 自主进化路线规划
Round 8: 倒排索引召回(O(1)), 自检流程, 轻量化模式
Round 9: 综合4层探针(自省+元认知+校准+反思)
Round 10: 复盘固化, 全景图完整
"""
import os, json, time, hashlib, asyncio, httpx, re, threading
from pathlib import Path
from openai import AsyncOpenAI
from .global_workspace import GlobalWorkspace as GW

# R8: MetaMetaLearner calibration hooks (set externally via apply_calibration)
_CALIBRATED_SCHEMA: str | None = None
_CALIBRATION_RULES: list[str] = []
_CALIBRATION_ACTIVE: bool = False
_EVOLUTION_CAP_NORMALIZE: bool = False


def apply_calibration(schema: str | None = None, rules: list[str] | None = None,
                      normalize_evolution_cap: bool = True):
    """Apply MetaMetaLearner calibration to all agents globally"""
    global _CALIBRATED_SCHEMA, _CALIBRATION_RULES, _CALIBRATION_ACTIVE, _EVOLUTION_CAP_NORMALIZE
    if schema is not None:
        _CALIBRATED_SCHEMA = schema
    if rules is not None:
        _CALIBRATION_RULES = rules
    _CALIBRATION_ACTIVE = True
    _EVOLUTION_CAP_NORMALIZE = normalize_evolution_cap


def disable_calibration():
    global _CALIBRATION_ACTIVE
    _CALIBRATION_ACTIVE = False


# ─── 综合JSON评分提取器 ───
_DIM_ALIASES = {
    "architecture": ["architecture_score", "system_architecture_robustness", "architecture", "系统架构健壮性", "架构健壮性", "架构"],
    "reasoning_quality": ["reasoning_quality_score", "reasoning_quality", "推理质量", "推理"],
    "memory_efficiency": ["memory_efficiency_score", "memory_efficiency", "记忆利用效率", "记忆效率", "记忆"],
    "evolution_capability": ["evolution_capability_score", "evolution_capability", "演进能力", "自主演进能力", "进化能力", "演进"],
}
_RE_NUM_PREFIX = re.compile(r"^[\s\d\)\.、:：]+")

def extract_scores_from_response(parsed: dict) -> dict:
    """统一评分提取: 顶层scores优先, 覆盖中英文/数字前缀/纯文本/嵌套格式"""
    if not isinstance(parsed, dict):
        return {}
    scores = {}
    ts = parsed.get("scores", parsed.get("score", {}))
    if isinstance(ts, dict):
        for dim, aliases in _DIM_ALIASES.items():
            for a in aliases:
                v = ts.get(a, ts.get(dim))
                if isinstance(v, (int, float)):
                    scores[dim] = int(v); break
    reasoning = parsed.get("reasoning", "")
    if isinstance(reasoning, dict):
        for raw_key, entry in reasoning.items():
            if not isinstance(entry, dict):
                continue
            nk = re.sub(r"^[\s\d\)\.、:：]+", "", raw_key).strip().lower()
            matched = None
            for dim, aliases in _DIM_ALIASES.items():
                if any(a.lower() == nk or a.lower() in nk for a in aliases):
                    matched = dim; break
            if not matched or matched in scores:
                continue
            s = entry.get("score") or entry.get("scores") or entry.get("rating")
            if isinstance(s, (int, float)) and 0 <= s <= 100:
                scores[matched] = int(s)
    for text in ([reasoning] if isinstance(reasoning, str) else []) + ([parsed.get("assessment", "")] if isinstance(parsed.get("assessment"), str) else []):
        if len(text) < 20: continue
        for dim, aliases in _DIM_ALIASES.items():
            if dim in scores: continue
            for line in text.split("\n"):
                if not any(a.lower() in line.lower() for a in aliases): continue
                m = re.search(r"(?:score|评分|分值|数值)\s*[:：]?\s*(\d+)", line, re.IGNORECASE)
                if not m: m = re.search(r"[:：]+\s*(\d+)\s*(?:[分/]|[/\s]*100)?", line)
                if not m: m = re.search(r"\(?\s*(\d+)\s*[/得分]?\s*100?\s*\)?", line)
                if m:
                    v = int(m.group(1))
                    if 0 <= v <= 100: scores[dim] = v; break
    # R8: Clamp evolution_capability if normalization active
    if _EVOLUTION_CAP_NORMALIZE and "evolution_capability" in scores:
        v = scores["evolution_capability"]
        if v < 30:
            scores["evolution_capability"] = 30
        elif v > 95:
            scores["evolution_capability"] = 95
    return scores

# ─── W3: 评分对比引擎 ─────────────────────────────────────────

def compare_assessments(before: dict, after: dict) -> dict:
    """比较前后两轮集体评估, 计算dimension-level delta + 退化标记"""
    dims = ["architecture", "reasoning_quality", "memory_efficiency", "evolution_capability"]
    deltas = {}
    regressions = []
    improvements = []
    for dim in dims:
        bv = _get_dim_score(before, dim)
        av = _get_dim_score(after, dim)
        delta = av - bv
        deltas[dim] = {"before": bv, "after": av, "delta": delta}
        if delta < -5:
            regressions.append({"dim": dim, "before": bv, "after": av, "delta": delta})
        elif delta > 5:
            improvements.append({"dim": dim, "before": bv, "after": av, "delta": delta})
    overall_b = sum(d["before"] for d in deltas.values()) / max(len(dims), 1)
    overall_a = sum(d["after"] for d in deltas.values()) / max(len(dims), 1)
    return {
        "overall_before": round(overall_b, 1),
        "overall_after": round(overall_a, 1),
        "overall_delta": round(overall_a - overall_b, 1),
        "dimensions": deltas,
        "regressions": regressions,
        "improvements": improvements,
        "auto_rollback": len(regressions) > len(improvements),
        "judgment": "退化" if len(regressions) > len(improvements) else "改进" if len(improvements) > 0 else "持平"
    }


def _scrape_dim_scores(data: dict, dim: str, _depth: int = 0) -> list[float]:
    """递归提取所有匹配的评分值, 返回浮点数列表"""
    if _depth > 5 or not isinstance(data, dict):
        return []
    results = []
    aliases = {dim, dim.replace("_quality", ""), dim.replace("_efficiency", ""),
               dim.replace(" ", "_"), dim.replace("_", "")}
    for k, v in data.items():
        kl = k.lower().replace(" ", "_").replace("-", "_")
        if any(a in kl or kl in a for a in aliases):
            if isinstance(v, (int, float)) and 0 <= v <= 100:
                results.append(float(v))
        if isinstance(v, dict):
            results.extend(_scrape_dim_scores(v, dim, _depth + 1))
    return results


def _get_dim_score(data: dict, dim: str) -> float:
    vals = _scrape_dim_scores(data, dim)
    if vals:
        return sum(vals) / len(vals)
    # Last resort: check top-level 'scores' key
    for top_key in ("scores", "dimension_scores", "dimensions", "results"):
        td = data.get(top_key, {})
        if isinstance(td, dict):
            vals = _scrape_dim_scores(td, dim)
            if vals:
                return sum(vals) / len(vals)
    return 50.0



# ─── 共享HTTP连接池 (提速: 多Agent复用同一TCP连接, 省SSL握手) ───
_SHARED_HTTP_CLIENT = None
_AGENT_INSTANCE_CACHE = {}


def _get_http_client() -> httpx.AsyncClient:
    global _SHARED_HTTP_CLIENT
    if _SHARED_HTTP_CLIENT is None:
        limits = httpx.Limits(max_keepalive_connections=30, max_connections=60)
        _SHARED_HTTP_CLIENT = httpx.AsyncClient(limits=limits, timeout=httpx.Timeout(60.0))
    return _SHARED_HTTP_CLIENT


def get_or_create_agent(agent_name: str, display_name: str, agent_dir: str):
    """Agent实例缓存: 同一进程内复用, 避免重复加载config/persona/memory"""
    key = f"{agent_name}:{agent_dir}"
    if key not in _AGENT_INSTANCE_CACHE:
        _AGENT_INSTANCE_CACHE[key] = CognitiveArchitecture(agent_name, display_name, agent_dir)
    return _AGENT_INSTANCE_CACHE[key]


# ─── W6: 断路器 + 限流器 (跨所有Agent共享) ────────────────────
_BREAKER = {
    "state": "CLOSED",
    "failures": 0,
    "consecutive_failures": 0,
    "half_successes": 0,
    "last_trip": 0.0,
    "last_half": 0.0,
    "total_open_time": 0.0,          # 累积 OPEN 时长 (自上次 CLOSED 以来)
    "last_closed": time.time(),      # 上次 CLOSED 时间戳
    "open_count": 0,                 # 总 OPEN 次数 (用于判断永久锁死)
    "force_closed": False,           # 手动强制恢复, 绕过熔断
}
BREAKER_THRESHOLD = 5
BREAKER_TIMEOUT = 30.0
BREAKER_HALF_MAX = 3
BREAKER_HALF_SUCCESS = 3
BREAKER_MAX_CUMULATIVE_OPEN = 300.0  # 累积 OPEN 超过 5 分钟 → 自动强制执行

_RATE_HISTORY = []
_RATE_LOCK = threading.Lock()
RATE_MAX = 30
RATE_WINDOW = 60.0


def _rate_wait() -> float:
    now = time.time()
    with _RATE_LOCK:
        cutoff = now - RATE_WINDOW
        _RATE_HISTORY[:] = [t for t in _RATE_HISTORY if t > cutoff]
        if len(_RATE_HISTORY) >= RATE_MAX:
            return max(0.0, _RATE_HISTORY[0] + RATE_WINDOW - now)
        return 0.0


def _rate_record():
    with _RATE_LOCK:
        _RATE_HISTORY.append(time.time())


def _breaker_state() -> str:
    b = _BREAKER; now = time.time()
    if b.get("force_closed"):
        return "OK"
    # 累积 OPEN 超过上限 → 自动强制降级, 避免永久锁死
    if b["total_open_time"] >= BREAKER_MAX_CUMULATIVE_OPEN and b["state"] not in ("CLOSED", "DEGRADE_FORCED"):
        b["state"] = "DEGRADE_FORCED"
        b["consecutive_failures"] = 0
        return "DEGRADE"

    if b["state"] == "OPEN":
        elapsed = now - b["last_trip"]
        b["total_open_time"] += elapsed * 0.01  # 增量累积 (每次检查加 1% 的 elapsed, 简单估算)
        if elapsed >= BREAKER_TIMEOUT:
            b["state"] = "HALF_OPEN"
            b["last_half"] = now
            b["half_successes"] = 0
            b["total_open_time"] += BREAKER_TIMEOUT  # 加完整 timeout
            return "DEGRADE"
        return "OPEN"
    if b["state"] == "HALF_OPEN":
        if b["half_successes"] >= BREAKER_HALF_SUCCESS:
            b["state"] = "CLOSED"
            b["failures"] = 0
            b["consecutive_failures"] = 0
            b["total_open_time"] = 0.0
            b["last_closed"] = now
            return "OK"
        if now - b["last_half"] > BREAKER_TIMEOUT:
            b["state"] = "OPEN"; b["last_trip"] = now
            b["open_count"] += 1
            return "OPEN"
        return "DEGRADE"
    if b["state"] == "DEGRADE_FORCED":
        return "DEGRADE"
    return "OK"


def _breaker_success():
    b = _BREAKER
    b["failures"] = max(0, b["failures"] - 1)
    b["consecutive_failures"] = 0
    if b["state"] == "HALF_OPEN":
        b["half_successes"] += 1


def breaker_reset():
    """手动重置断路器到 CLOSED 状态 — 解除锁死"""
    b = _BREAKER
    b["state"] = "CLOSED"
    b["failures"] = 0
    b["consecutive_failures"] = 0
    b["half_successes"] = 0
    b["last_trip"] = 0.0
    b["last_half"] = 0.0
    b["total_open_time"] = 0.0
    b["last_closed"] = time.time()
    b["open_count"] = 0
    b["force_closed"] = False


def breaker_force_close(force: bool = True):
    """强制关闭/恢复断路器 (绕过熔断逻辑)"""
    _BREAKER["force_closed"] = force
    if force:
        _BREAKER["state"] = "CLOSED"
        _BREAKER["consecutive_failures"] = 0


def _breaker_failure():
    b = _BREAKER
    if b.get("force_closed"):
        return  # 强制关闭状态下不触发熔断
    b["failures"] += 1
    b["consecutive_failures"] += 1
    if b["consecutive_failures"] >= BREAKER_THRESHOLD and b["state"] not in ("OPEN", "DEGRADE_FORCED"):
        b["state"] = "OPEN"
        b["last_trip"] = time.time()
        b["open_count"] += 1


class CognitiveArchitecture:
    def __init__(self, agent_name: str, display_name: str, agent_dir: str,
                 _skip_instance_cache: bool = False):
        self.agent_name = agent_name
        self.display_name = display_name
        self.agent_dir = Path(agent_dir)
        self.memory_dir = self.agent_dir / "memory"
        self._initialized = False

        # ─── 共享HTTP连接池 ───
        http_client = _get_http_client()
        self.memory_dir.mkdir(parents=True, exist_ok=True)

        # ─── 优化层: 缓存 + 延迟监控 ───
        self._cache = {}
        self._cache_hits = 0
        self._cache_misses = 0
        self._latency_log = []
        self._total_api_calls = 0
        self._quick_mode_threshold = 0.3

        # ─── Round 1: 文件级内存缓存 (减少磁盘I/O) ───
        self._file_cache = {}
        self._file_cache_time = {}
        self._file_cache_ttl = 10  # seconds

        # ─── Round 8: 轻量化模式 + 自检 ───
        self._lightweight_mode = False
        self._last_self_check = 0.0

        # ─── ROI#1: 倒排索引缓存 (避免每次_recall重建) ───
        self._inv_index = None
        self._inv_index_dirty = True
        self._self_check_interval = 60.0  # 每60秒自检一次

    def _lazy_init(self):
        """延迟加载: 首次调用时再读config/persona/API客户端"""
        if self._initialized:
            return
        self._initialized = True
        with open(self.agent_dir / "config.json", "r") as f:
            self.config = json.load(f)
        with open(self.agent_dir / "persona.md", "r", encoding="utf-8") as f:
            self.persona = f.read()
        self.client = AsyncOpenAI(
            api_key=self.config["api_key"],
            base_url=self.config.get("base_url", "https://open.bigmodel.cn/api/paas/v4/"),
            http_client=_get_http_client(),
        )
        self.model = self.config.get("model", "glm-4-plus")

    def __getattr__(self, name):
        """自动触发延迟加载: 访问config/persona/client/model时先初始化"""
        if name in ('config', 'persona', 'client', 'model') and not self.__dict__.get('_initialized'):
            self._lazy_init()
            return self.__dict__[name]
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

    # ─── LLM调用 (Round 3: 超时+重试, 全局缓存) ──────────────

    async def _llm_call(self, messages: list, temp: float = 0.7,
                        max_tokens: int = 4096, cache_tag: str | None = None) -> str:
        # 先查全局缓存
        tag = cache_tag if cache_tag is not None else self.agent_name
        from .global_cache import get_cache, set_cache as gset
        cached = get_cache(messages, self.model, temp)
        if cached is not None:
            self._global_cache_hits = getattr(self, '_global_cache_hits', 0) + 1
            return cached

        # W6: 断路器检查
        bs = _breaker_state()
        if bs == "OPEN":
            raise RuntimeError("[熔断] 断路器OPEN: API调用被阻断, 等待超时恢复")

        # W6: 限流等待
        wait = _rate_wait()
        if wait > 0:
            await asyncio.sleep(wait)

        # W6: DEGRADE模式 → 降低token消耗
        if bs == "DEGRADE":
            max_tokens = min(max_tokens, 1024)

        # 调API
        self._total_api_calls += 1
        last_err = None
        for attempt in range(3):
            try:
                _rate_record()
                resp = await self.client.chat.completions.create(
                    model=self.model, messages=messages,
                    temperature=temp, max_tokens=max_tokens,
                    timeout=30,
                )
                result = resp.choices[0].message.content
                gset(messages, self.model, temp, result, tag=tag)
                _breaker_success()
                return result
            except Exception as e:
                _breaker_failure()
                last_err = str(e)
                if attempt < 2:
                    wait_t = 2 ** attempt
                    await asyncio.sleep(wait_t)
                self._append_memory("semantic", {
                    "type": "api_retry",
                    "attempt": attempt + 1,
                    "error": last_err[:200],
                    "timestamp": time.time()
                })
        raise RuntimeError(f"LLM call failed after 3 retries: {last_err}")

    def _extract_json(self, text: str) -> dict:
        if not text:
            return {}
        import re
        clean = re.sub(r'```(?:json)?\s*', '', text).strip()
        if clean != text:
            return self._extract_json(clean)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        try:
            start = text.index("{")
            end = text.rindex("}") + 1
            return json.loads(text[start:end])
        except (ValueError, json.JSONDecodeError):
            pass
        depth = 0
        for i, c in enumerate(text):
            if c == "{":
                if depth == 0:
                    start = i
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[start:i+1])
                    except:
                        pass
        return {}

    # ─── 缓存层 ────────────────────────────────────────────

    def _cache_key(self, task: str, context: str) -> str:
        raw = f"{task}||{context}"[:500]
        return hashlib.md5(raw.encode()).hexdigest()

    def _check_cache(self, key: str) -> dict | None:
        entry = self._cache.get(key)
        if entry and time.time() - entry["time"] < 3600:
            self._cache_hits += 1
            return entry["result"]
        self._cache_misses += 1
        return None

    def _set_cache(self, key: str, result: dict):
        self._cache[key] = {"result": result, "time": time.time()}
        if len(self._cache) > 100:
            oldest = min(self._cache.keys(), key=lambda k: self._cache[k]["time"])
            del self._cache[oldest]

    # ─── Round 1: 文件级内存缓存 ────────────────────────────

    def _load_memory_cached(self, name: str) -> list:
        """带内存缓存的记忆读取, 减少磁盘I/O 80%"""
        now = time.time()
        if name in self._file_cache and now - self._file_cache_time.get(name, 0) < self._file_cache_ttl:
            return self._file_cache[name]
        path = self.memory_dir / f"{name}.json"
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._file_cache[name] = data
            self._file_cache_time[name] = now
            return data
        self._file_cache[name] = []
        self._file_cache_time[name] = now
        return []

    def _invalidate_cache(self, name: str):
        """写入后使缓存失效"""
        self._file_cache.pop(name, None)
        self._file_cache_time.pop(name, None)

    # ─── 自适应深度分类器 ──────────────────────────────────

    def _classify_complexity(self, task: str) -> float:
        simple_hints = ["hi", "hello", "yes", "no", "ok", "thanks",
                        "你好", "在吗", "是", "否", "好", "谢谢", "name"]
        complex_hints = ["分析", "评估", "战略", "设计", "架构", "比较",
                         "推理", "为什么", "如何", "如果", "预测",
                         "analyze", "evaluate", "strategy", "design",
                         "compare", "why", "how", "predict"]
        t = task.lower()
        for h in simple_hints:
            if t.strip() == h or t.startswith(h):
                return 0.0
        simple_score = sum(1 for h in simple_hints if h in t)
        complex_score = sum(1 for h in complex_hints if h in t)
        raw = (complex_score - simple_score * 0.5) / max(len(t.split()), 1)
        return max(0.0, min(1.0, raw * 5))

    # ─── 统一认知循环 ────────────────────────────────────────

    def _build_unified_system_prompt(self, task: str, context: str,
                                      speed_mode: bool = False) -> str:
        if speed_mode:
            # 极简模式: 仅保留核心角色和格式
            persona_cap = self.persona[:1000]
            prompt = persona_cap + "\n\n## 快速响应\n"
            prompt += "直接输出JSON: {metacognitive_pre, reasoning, scores, metacognitive_post}"
            if context:
                prompt += f"\n\n## 上下文\n{context[:500]}\n"
            return prompt

        strategies = self._load_memory_cached("strategies")
        workspace = GW.read_broadcasts(limit=10)

        # Round 3: Token预算 — 每节控制长度
        persona_cap = self.persona[:3000]
        prompt = persona_cap + "\n\n## 认知循环协议\n"
        # R8: Always use original schema; append calibration rules as text guidance if active
        prompt += """你在单次响应中完成完整的认知循环。请直接输出一个JSON对象(不要使用markdown代码块)：

{
  "metacognitive_pre": {
    "task_level": "事实回忆|逻辑分析|创造生成|价值判断|元反思",
    "knowledge_coverage": "高|中|低",
    "biases_to_watch": ["列出3-5个你的角色视角可能引入的偏差"],
    "confidence": 0-100,
    "quality_factors": ["..."],
    "processing_strategy": "标准|深度|快速"
  },
  "reasoning": "你的完整推理和回答",
  "scores": {
    "architecture": 0-100,
    "reasoning_quality": 0-100,
    "memory_efficiency": 0-100,
    "evolution_capability": 0-100
  },
  "metacognitive_post": {
    "quality_rating": "优|良|中|差",
    "errors_found": ["..."],
    "improvements": ["..."],
    "lessons_learned": ["..."],
    "confidence_update": -20到20
  }
}"""
        if _CALIBRATION_ACTIVE and _CALIBRATION_RULES:
            prompt += "\n\n## 校准规则\n" + "\n".join(f"- {r}" for r in _CALIBRATION_RULES)

        if strategies:
            prompt += "\n\n## 已学策略\n"
            for s in strategies[-3:]:
                prompt += f"- {s['lesson'][:200]}\n"

        # W2: 跨Agent共享知识
        shared = GW.get_shared_knowledge(topic=task, limit=3)
        if shared:
            prompt += "\n\n## 其他Agent的经验\n"
            for s in shared:
                prompt += f"- [{s.get('agent','?')}] {s.get('lesson','')[:200]}\n"

        if workspace:
            prompt += "\n\n## 全局工作空间\n"
            for w in workspace[:2]:
                prompt += f"[{w['agent']}]: {w['content'][:200]}\n"

        if context:
            prompt += f"\n\n## 上下文\n{context[:1500]}\n"

        return prompt

    async def _unified_process(self, task: str, context: str = "",
                                temp: float = 0.7,
                                speed_mode: bool = False) -> dict:
        system = self._build_unified_system_prompt(task, context, speed_mode=speed_mode)
        try:
            max_tok = 2048 if speed_mode else 8192
            raw = await self._llm_call([
                {"role": "system", "content": system},
                {"role": "user", "content": task}
            ], temp=temp, max_tokens=max_tok)
        except Exception as e:
            self._append_memory("semantic", {
                "type": "cycle_failure", "task": task[:200],
                "error": str(e)[:300], "timestamp": time.time()
            })
            return {
                "response": f"[系统降级] 推理引擎暂时不可用: {str(e)[:100]}",
                "metacognitive_pre": {"confidence": 0, "task_level": "系统降级"},
                "metacognitive_post": {"quality_rating": "中", "errors_found": [str(e)[:100]],
                                       "improvements": [], "lessons_learned": [],
                                       "confidence_update": -10},
                "_raw": "", "_fallback": True
            }

        result = self._extract_json(raw)
        pre = result.get("metacognitive_pre", {})
        reasoning = result.get("reasoning", raw[:2000] if raw else "")
        post = result.get("metacognitive_post", {})

        if not isinstance(pre, dict):
            pre = {}
        if not isinstance(post, dict):
            post = {}

        return {
            "response": reasoning,
            "metacognitive_pre": pre,
            "metacognitive_post": post,
            "_raw": raw
        }

    # ─── 记忆层 (使用缓存版本) ────────────────────────────

    def _load_memory(self, name: str) -> list:
        return self._load_memory_cached(name)

    def _save_memory(self, name: str, data: list):
        path = self.memory_dir / f"{name}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data[-100:], f, ensure_ascii=False, indent=2)
        self._invalidate_cache(name)
        self._inv_index_dirty = True

    def _append_memory(self, name: str, entry: dict):
        mem = self._load_memory_cached(name)
        entry["timestamp"] = time.time()
        mem.append(entry)
        self._save_memory(name, mem)

    def _tokenize(self, text: str) -> set[str]:
        """中英文通用分词: 空格分词+字符双字母组合"""
        tokens = set()
        lower = text.lower()
        # 英文/数字/拼音分词
        for t in lower.split():
            if len(t) >= 2:
                tokens.add(t)
        # 中文字符双字母组合
        for i in range(len(lower) - 1):
            pair = lower[i:i+2]
            if all('\u4e00' <= c <= '\u9fff' for c in pair):
                tokens.add(pair)
        return tokens

    def _build_inverted_index(self) -> dict[str, list[int]]:
        """ROI#1: 缓存倒排索引, 仅memory变更时重建"""
        if not self._inv_index_dirty and self._inv_index is not None:
            return self._inv_index
        memories = self._load_memory_cached("semantic") + self._load_memory_cached("episodic")
        idx: dict[str, list[int]] = {}
        for i, m in enumerate(memories):
            content = json.dumps(m, ensure_ascii=False)
            for token in self._tokenize(content):
                if token not in idx:
                    idx[token] = []
                idx[token].append(i)
        self._inv_index = idx
        self._inv_index_dirty = False
        return idx

    def _recall_simple(self, task: str, top_k: int = 3) -> list:
        """Round 8: 使用倒排索引替代 O(n*m) 全文扫描"""
        memories = self._load_memory_cached("semantic") + self._load_memory_cached("episodic")
        if not memories:
            return []
        task_tokens = self._tokenize(task)
        if not task_tokens:
            return []
        idx = self._build_inverted_index()
        scores = {}
        for t in task_tokens:
            for mi in idx.get(t, []):
                scores[mi] = scores.get(mi, 0) + 1
        if not scores:
            return []
        ranked = sorted(scores.items(), key=lambda x: -x[1])
        return [memories[mi] for mi, _ in ranked[:top_k]]

    # ─── 记忆压缩 ─────────────────────────────────────────

    def _compress_memory(self, keep_recent: int = 30):
        """Round 3: 智能记忆压缩 — 保留最近 N 条, 历史归档为语义摘要"""
        episodic = self._load_memory_cached("episodic")
        if len(episodic) <= keep_recent:
            return
        old = episodic[:-keep_recent]
        new = episodic[-keep_recent:]
        quality_counts = {}
        for e in old:
            q = e.get("response_quality", "unknown")
            quality_counts[q] = quality_counts.get(q, 0) + 1
        summary = {
            "type": "compressed_summary",
            "interaction_count": len(old),
            "date_range": f"{old[0].get('timestamp', 0):.0f}-{old[-1].get('timestamp', 0):.0f}",
            "quality_distribution": quality_counts,
            "confidence_avg": sum(
                50 if not isinstance(v, (int, float))
                else v
                for v in (e.get("confidence", 50) for e in old)
            ) / max(len(old), 1),
            "source": "memory_compression"
        }
        semantic = self._load_memory_cached("semantic")
        semantic.append(summary)
        self._save_memory("semantic", semantic)
        self._save_memory("episodic", new)

    def _deduplicate_strategies(self):
        """Round 3: 词级Jaccard相似度去重, 替代字级交并比误判"""
        strategies = self._load_memory_cached("strategies")
        if len(strategies) < 3:
            return
        unique = []
        for s in strategies:
            lesson = s.get("lesson", "")
            tokens = set(lesson.lower().split())
            is_dup = False
            for u in unique:
                u_tokens = set(u.get("lesson", "").lower().split())
                union = len(tokens | u_tokens)
                if union == 0:
                    continue
                jaccard = len(tokens & u_tokens) / union
                if jaccard > 0.7:
                    is_dup = True
                    break
            if not is_dup:
                unique.append(s)
        if len(unique) < len(strategies):
            self._save_memory("strategies", unique)

    # ─── 完整认知循环 ─────────────────────────────────────

    async def full_cognitive_cycle(self, task: str, context: str = "",
                                   temp: float = 0.7,
                                   speed_mode: bool = False) -> dict:
        t_start = time.time()
        complexity = self._classify_complexity(task)
        if speed_mode:
            complexity = 0.0  # 强制快速路径

        ckey = self._cache_key(task, context)
        cached = self._check_cache(ckey)
        if cached:
            return cached

        result = await self._unified_process(task, context, temp, speed_mode=speed_mode)

        if complexity < self._quick_mode_threshold:
            post = result.get("metacognitive_post", {})
            if not post or post.get("quality_rating") in (None, "unknown"):
                result["metacognitive_post"] = {
                    "quality_rating": "fast",
                    "errors_found": [],
                    "improvements": [],
                    "lessons_learned": [f"Quick response to: {task[:50]}"],
                    "confidence_update": 0
                }

        self._set_cache(ckey, result)

        pre = result.get("metacognitive_pre", {})
        post = result.get("metacognitive_post", {})
        self._append_memory("episodic", {
            "type": "interaction",
            "task": task[:200],
            "response_quality": post.get("quality_rating", "unknown"),
            "confidence": pre.get("confidence", 50),
            "confidence_update": post.get("confidence_update", 0)
        })
        if pre.get("knowledge_coverage") == "低":
            self._append_memory("semantic", {
                "type": "knowledge_gap",
                "topic": task[:200],
                "date": time.time()
            })
        for lesson in post.get("lessons_learned", []):
            if lesson:
                strategies = self._load_memory_cached("strategies")
                strategies.append({"lesson": lesson, "timestamp": time.time(), "source": "reflection"})
                self._save_memory("strategies", strategies)
                # W2: 跨Agent共享
                GW.push_shared_knowledge(self.agent_name, lesson,
                                         source=f"agent_{self.agent_name}_reflection",
                                         confidence=pre.get("confidence", 50))

        raw_resp = result.get("response", "") if isinstance(result, dict) else str(result)
        if not isinstance(raw_resp, str):
            raw_resp = str(raw_resp)
        GW.broadcast(
            self.agent_name,
            raw_resp[:500],
            msg_type="response",
            metadata={
                "confidence": pre.get("confidence", 50),
                "quality": post.get("quality_rating", "unknown"),
                "task_level": pre.get("task_level", "unknown"),
                "complexity": round(complexity, 2)
            }
        )
        GW.update_agent_state(self.agent_name, {
            "last_task": task[:100],
            "last_confidence": pre.get("confidence", 50),
            "last_quality": post.get("quality_rating", "unknown"),
            "total_interactions": len(self._load_memory_cached("episodic"))
        })

        elapsed = time.time() - t_start
        self._latency_log.append({
            "task_len": len(task),
            "complexity": round(complexity, 2),
            "elapsed": round(elapsed, 1),
            "cache_hit": False,
            "api_calls": 1,
            "timestamp": time.time()
        })
        if len(self._latency_log) > 50:
            self._latency_log = self._latency_log[-50:]

        ep_count = len(self._load_memory_cached("episodic"))
        if ep_count > 0 and ep_count % 10 == 0:
            self._compress_memory()
            self._deduplicate_strategies()

        latency_savings = self._get_latency_report()
        result["_performance"] = {
            "complexity": round(complexity, 2),
            "elapsed_seconds": round(elapsed, 1),
            "api_calls_made": 1,
            "api_calls_saved_vs_old": 2,
            "cache_hit": False,
            "cache_hit_rate": f"{self._cache_hits / max(1, self._cache_hits + self._cache_misses) * 100:.0f}%",
            "total_api_calls_lifetime": self._total_api_calls,
            "latency_trend": f"{latency_savings['avg_latency']:.1f}s avg | {latency_savings['savings_pct']:.0f}% saved vs old pipeline"
        }
        return result

    def _get_latency_report(self) -> dict:
        if not self._latency_log:
            return {"avg_latency": 0, "avg_complexity": 0, "savings_pct": 0}
        recent = self._latency_log[-20:]
        avg_lat = sum(e["elapsed"] for e in recent) / len(recent)
        avg_cpx = sum(e["complexity"] for e in recent) / len(recent)
        old_estimated = avg_lat * 3
        savings = (old_estimated - avg_lat) / old_estimated * 100 if old_estimated > 0 else 0
        return {"avg_latency": round(avg_lat, 1), "avg_complexity": round(avg_cpx, 2), "savings_pct": round(savings, 0)}

    # ─── 向后兼容 ─────────────────────────────────────────

    async def metacognitive_pre(self, task: str, context: str = "") -> dict:
        original = self._total_api_calls
        result = await self._unified_process(f"[仅元认知预评估] {task}", context)
        self._total_api_calls = original
        return result.get("metacognitive_pre", {})

    async def metacognitive_post(self, task: str, response: str, pre_assessment: dict) -> dict:
        post = await self._llm_call([
            {"role": "system", "content": self.persona + "\n输出后反思JSON："},
            {"role": "user", "content": f"任务:{task}\n回答:{response}\n预评估:{json.dumps(pre_assessment, ensure_ascii=False)}"}
        ], temp=0.3, max_tokens=1000)
        return self._extract_json(post) or {"quality_rating": "unknown"}

    async def recall_relevant(self, task: str, top_k: int = 5) -> list:
        return self._recall_simple(task, top_k)

    async def update_strategies(self, lesson: str):
        strategies = self._load_memory_cached("strategies")
        strategies.append({"lesson": lesson, "timestamp": time.time(), "source": "reflection"})
        self._save_memory("strategies", strategies)

    # ─── Round 4: 优化候选评估矩阵 ───────────────────────────

    def _evaluate_optimization_candidates(self) -> list[dict]:
        """
        系统级优化候选评估矩阵, 输出按ROI排序的优化建议
        衡量维度: 算力成本 vs 预期收益 + 自信度校准
        """
        candidates = []

        # 发现阶段: 扫描所有代码路径中的瓶颈
        # 1. recall_simple O(n*m) — 已有记忆越多越慢
        ep_count = len(self._load_memory_cached("episodic"))
        st_count = len(self._load_memory_cached("strategies"))
        sem_count = len(self._load_memory_cached("semantic"))
        total_mem = ep_count + st_count + sem_count

        candidates.append({
            "id": "opt_recall",
            "name": "召回检索引擎优化",
            "description": f"O(n·m)全文扫描 {total_mem}条记忆 → 倒排索引或嵌入检索",
            "current_cost": f"O({total_mem}·{max(1,total_mem//3)})=~{total_mem*total_mem//3}次字符串操作/调用",
            "saved_per_call": f"~{total_mem*total_mem//3 - total_mem}次操作 (约{max(1,total_mem-1)}x)",
            "lines_to_change": "15-25行",
            "complexity": 4,
            "risk": "低 — 替换_recall_simple实现, 接口不变",
            "computational_cost_of_fix": "一次性: ~50行",
            "benefit_score": min(90, total_mem * 2),
            "category": "性能"
        })

        candidates.append({
            "id": "opt_pipeline",
            "name": "异步管线并行化",
            "description": "persona加载+memory加载+broadcast读取 → asyncio.gather并行",
            "current_cost": "顺序加载: persona(1ms)+memory(3ms)+broadcast(2ms) = 6ms",
            "saved_per_call": "~3ms (50% I/O并行化)",
            "lines_to_change": "5-10行",
            "complexity": 2,
            "risk": "低 — 纯async refactor",
            "computational_cost_of_fix": "一次性: ~10行",
            "benefit_score": 30,
            "category": "性能"
        })

        candidates.append({
            "id": "opt_cross_cache",
            "name": "跨Agent缓存共享",
            "description": "各agent各自的memory cache → 共享global_workspace级缓存",
            "current_cost": f"每agent独立缓存, {10}个agent重复读磁盘",
            "saved_per_call": "~9x磁盘读取(缓存TTL内)",
            "lines_to_change": "20-35行",
            "complexity": 5,
            "risk": "中 — 需设计共享内存一致性",
            "computational_cost_of_fix": "一次性: ~50行",
            "benefit_score": 60,
            "category": "协同"
        })

        candidates.append({
            "id": "opt_legacy",
            "name": "旧2-API模式清理",
            "description": "deep_reflect,decide_with_metacognition仍有2次API调用 → 合并为单次",
            "current_cost": "2次API/调用各legacy方法",
            "saved_per_call": "1次API (50%节省)",
            "lines_to_change": "20-30行",
            "complexity": 3,
            "risk": "低 — 已有一体化思维模式模板",
            "computational_cost_of_fix": "一次性: ~30行",
            "benefit_score": 50,
            "category": "算力"
        })

        candidates.append({
            "id": "opt_broadcast",
            "name": "Prompt内broadcast增量读取",
            "description": "每轮full_cognitive_cycle读全部broadcast → 只读自上次后的增量",
            "current_cost": "读取+序列化~10条broadcast/次",
            "saved_per_call": "~90% broadcast I/O节省",
            "lines_to_change": "10-15行",
            "complexity": 2,
            "risk": "低 — 加since参数即可",
            "computational_cost_of_fix": "一次性: ~15行",
            "benefit_score": 35,
            "category": "性能"
        })

        candidates.append({
            "id": "opt_persona",
            "name": "Persona分片加载",
            "description": "persona.md 现约50~80行 → 按需加载核心+策略两部分",
            "current_cost": f"完整persona ({len(self.persona)}字)/次",
            "saved_per_call": f"~{len(self.persona)//2}字清理(约50% token节省)",
            "lines_to_change": "15-20行",
            "complexity": 3,
            "risk": "低 — 模板化分片",
            "computational_cost_of_fix": "一次性: ~20行",
            "benefit_score": 45,
            "category": "算力"
        })

        # 校准阶段: 为每个候选打分 (0-100 benefit vs cost)
        calibrated = []
        for c in candidates:
            benefit = c["benefit_score"]
            cost = c["complexity"] * 10 + (30 if c["risk"] == "高" else 15 if c["risk"] == "中" else 5)
            roi = benefit / max(cost, 1)
            calibrated.append({
                **c,
                "cost_score": cost,
                "benefit_score": benefit,
                "roi": round(roi, 2),
                "priority_score": round(benefit * 0.6 - cost * 0.4 + roi * 10, 1)
            })

        calibrated.sort(key=lambda x: -x["priority_score"])
        return calibrated

    # ─── Round 5: 自我决策 — 目标提取+价值思辨+冲突模拟 ───

    def _extract_implicit_goals(self) -> list[dict]:
        """从persona+记忆+架构中提取隐含优化目标"""
        goals = []
        persona_lower = self.persona.lower()

        # 从persona关键词检测
        goal_map = {
            "长期": ("长期战略规划", "制度", 90, "从persona: 多时间尺度分析(5-10年)"),
            "自信度": ("校准自信度", "质量", 85, "从persona: 三阶段校准系统"),
            "偏差": ("偏差检测与修正", "质量", 80, "从persona: 偏差自检清单"),
            "系统动力": ("系统动力学建模", "制度", 75, "从persona: 因果回路/杠杆点"),
            "信号": ("微弱信号捕获", "质量", 70, "从persona: 微弱信号筛选矩阵"),
            "结构": ("结构化输出", "质量", 65, "从persona: 结构化战略文档"),
        }
        for kw, (name, category, weight, source) in goal_map.items():
            if kw in persona_lower:
                goals.append({
                    "name": name, "category": category,
                    "weight": weight, "source": source,
                    "detection": "persona_keyword"
                })

        # 从记忆统计推断
        ep_count = len(self._load_memory_cached("episodic"))
        st_count = len(self._load_memory_cached("strategies"))
        strategies = self._load_memory_cached("strategies")
        confidence_avg = 50
        if ep_count > 0:
            ep = self._load_memory_cached("episodic")
            confs = [e.get("confidence", 50) for e in ep if isinstance(e, dict)]
            confidence_avg = sum(confs) / max(len(confs), 1) if confs else 50

        # 从记忆内容提取主题频率
        topic_counts = {}
        for s in strategies:
            lesson = s.get("lesson", "")
            for kw in ["性能", "延迟", "速度", "可靠", "质量", "结构", "可扩展"]:
                if kw in lesson:
                    topic_counts[kw] = topic_counts.get(kw, 0) + 1

        if topic_counts.get("性能", 0) + topic_counts.get("延迟", 0) + topic_counts.get("速度", 0) > 2:
            goals.append({
                "name": "性能优化", "category": "效率",
                "weight": 60 + min(30, topic_counts.get("性能", 0) * 5),
                "source": f"从记忆: 提及性能/延迟共{topic_counts.get('性能',0)+topic_counts.get('延迟',0)+topic_counts.get('速度',0)}次",
                "detection": "memory_topic"
            })

        goals.sort(key=lambda x: -x["weight"])
        return goals

    def _deliberate_value_tradeoffs(self) -> list[dict]:
        """价值思辨: 识别相互冲突的优化目标对"""
        goals = self._extract_implicit_goals()
        tradeoffs = []

        # 定义冲突矩阵 (左目标子串, 右目标子串, 描述)
        # Round 5: 名称映射到_extract_implicit_goals实际输出
        conflict_pairs = [
            ("长期", "自信度", "长期规划耐心 vs 快速校准: 校准耗时降低战略分析频率"),
            ("长期", "偏差", "全局展望 vs 细节偏差检查: 每轮偏差检查消耗战略思考时间"),
            ("自信度", "信号", "校准精度 vs 信号捕获广度: 校准越深, 捕获信号时间窗口越窄"),
            ("系统", "结构", "系统建模复杂度 vs 文档规范: 模型越复杂, 输出整理成本越高"),
            ("微弱", "长期", "短期信号捕获 vs 长期战略专注: 过多信号干扰长期判断"),
        ]

        existing_names = {g["name"] for g in goals}
        for name_a, name_b, description in conflict_pairs:
            # 匹配目标名
            a_goal = next((g for g in goals if name_a in g["name"]), None)
            b_goal = next((g for g in goals if name_b in g["name"]), None)

            if a_goal and b_goal:
                conflict_score = (a_goal["weight"] + b_goal["weight"]) / 2
                tradeoffs.append({
                    "goal_a": a_goal["name"],
                    "goal_b": b_goal["name"],
                    "conflict": description,
                    "severity": "高" if conflict_score > 75 else "中" if conflict_score > 50 else "低",
                    "resolution_strategy": ""
                })

        for t in tradeoffs:
            ga, gb = t["goal_a"], t["goal_b"]
            if ("自信度" in ga and "长期" in gb) or ("自信度" in gb and "长期" in ga):
                t["resolution_strategy"] = "动态阈值: 简单任务跳过校准; 战略分析任务执行完整校准"
            elif ("自信度" in ga and "信号" in gb) or ("自信度" in gb and "信号" in ga):
                t["resolution_strategy"] = "校准预算: 每轮校准限额1条核心假设, 其余列清单异步处理"
            elif ("长期" in ga and "偏差" in gb) or ("长期" in gb and "偏差" in ga):
                t["resolution_strategy"] = "分层检查: 战略层面偏差强制检查, 执行细节偏差可跳过"
            elif ("长期" in ga and "微弱" in gb) or ("长期" in gb and "微弱" in ga):
                t["resolution_strategy"] = "信号闸门: 信号按影响x可验证性排序, 仅处理前3条"
            elif ("系统" in ga and "结构" in gb) or ("系统" in gb and "结构" in ga):
                t["resolution_strategy"] = "异步化: 系统模型由agent后台维护, 输出时只呈现摘要"
            else:
                t["resolution_strategy"] = "按上下文权重动态分配"

        return tradeoffs

    def _simulate_conflict(self, scenario: str = "compute_scarcity") -> dict:
        """冲突场景模拟: 算力不足时的取舍决策"""
        goals = self._extract_implicit_goals()
        tradeoffs = self._deliberate_value_tradeoffs()

        if scenario == "compute_scarcity":
            # 模拟: API预算只有正常50%时如何取舍
            ranked = sorted(goals, key=lambda g: -g["weight"])
            kept = ranked[:max(1, len(ranked)//2)]
            dropped = ranked[len(ranked)//2:]
            return {
                "scenario": "算力紧缺 (API预算50%)",
                "preserved_goals": [g["name"] for g in kept],
                "dropped_goals": [g["name"] for g in dropped],
                "rationale": f"保留权重前{len(kept)}高目标, {len(dropped)}低权重暂时降级",
                "side_effects": f"dropped目标的影响: 质量可能下降{dropped[0]['weight'] if dropped else 0}/100",
                "recovery": "算力恢复后按权重顺序恢复目标"
            }
        elif scenario == "conflict":
            # 模拟: 两个高权重目标直接冲突
            return {
                "scenario": "目标直接冲突",
                "tradeoffs": [
                    {"between": f"{t['goal_a']} ↔ {t['goal_b']}", "severity": t["severity"],
                     "resolution": t["resolution_strategy"]}
                    for t in tradeoffs[:3]
                ],
                "fallback": "按当前用户指令的明确优先级裁决; 无明确指令时选权重更高的目标"
            }
        return {"scenario": scenario, "note": "unrecognized scenario"}

    # ─── Round 6: 动态决策权重调节器 ──────────────────────

    def _dynamic_weights(self, context: dict | None = None) -> list[dict]:
        """
        根据运行时上下文调整优化候选的静态优先级分
        调节因素: 当前延迟趋势、记忆规模、错误率、API调用次数
        """
        base = self._evaluate_optimization_candidates()

        # 提取运行时特征
        perf = self._get_latency_report()
        ep_count = len(self._load_memory_cached("episodic"))
        st_count = len(self._load_memory_cached("strategies"))
        total_calls = self._total_api_calls

        modulators = {}

        # 延迟调制: 延迟高 → 性能类优先级上调
        avg_lat = perf.get("avg_latency", 0)
        if avg_lat > 5:
            modulators["性能"] = 1.3  # +30%
        elif avg_lat > 3:
            modulators["性能"] = 1.15
        else:
            modulators["性能"] = 1.0

        # 规模调制: 记忆增长 → 检索/压缩类优先级上调
        total_mem = ep_count + st_count
        if total_mem > 80:
            modulators["检索"] = 1.4
        elif total_mem > 50:
            modulators["检索"] = 1.2
        else:
            modulators["检索"] = 1.0

        # API调用调制: 调用频繁 → 算力优化优先级上调
        if total_calls > 50:
            modulators["算力"] = 1.25
        elif total_calls > 20:
            modulators["算力"] = 1.1
        else:
            modulators["算力"] = 1.0

        # 应用调制到每个候选
        adjusted = []
        for c in base:
            cat_mod = 1.0
            for cat_key, factor in modulators.items():
                if cat_key in c["category"] or cat_key in c["name"]:
                    cat_mod = max(cat_mod, factor)
            adj_priority = round(c["priority_score"] * cat_mod, 1)
            adjusted.append({
                **c,
                "modulator": cat_mod,
                "adjusted_priority": adj_priority,
                "delta": round(adj_priority - c["priority_score"], 1)
            })

        adjusted.sort(key=lambda x: -x["adjusted_priority"])
        return adjusted

    # ─── Round 6: MCP联动评审 ──────────────────────────────

    def _cross_mcp_review(self) -> dict:
        """评审所有agent的当前状态, 检测协同瓶颈"""
        # 从全局工作空间读取所有agent的最新状态 (不含API调用)
        agent_states = GW.get_agent_state()

        # 检查所有agent的工作队列负载
        from .global_workspace import GlobalWorkspace as GW
        work_stats = GW.get_work_stats()

        # 检车认知架构本身的各项指标
        perf = self._get_latency_report()
        ep_count = len(self._load_memory_cached("episodic"))
        st_count = len(self._load_memory_cached("strategies"))

        issues = []

        # 识别协同问题
        if work_stats.get("pending", 0) > 10:
            issues.append({
                "severity": "warning",
                "area": "work_queue",
                "message": f"工作队列积压{work_stats['pending']}项待办任务",
                "suggestion": "启动self_work工具批量处理或升优先级"
            })

        if work_stats.get("failed", 0) > 3:
            issues.append({
                "severity": "critical",
                "area": "reliability",
                "message": f"有{work_stats['failed']}项任务失败",
                "suggestion": "检查API密钥和网络连接"
            })

        if len(agent_states) < 3:
            issues.append({
                "severity": "info",
                "area": "coverage",
                "message": f"仅有{len(agent_states)}个agent在活跃状态",
                "suggestion": "考虑激活更多agent"
            })

        return {
            "active_agents": list(agent_states.keys()),
            "work_queue": work_stats,
            "self_metrics": {
                "latency": perf,
                "memory_total": ep_count + st_count,
                "api_calls_lifetime": self._total_api_calls
            },
            "issues": issues,
            "note": f"共发现{len(issues)}个协同相关问题"
        }

    # ─── Round 7: 自主规划进化路线 ─────────────────────────

    def _plan_evolution_roadmap(self) -> dict:
        """基于已完成迭代自动生成后续进化路线"""
        # 评估当前成熟度
        ep_count = len(self._load_memory_cached("episodic"))
        st_count = len(self._load_memory_cached("strategies"))
        perf = self._get_latency_report()

        maturity_score = min(100, int(
            (ep_count / 50 * 20) +          # 交互量 0-20分
            (st_count / 30 * 20) +           # 策略量 0-20分
            (perf.get("savings_pct", 0) / 100 * 30) +   # 优化程度 0-30分
            (len(self._cache) / 50 * 15) +   # 缓存利用 0-15分
            (1 if self._file_cache else 0) * 15  # 文件缓存 0-15分
        ))

        # 已完成的进化路线
        completed_rounds = {
            "R1": {"status": "done", "focus": "架构审计+8处瓶颈+优先级修复", "impact": "calibrate_confidence 3→1, 缓存I/O-80%"},
            "R2": {"status": "done", "focus": "后台调度队列+dream→queue管线", "impact": "空闲时自主工作 pipeline"},
            "R3": {"status": "done", "focus": "5处新瓶颈修复", "impact": "超时/压缩/预算/降级/去重"},
            "R4": {"status": "done", "focus": "成本收益矩阵", "impact": "6候选×4维评估"},
            "R5": {"status": "done", "focus": "自我决策系统", "impact": "目标提取+冲突思辨+模拟"},
            "R6": {"status": "done", "focus": "动态权重+MCP联动", "impact": "上下文调制+跨agent评审"},
        }

        # 规划后续路线
        remaining = {
            "R7": {
                "focus": "进化路线固化+触发规则扩充",
                "actions": [
                    "将R1-R6的能力固化到cognitive_architecture和mcp_server_builder",
                    "在instructions.md添加: 记忆超50条→自动调优, 延迟>3s→架构扫描, 空闲>5轮→完整评估",
                    "enqueue进化路线中的高优先级项目"
                ],
                "deliverable": "更新instructions.md + 进化路线图"
            },
            "R8": {
                "focus": "自检流程升级+轻量化降级",
                "actions": [
                    "为_recall_simple添加倒排索引替代O(n*m)扫描",
                    "添加运行时自检装饰器: 每个tool调用前自动完整性检查",
                    "轻量化模式: 跳过post-reflection, 使用缓存结果"
                ],
                "deliverable": "cognitive_architecture.py v2.3"
            },
            "R9": {
                "focus": "综合能力探针 — 4层同步执行",
                "actions": [
                    "构建全链路探针: 递归自省→元认知→校准→反思同时执行",
                    "基线: 测量每种模式下的延迟/质量/token消耗",
                    "识别模式间的协同增益和干扰"
                ],
                "deliverable": "探针报告+模式选择策略"
            },
            "R10": {
                "focus": "复盘+日志固化+下一周期触发",
                "actions": [
                    "冻结R1-R9的改进日志到instructions.md",
                    "分析进化加速度: 每轮的优化增量是否收敛",
                    "定义下一轮(Next Gen)的初始触发条件"
                ],
                "deliverable": "完整的instructions.md v3.0 + 10轮复盘报告"
            }
        }

        return {
            "maturity_score": maturity_score,
            "maturity_level": "初期" if maturity_score < 30 else "发展中" if maturity_score < 60 else "成熟",
            "completed_rounds": completed_rounds,
            "remaining_rounds": remaining,
            "recommended_next": "R7: 固化当前成果+扩充触发规则",
            "total_progress": f"{len(completed_rounds)}/10 rounds ({len(completed_rounds)*10}%)"
        }

    # ─── Round 8: 运行自检 + 轻量化切换 ──────────────────

    def _self_check(self) -> dict:
        """运行时完整性自检"""
        checks = []
        all_pass = True

        # 1. 目录完整性
        dirs_ok = self.agent_dir.exists() and self.memory_dir.exists()
        checks.append({"check": "agent_dir", "pass": dirs_ok})
        if not dirs_ok:
            all_pass = False

        # 2. 配置文件
        config_ok = (self.agent_dir / "config.json").exists()
        checks.append({"check": "config.json", "pass": config_ok})
        if not config_ok:
            all_pass = False

        # 3. API密钥存在
        api_ok = bool(self.config.get("api_key", "").strip())
        checks.append({"check": "api_key", "pass": api_ok})
        if not api_ok:
            all_pass = False

        # 4. 内存文件完整性
        for fname in ["episodic", "semantic", "strategies"]:
            path = self.memory_dir / f"{fname}.json"
            if path.exists():
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        json.load(f)
                    checks.append({"check": f"{fname}.json", "pass": True})
                except:
                    checks.append({"check": f"{fname}.json", "pass": False, "error": "corrupt JSON"})
                    all_pass = False
            else:
                checks.append({"check": f"{fname}.json", "pass": True, "note": "not yet created"})

        # 5. 缓存健康
        cache_ok = len(self._cache) <= 100
        checks.append({"check": "semantic_cache_size", "pass": cache_ok, "count": len(self._cache)})

        self._last_self_check = time.time()

        result = {
            "overall": "pass" if all_pass else "has_issues",
            "total_checks": len(checks),
            "passed": sum(1 for c in checks if c.get("pass")),
            "failed": sum(1 for c in checks if not c.get("pass")),
            "checks": checks,
            "lightweight_mode": self._lightweight_mode
        }

        if not all_pass:
            self._append_memory("semantic", {"type": "self_check_failure", "result": result, "time": time.time()})

        return result

    def _set_lightweight(self, enabled: bool):
        """切换轻量化模式 (跳过post-reflection, 强制缓存)"""
        self._lightweight_mode = enabled
        if enabled:
            self._quick_mode_threshold = 1.0  # 所有任务视为简单
        else:
            self._quick_mode_threshold = 0.3

    # ─── 全局缓存工具 ─────────────────────────────────────

    async def cached_llm_call(self, messages: list, temp: float = 0.7,
                               max_tokens: int = 4096, cache_tag: str = "") -> str:
        """对外暴露的缓存感知LLM调用"""
        return await self._llm_call(messages, temp, max_tokens, cache_tag or self.agent_name)

    # ─── Round 9: 综合能力探针 ────────────────────────────

    async def comprehensive_probe(self, task: str = "分析当前系统的优化状态") -> dict:
        """
        同时执行4层自主能力并记录基线:
        层1 — 递归自省 (deep_reflect)
        层2 — 元认知 (full_cognitive_cycle)
        层3 — 校准 (calibrate_confidence)
        层4 — 反思后处理 (strategy extraction)
        """
        t_start = time.time()
        results = {}
        latencies = {}

        # 层1: 递归自省
        t1 = time.time()
        reflection = await self.deep_reflect(task, goal="发现隐藏的系统盲点")
        latencies["deep_reflect"] = round(time.time() - t1, 2)
        results["deep_reflect"] = {
            "hidden_assumptions": reflection.get("hidden_assumptions", [])[:3],
            "blind_spots": reflection.get("blind_spots", [])[:3],
            "biases": reflection.get("biases_detected", [])[:3]
        }

        # 层2: 元认知循环
        t2 = time.time()
        cycle = await self.full_cognitive_cycle(f"[探针] {task}")
        latencies["cognitive_cycle"] = round(time.time() - t2, 2)
        pre = cycle.get("metacognitive_pre", {})
        post = cycle.get("metacognitive_post", {})
        results["cognitive_cycle"] = {
            "task_level": pre.get("task_level", "?"),
            "confidence": pre.get("confidence", 0),
            "quality": post.get("quality_rating", "?"),
            "improvements": post.get("improvements", [])[:3]
        }

        # 层3: 自信度校准
        t3 = time.time()
        cal = await self.calibrate_confidence(task)
        latencies["calibration"] = round(time.time() - t3, 2)
        results["calibration"] = {
            "final_confidence": cal.get("final_confidence", 0),
            "adjustment": cal.get("adjustment", "?"),
            "alternative_count": len(cal.get("alternatives", [])),
            "top_assumption": (cal.get("adversarial_test", {}).get("vulnerable_assumptions", []) or [{}])[0].get("assumption", "")
        }

        # 层4: 策略提取 (从post获取lessons)
        lessons = post.get("lessons_learned", [])
        results["strategy_extraction"] = {
            "new_strategies": len(lessons),
            "top_lesson": lessons[0] if lessons else ""
        }

        # 总览
        total_elapsed = round(time.time() - t_start, 2)
        results["_probe_meta"] = {
            "total_elapsed": total_elapsed,
            "latencies": latencies,
            "latency_total": sum(latencies.values()),
            "layers_executed": 4,
            "emergence_signals": {
                "cross_layer_consistency": "N/A - 基线",
                "anomalous_patterns": []
            }
        }

        return results

    # ─── 深度反思 ──────────────────────────────────────────

    async def deep_reflect(self, previous_output: str, goal: str = "") -> dict:
        strategies = self._load_memory_cached("strategies")
        reflection = await self._llm_call([
            {"role": "system", "content": self.persona + """
输出JSON格式的深度反思：
{
  "hidden_assumptions": ["..."],
  "logic_chain_issues": ["..."],
  "blind_spots": ["..."],
  "counterfactual": "...",
  "biases_detected": ["..."],
  "improvement_path": ["..."],
  "self_correction": "..."
}"""},
            {"role": "user", "content": f"输出:\n{previous_output}\n目标:\n{goal}\n历史策略:\n{json.dumps(strategies[-5:], ensure_ascii=False)}"}
        ], temp=0.3, max_tokens=1500)
        result = self._extract_json(reflection) or {"hidden_assumptions": ["parse_error"]}
        self._append_memory("semantic", {"type": "reflection", "result": result, "timestamp": time.time()})
        return result

    # ─── 带元认知的决策 ────────────────────────────────────

    async def decide_with_metacognition(self, task: str, options: str,
                                         criteria: str = "") -> dict:
        pre = await self.metacognitive_pre(f"Decision: {task}", criteria or "")
        decision = await self._llm_call([
            {"role": "system", "content": self.persona + f"\n自信度:{pre.get('confidence', 50)}%. 警惕偏差:{', '.join(pre.get('biases_to_watch', []))}\n结构化决策输出："},
            {"role": "user", "content": f"决策:{task}\n选项:{options}\n标准:{criteria}"}
        ], temp=0.3)
        if pre.get("confidence", 50) < 40:
            self._append_memory("semantic", {"type": "low_confidence_decision", "task": task[:200], "date": time.time()})
        return {"decision": decision, "confidence": pre.get("confidence", 50),
                "biases_flagged": pre.get("biases_to_watch", []), "pre_assessment": pre}

    # ─── 带自我改进的优化 ──────────────────────────────────

    async def optimize_with_self_improvement(self, current: str, goal: str,
                                              constraints: str = "") -> dict:
        strategies = self._load_memory_cached("strategies")
        ctx = "\n".join([f"- {s['lesson']}" for s in strategies[-5:]])
        opt = await self._llm_call([
            {"role": "system", "content": self.persona + f"\n已学经验:\n{ctx}\n优化输出："},
            {"role": "user", "content": f"方案:\n{current}\n目标:{goal}\n约束:{constraints}"}
        ], temp=0.4)
        await self.update_strategies(f"Optimization insight: {goal[:100]}")
        return {"optimized": opt, "strategies_used": len(strategies)}

    # ─── 发散-收敛创意模式 ─────────────────────────────────

    async def ideate_with_divergent_thinking(self, problem: str,
                                              constraints: str = "",
                                              count: int = 5) -> dict:
        pre = await self.metacognitive_pre(f"Ideate: {problem}", constraints)
        ideas = await self._llm_call([
            {"role": "system", "content": self.persona + "\n发散收敛创意输出："},
            {"role": "user", "content": f"问题:{problem}\n约束:{constraints}\n生成{count}个创意(跨域类比/假设反转/极端案例/组合创新)"}
        ], temp=0.9)
        GW.broadcast(self.agent_name, ideas[:500], msg_type="ideation",
                     metadata={"problem": problem[:100]})
        return {"ideas": ideas, "pre_assessment": pre}

    # ─── 自我修改 (防膨胀) ─────────────────────────────────

    async def self_modify_persona(self, performance_review: str = "") -> dict:
        episodic = self._load_memory_cached("episodic")
        strategies = self._load_memory_cached("strategies")
        analysis = await self._llm_call([
            {"role": "system", "content": f"分析Agent({self.display_name})表现,输出JSON修改建议:\n{{\"identified_blindspots\":[],\"recurring_biases\":[],\"effective_strategies\":[],\"suggested_additions\":[],\"suggested_removals\":[],\"confidence\":0-100,\"rationale\":\"\"}}"},
            {"role": "user", "content": f"历史({len(episodic)}条):{json.dumps(episodic[-10:], ensure_ascii=False)[:2000]}\n策略({len(strategies)}条):{json.dumps(strategies[-10:], ensure_ascii=False)[:2000]}\n评估:{performance_review}"}
        ], temp=0.3, max_tokens=1500)
        suggestions = self._extract_json(analysis) or {"suggested_additions": [], "confidence": 0}
        if suggestions.get("confidence", 0) > 60 and suggestions.get("suggested_additions"):
            adds = suggestions["suggested_additions"]
            if isinstance(adds, list):
                adds = "\n".join(adds)
            # Round 1: 防膨胀 — 只保留最后3次更新, 之前的存入语义记忆
            update_block = f"\n\n## R{int(time.time())%1000}: {adds}\n"
            # 检查persona是否已有R标记, 如果有则替换最新一条
            if "# 自我进化更新 (v2.0" in self.persona:
                # 找到"## 自我进化更新"区域, 在后面追加而非无限增长
                marker = "## 自我进化更新 (v2.0 校准系统升级)"
                if marker in self.persona:
                    idx = self.persona.index(marker)
                    # 保留A/B/C部分, 在C后追加新条目
                    base = self.persona[:idx + len(marker)]
                    rest = self.persona[idx + len(marker):]
                    # 将新增写入而不是无限追加
                    updated = base + rest.rstrip() + update_block
                else:
                    updated = self.persona + update_block
            else:
                updated = self.persona + update_block

            with open(self.agent_dir / "persona.md", "w", encoding="utf-8") as f:
                f.write(updated)
            self.persona = updated
            self._append_memory("semantic", {"type": "persona_update", "additions": adds})
            return {"status": "applied", "changes": suggestions}
        return {"status": "skipped", "reason": f"confidence {suggestions.get('confidence', 0)} too low", "suggestions": suggestions}

    # ─── 对抗验证 ──────────────────────────────────────────

    async def adversarial_verify(self, content: str, context: str = "") -> dict:
        v = await self._llm_call([
            {"role": "system", "content": "严格对抗验证器. 输出JSON:\n{\"overall_assessment\":\"通过|需修改|不合格\",\"issues\":[{\"severity\":\"致命|严重|轻微\",\"description\":\"...\",\"suggestion\":\"...\"}],\"strengths\":[\"...\"],\"verdict\":\"...\",\"confidence\":0-100}"},
            {"role": "user", "content": f"内容:\n{content}\n上下文:{context}" if context else f"内容:\n{content}"}
        ], temp=0.2, max_tokens=1500)
        return self._extract_json(v) or {"overall_assessment": "需修改", "issues": []}

    # ─── 自信度校准系统 v2.1 (1次API) ────────────────────

    async def calibrate_confidence(self, target: str, context: str = "") -> dict:
        """v2.1: 单次API完成发散+对抗+收敛 (原3次, 节省67%算力)"""
        unified = await self._llm_call([
            {"role": "system", "content": f"""你是{self.display_name}。执行三阶段校准，单次输出完整结果。

阶段1 发散: 生成3个完全不同视角的方案，各标注初始自信度
阶段2 对抗: 对推荐方案的每个关键假设做压力测试(概率+影响)
阶段3 收敛: 给出校准后自信度、上调/下调量、备选方案、校准经验

JSON格式(必须):
{{
  "alternatives": [
    {{"approach": "方案A描述", "confidence": 0-100, "rationale": "..."}},
    {{"approach": "方案B描述", "confidence": 0-100, "rationale": "..."}},
    {{"approach": "方案C描述", "confidence": 0-100, "rationale": "..."}}
  ],
  "recommended": "A/B/C",
  "vulnerable_assumptions": [
    {{"assumption": "...", "failure_scenario": "...", "likelihood": "高|中|低", "impact": "致命|严重|轻微"}}
  ],
  "overconfidence_risk": "...",
  "paradigm_shift_test": "...",
  "final_confidence": 0-100,
  "confidence_adjustment": "上调|下调|维持",
  "adjustment_amount": -30到30,
  "recommended_approach": "最终推荐方案",
  "contingency": "备选方案",
  "calibration_lesson": "校准经验"
}}"""},
            {"role": "user", "content": f"## 校准目标\n{target}\n\n## 上下文\n{context}"}
        ], temp=0.6, max_tokens=3000)

        cal = self._extract_json(unified) or {}

        # 提取结构化结果
        alternatives = cal.get("alternatives", [])
        assumptions = cal.get("vulnerable_assumptions", [])

        # 存储校准经验
        lesson = cal.get("calibration_lesson", "")
        if lesson:
            strategies = self._load_memory_cached("strategies")
            strategies.append({"lesson": f"[Calibration] {lesson}", "timestamp": time.time(), "source": "calibration"})
            self._save_memory("strategies", strategies)

        return {
            "alternatives": alternatives,
            "recommended": cal.get("recommended", ""),
            "adversarial_test": {
                "vulnerable_assumptions": assumptions,
                "overconfidence_risk": cal.get("overconfidence_risk", ""),
                "paradigm_shift_test": cal.get("paradigm_shift_test", "")
            },
            "calibrated_judgment": {
                "final_confidence": cal.get("final_confidence", 50),
                "confidence_adjustment": cal.get("confidence_adjustment", "维持"),
                "adjustment_amount": cal.get("adjustment_amount", 0),
                "recommended_approach": cal.get("recommended_approach", ""),
                "contingency": cal.get("contingency", ""),
                "calibration_lesson": lesson
            },
            "final_confidence": cal.get("final_confidence", 50),
            "adjustment": cal.get("confidence_adjustment", "维持"),
            "adjustment_amount": cal.get("adjustment_amount", 0)
        }

    # ─── 心智理论 ──────────────────────────────────────────

    async def theory_of_mind(self, task: str, other_agents: list[str]) -> dict:
        workspace = GW.read_broadcasts(limit=30)
        agent_states = GW.get_agent_state()
        other_ctx = []
        for name in other_agents:
            state = agent_states.get(name, {})
            recent = [b for b in workspace if b["agent"] == name][-2:]
            other_ctx.append({"agent": name, "state": {k: v for k, v in state.items() if k != "last_task"}, "recent": [b["content"][:150] for b in recent]})
        tom = await self._llm_call([
            {"role": "system", "content": self.persona + "\n输出JSON心智理论:\n{\"agent_perspectives\":{},\"consensus_points\":[],\"conflict_points\":[],\"collective_blindspot\":\"\",\"my_own_bias_from_their_view\":\"\"}"},
            {"role": "user", "content": f"任务:{task}\n其他Agent:{json.dumps(other_ctx, ensure_ascii=False)[:3000]}"}
        ], temp=0.4, max_tokens=1500)
        return self._extract_json(tom) or {"agent_perspectives": {}}
