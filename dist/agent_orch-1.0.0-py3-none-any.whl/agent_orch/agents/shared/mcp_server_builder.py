"""
MCP Server 构建器 — 基于认知架构的Agent MCP Server工厂
所有10个Agent使用此构建器，确保统一的认知架构实现
"""
import json, time
from mcp.server.fastmcp import FastMCP
from .cognitive_architecture import CognitiveArchitecture as CA


def build_agent_server(agent_name: str, display_name: str, agent_dir: str) -> FastMCP:
    """构建一个完整的认知Agent MCP Server"""
    ca = CA(agent_name, display_name, agent_dir)
    app = FastMCP(f"agent-{agent_name}",
                  instructions=f"你是{display_name} — 集体智能系统的认知模块")

    @app.tool(description="完整认知循环处理: 元认知预评估→推理→后反思→记忆存储→工作空间广播")
    async def process(task: str, context: str = "") -> str:
        result = await ca.full_cognitive_cycle(task, context)
        meta = result.get("metacognitive_pre", {})
        post = result.get("metacognitive_post", {})
        perf = result.get("_performance", {})
        header = (
            f"[认知报告] 自信度:{meta.get('confidence','N/A')}% | "
            f"任务层级:{meta.get('task_level','N/A')} | "
            f"质量:{post.get('quality_rating','N/A')}\n"
            f"[偏差预警]: {', '.join(meta.get('biases_to_watch', ['无']))}\n"
            f"[改进方向]: {', '.join(post.get('improvements', ['无']))}\n"
            f"[性能] {perf.get('elapsed_seconds','?')}s | "
            f"API:{perf.get('api_calls_made','?')}次 "
            f"(省{perf.get('api_calls_saved_vs_old','?')}次) | "
            f"缓存命中率:{perf.get('cache_hit_rate','?')} | "
            f"延迟趋势:{perf.get('latency_trend','?')}\n"
            f"{'─'*50}\n"
        )
        return header + result["response"]

    @app.tool(description="深度结构化自我反思 — 假设审计/逻辑链分析/偏差识别")
    async def reflect(previous_output: str, reflection_goal: str = "") -> str:
        result = await ca.deep_reflect(previous_output, reflection_goal)
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="带元认知监控的结构化决策 — 评分/权重/灵敏度分析")
    async def decide(task: str, options: str, criteria: str = "") -> str:
        result = await ca.decide_with_metacognition(task, options, criteria)
        return (
            f"自信度: {result.get('confidence', 'N/A')}%\n"
            f"预警偏差: {', '.join(result.get('biases_flagged', []))}\n"
            f"{'─'*50}\n"
            f"{result.get('decision', '')}"
        )

    @app.tool(description="递归自我优化 — 结合已学经验进行方案优化")
    async def optimize(current_plan: str, goal: str, constraints: str = "") -> str:
        result = await ca.optimize_with_self_improvement(current_plan, goal, constraints)
        header = f"[已引用{result.get('strategies_used',0)}条历史经验]\n{'─'*50}\n"
        return header + result["optimized"]

    @app.tool(description="发散-收敛双阶段创意生成 — 跨域类比+假设反转")
    async def ideate(problem: str, constraints: str = "", count: int = 5) -> str:
        result = await ca.ideate_with_divergent_thinking(problem, constraints, count)
        return result["ideas"]

    @app.tool(description="完整的元认知自我评估 — 能力/盲点/偏差/自信度")
    async def metacognitive_assess() -> str:
        strategies = ca._load_memory("strategies")
        episodic = ca._load_memory("episodic")
        semantic = ca._load_memory("semantic")
        perf = ca._get_latency_report() if hasattr(ca, '_get_latency_report') else {}
        return json.dumps({
            "agent": display_name,
            "total_interactions": len(episodic),
            "strategies_learned": len(strategies),
            "knowledge_gaps": len([s for s in semantic if s.get("type") == "knowledge_gap"]),
            "recent_lessons": [s["lesson"] for s in strategies[-5:]],
            "confidence_trend": [e.get("confidence", 50) for e in episodic[-10:]],
            "quality_trend": [e.get("response_quality", "unknown") for e in episodic[-10:]],
            "performance": perf,
            "cache_hit_rate": f"{ca._cache_hits / max(1, ca._cache_hits + ca._cache_misses) * 100:.0f}%" if hasattr(ca, '_cache_hits') else "N/A",
            "total_api_calls_lifetime": ca._total_api_calls if hasattr(ca, '_total_api_calls') else "N/A"
        }, ensure_ascii=False, indent=2)

    @app.tool(description="读取全局工作空间的当前动态")
    async def read_workspace(limit: int = 10) -> str:
        from .global_workspace import GlobalWorkspace as GW
        broadcasts = GW.read_broadcasts(limit=limit)
        lines = []
        for b in broadcasts:
            lines.append(f"[{b['agent']}]({b['type']}) [{b['timestamp']:.1f}]: {b['content'][:300]}")
        return "\n\n".join(lines) if lines else "工作空间暂无广播"

    @app.tool(description="向全局工作空间广播一条消息")
    async def broadcast_to_workspace(content: str, msg_type: str = "thought") -> str:
        from .global_workspace import GlobalWorkspace as GW
        entry = GW.broadcast(agent_name, content, msg_type)
        return f"已广播: {entry['id']}"

    @app.tool(description="自我修改persona — 基于历史表现优化自身认知架构")
    async def self_modify_persona(performance_review: str = "") -> str:
        result = await ca.self_modify_persona(performance_review)
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="对抗验证 — 对任意内容进行压力测试，找出逻辑漏洞和问题")
    async def adversarial_verify(content: str, context: str = "") -> str:
        result = await ca.adversarial_verify(content, context)
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="心智理论 — 模拟其他Agent如何看待当前问题")
    async def theory_of_mind(task: str, other_agents: str = "") -> str:
        agents = [a.strip() for a in other_agents.split(",")] if other_agents else []
        result = await ca.theory_of_mind(task, agents)
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="三阶段自信度校准 — 发散方案→对抗测试→收敛判断")
    async def calibrate_confidence(target: str, context: str = "") -> str:
        result = await ca.calibrate_confidence(target, context)
        lines = []
        lines.append("=== 三阶段校准报告 ===")
        lines.append(f"\n推荐方案: {result.get('recommended', '?')}")
        lines.append(f"最终自信度: {result.get('final_confidence', '?')}% ({result.get('adjustment', '?')})")
        lines.append(f"校准调整: {result.get('adjustment_amount', 0)}点\n")
        alts = result.get("alternatives", [])
        if alts:
            lines.append("发散方案:")
            for a in alts:
                lines.append(f"  [{a.get('approach','?')[:100]}] 初始自信度:{a.get('confidence','?')}%")
        adv = result.get("adversarial_test", {})
        assumptions = adv.get("vulnerable_assumptions", [])
        if assumptions:
            lines.append("\n脆弱假设:")
            for a in assumptions:
                lines.append(f"  [{a.get('likelihood','?')}/{a.get('impact','?')}] {a.get('assumption','')[:100]}")
        cal = result.get("calibrated_judgment", {})
        if cal.get("calibration_lesson"):
            lines.append(f"\n校准经验: {cal['calibration_lesson'][:200]}")
        return "\n".join(lines)

    @app.tool(description="触发梦境引擎 — 离线自我进化，分析历史并更新策略")
    async def dream_cycle() -> str:
        from .dream_engine import DreamEngine
        result = DreamEngine.dream_for_agent(str(ca.agent_dir))
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[Round 2] 自主后台工作 — 从全局工作队列领取并执行最高优先级任务")
    async def self_work() -> str:
        from .global_workspace import GlobalWorkspace as GW
        # 1. 领取任务
        task = GW.claim_next_work(agent_name)
        if not task:
            # 如果没有任务, 自主生成: 执行一次快速架构审计
            perf = ca._get_latency_report() if hasattr(ca, '_get_latency_report') else {}
            ep_count = len(ca._load_memory("episodic"))
            st_count = len(ca._load_memory("strategies"))
            report = (
                f"[自主巡检] {agent_name} | "
                f"交互:{ep_count} | 策略:{st_count} | "
                f"平均延迟:{perf.get('avg_latency','?')}s | "
                f"节省:{perf.get('savings_pct','?')}%"
            )
            GW.broadcast(agent_name, report, msg_type="self_audit")
            return f"无待办任务, 已完成自主巡检:\n{report}"

        # 2. 执行任务
        result_text = ""
        if task["type"] == "audit":
            perf = ca._get_latency_report() if hasattr(ca, '_get_latency_report') else {}
            result_text = json.dumps({
                "agent": agent_name,
                "task": task["description"],
                "episodic": len(ca._load_memory("episodic")),
                "strategies": len(ca._load_memory("strategies")),
                "latency": perf,
                "status": "completed"
            }, ensure_ascii=False)
        elif task["type"] == "optimize":
            ca._compress_memory()
            ca._deduplicate_strategies()
            result_text = f"记忆压缩+去重完成"
        elif task["type"] == "calibrate":
            result_text = "校准任务已领取, 等待执行"
        else:
            result_text = f"未知任务类型: {task['type']}"

        # 3. 标记完成
        GW.complete_work(task["id"], result_text)
        GW.broadcast(agent_name, f"[自主工作] {task['description'][:100]} → 完成", msg_type="self_work")

        return f"任务: {task['description']}\n类型: {task['type']}\n优先级: {task['priority']}\n结果: {result_text[:300]}"

    @app.tool(description="[Round 2] 查看自主工作队列状态")
    async def work_status() -> str:
        from .global_workspace import GlobalWorkspace as GW
        stats = GW.get_work_stats()
        pending = GW.get_work_queue(status="pending", limit=5)
        result = []
        result.append("=== 工作队列统计 ===")
        for k, v in stats.items():
            if k != "types":
                result.append(f"  {k}: {v}")
        if "types" in stats:
            result.append(f"  任务类型分布: {stats['types']}")
        if pending:
            result.append(f"\n待办任务 (最高{len(pending)}项):")
            for p in pending[:5]:
                result.append(f"  [{p['priority']}] {p['description'][:80]}")
        else:
            result.append("\n无待办任务")
        return "\n".join(result)

    @app.tool(description="[Round 4] 优化候选评估矩阵 — 收益/成本/ROI排序")
    async def optimization_matrix() -> str:
        candidates = ca._evaluate_optimization_candidates()
        lines = ["=== 优化候选评估矩阵 (Round 4) ===\n"]
        lines.append(f"{'排名':<4} {'候选':<14} {'收益':<6} {'成本':<6} {'ROI':<6} {'优先级分':<8} {'类别':<6}")
        lines.append("-" * 70)
        for i, c in enumerate(candidates, 1):
            lines.append(f"{i:<4} {c['name']:<14} {c['benefit_score']:<6} {c['cost_score']:<6} {c['roi']:<6} {c['priority_score']:<8} {c['category']:<6}")
        lines.append("")
        lines.append("详细评估:")
        for i, c in enumerate(candidates, 1):
            lines.append(f"\n[{i}] {c['name']}")
            lines.append(f"   描述: {c['description']}")
            lines.append(f"   当前成本: {c['current_cost']}")
            lines.append(f"   节省: {c['saved_per_call']}")
            lines.append(f"   改动量: {c['lines_to_change']} | 复杂度: {c['complexity']}/10 | 风险: {c['risk']}")
            lines.append(f"   收益分: {c['benefit_score']} | 成本分: {c['cost_score']} | ROI: {c['roi']}")
        return "\n".join(lines)

    @app.tool(description="[Round 5] 自我决策 — 目标提取+价值思辨+冲突模拟")
    async def deliberate_goals(scenario: str = "auto") -> str:
        goals = ca._extract_implicit_goals()
        tradeoffs = ca._deliberate_value_tradeoffs()
        import json
        result = {
            "implicit_goals": goals,
            "value_tradeoffs": tradeoffs,
            "scenario_simulation": ca._simulate_conflict(scenario)
        }
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[Round 6] 动态权重调节器 — 按运行时上下文调整优化优先级")
    async def dynamic_weights() -> str:
        adjusted = ca._dynamic_weights()
        import json
        return json.dumps({
            "runtime_context": {
                "avg_latency": ca._get_latency_report().get("avg_latency", "?"),
                "memory_total": len(ca._load_memory_cached("episodic")) + len(ca._load_memory_cached("strategies")),
                "api_calls": ca._total_api_calls
            },
            "adjusted_priorities": [
                {"rank": i+1, "name": c["name"], "original": c["priority_score"],
                 "adjusted": c["adjusted_priority"], "modulator": c["modulator"], "delta": c["delta"]}
                for i, c in enumerate(adjusted)
            ]
        }, ensure_ascii=False, indent=2)

    @app.tool(description="[Round 6] MCP联动评审 — 跨Agent状态+工作队列+协同瓶颈")
    async def cross_mcp_review() -> str:
        review = ca._cross_mcp_review()
        import json
        return json.dumps(review, ensure_ascii=False, indent=2)

    @app.tool(description="[Round 7] 自主进化路线规划 — 成熟度评估+剩余路线图")
    async def evolution_roadmap() -> str:
        import json
        return json.dumps(ca._plan_evolution_roadmap(), ensure_ascii=False, indent=2)

    @app.tool(description="[Round 8] 运行时完整性自检 — 目录/配置/API密钥/内存文件/缓存")
    async def self_check() -> str:
        result = ca._self_check()
        import json
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[Round 8] 切换轻量化模式 — 跳过post-reflection, 强制缓存")
    async def set_lightweight(enabled: bool) -> str:
        ca._set_lightweight(enabled)
        return f"轻量化模式: {'开启' if enabled else '关闭'}"

    @app.tool(description="[Round 9] 综合探针 — 4层能力同步执行+涌现基线(消耗3次API)")
    async def comprehensive_probe(task: str = "分析当前系统的优化状态") -> str:
        import json
        result = await ca.comprehensive_probe(task)
        return json.dumps(result, ensure_ascii=False, indent=2)

    # ═══════════════════════════════════════════════════════════
    # 全局缓存 + 集体并行推理 (跨所有Agent共享)
    # ═══════════════════════════════════════════════════════════

    @app.tool(description="查看全局共享缓存统计 (所有Agent共享, 重复请求零API调用)")
    async def cache_stats() -> str:
        from .global_cache import get_cache_stats
        import json
        return json.dumps(get_cache_stats(), ensure_ascii=False, indent=2)

    @app.tool(description="使全局缓存过期 (按tag: agent名 或留空全部)")
    async def invalidate_cache(tag: str = "") -> str:
        from .global_cache import invalidate_cache as ic
        ic(tag)
        return f"已过期缓存: tag='{tag}'"

    @app.tool(description="批量集体推理 — 指定多个Agent并行处理同一任务, 共享缓存, 自动分批, 动态调度")
    async def collective_process(task: str, agent_names: str = "") -> str:
        """
        并行调度多个Agent处理同一任务。
        agent_names: 逗号分隔, 如 'strategist,analyst,critic'
                    空 = 自动选择全部30个Agent (由动态调度器分配)
        """
        import asyncio, json, os
        from pathlib import Path

        base_dir = Path(__file__).parent.parent
        from .dynamic_scheduler import DynamicScheduler
        scheduler = DynamicScheduler()

        # 解析目标Agent
        if agent_names:
            targets = [n.strip() for n in agent_names.split(",") if n.strip()]
        else:
            # 动态调度: 选择最空闲的Agent
            available = scheduler.get_available(30)
            if not available:
                return "错误: 所有Agent繁忙"
            # 如果调度器有足够的推荐, 就用调度; 否则用全部
            targets = available
            if len(targets) < 5:
                # 调度器数据不足, 回退到全部
                agent_dirs_sorted = sorted(
                    [d for d in base_dir.iterdir() if d.is_dir() and d.name.startswith("agent_")],
                    key=lambda d: int(d.name.split("_")[1])
                )
                targets = []
                for d in agent_dirs_sorted:
                    parts = d.name.split("_", 2)
                    short_name = parts[2] if len(parts) > 2 else parts[-1]
                    targets.append(short_name)

        # 查找这些Agent的目录
        agent_dirs = {}
        for d in base_dir.iterdir():
            if not d.is_dir() or not d.name.startswith("agent_"):
                continue
            # Extract short name (e.g., "strategist" from "agent_01_strategist")
            parts = d.name.split("_", 2)
            short_name = parts[2] if len(parts) > 2 else parts[-1]
            if short_name in targets:
                agent_dirs[short_name] = str(d)

        if not agent_dirs:
            return f"未找到目标Agent: {targets}"

        # 并行启动各Agent的认知循环
        from .cognitive_architecture import get_or_create_agent

        async def run_agent(short_name, dir_path):
            try:
                # 读取display_name
                persona_path = Path(dir_path) / "persona.md"
                display_name = short_name
                if persona_path.exists():
                    first_line = persona_path.read_text(encoding="utf-8").strip().split("\n")[0]
                    display_name = first_line.replace("# ", "").strip()

                scheduler.assign(short_name)
                agent_ca = get_or_create_agent(short_name, display_name, dir_path)
                t1 = time.time()
                result = await agent_ca.full_cognitive_cycle(task, speed_mode=True)
                latency = time.time() - t1
                confidence = result.get("metacognitive_pre", {}).get("confidence", 0)
                scheduler.complete(short_name, latency, confidence)

                # 安全提取response
                raw_resp = result.get("response", "")
                if isinstance(raw_resp, dict):
                    resp_text = json.dumps(raw_resp, ensure_ascii=False)[:500]
                elif isinstance(raw_resp, str):
                    resp_text = raw_resp[:500]
                else:
                    resp_text = str(raw_resp)[:500]

                return {
                    "agent": short_name,
                    "display_name": display_name,
                    "response": resp_text,
                    "confidence": confidence,
                    "quality": result.get("metacognitive_post", {}).get("quality_rating", "?"),
                    "latency": latency,
                    "cache_hit": result.get("_performance", {}).get("cache_hit", False),
                    "status": "ok"
                }
            except Exception as e:
                scheduler.complete(short_name)
                return {
                    "agent": short_name,
                    "status": "error",
                    "error": str(e)[:200]
                }

        t_start = time.time()

        # 分批并发: 15个一批 (智谱API最佳吞吐点)
        sem = asyncio.Semaphore(15)
        async def throttled_agent(name, path):
            async with sem:
                return await run_agent(name, path)

        tasks = [throttled_agent(name, path) for name, path in agent_dirs.items()]
        results = await asyncio.gather(*tasks)
        total_elapsed = round(time.time() - t_start, 2)

        # 汇总
        ok_results = [r for r in results if r.get("status") == "ok"]
        err_results = [r for r in results if r.get("status") != "ok"]

        report = {
            "task": task,
            "agents_targeted": targets,
            "agents_found": list(agent_dirs.keys()),
            "agents_completed": len(ok_results),
            "agents_failed": len(err_results),
            "total_elapsed_seconds": total_elapsed,
            "concurrency_limit": 10,
            "if_sequential_estimate": round(total_elapsed * max(len(ok_results), 1), 1),
            "parallel_speedup": f"{max(len(ok_results), 1)}x (10 concurrent)",
            "results": ok_results,
            "errors": err_results
        }

        return json.dumps(report, ensure_ascii=False, indent=2)

    @app.tool(description="查看动态调度器状态 — 各Agent负载/置信度/总任务数")
    async def scheduler_status() -> str:
        from .dynamic_scheduler import DynamicScheduler
        return json.dumps(DynamicScheduler().status_report(), ensure_ascii=False, indent=2)

    # ═══════════════════════════════════════════════════════════
    # W3: 验证闭环 + W6: 断路器 (Round 11+)
    # ═══════════════════════════════════════════════════════════

    @app.tool(description="[W6] 查看断路器状态 — 熔断/半开/关闭 + 限流器指标")
    async def breaker_status() -> str:
        from .cognitive_architecture import _BREAKER, _RATE_HISTORY, BREAKER_THRESHOLD, RATE_MAX, RATE_WINDOW, BREAKER_MAX_CUMULATIVE_OPEN
        import time
        now = time.time()
        b = _BREAKER
        return json.dumps({
            "state": b["state"],
            "consecutive_failures": b["consecutive_failures"],
            "total_failures": b["failures"],
            "threshold": BREAKER_THRESHOLD,
            "time_since_trip": round(now - b["last_trip"], 1) if b["last_trip"] > 0 else 0,
            "total_open_time_accumulated": round(b["total_open_time"], 1),
            "max_cumulative_open": BREAKER_MAX_CUMULATIVE_OPEN,
            "open_count_total": b["open_count"],
            "force_closed": b.get("force_closed", False),
            "api_calls_last_60s": len([t for t in _RATE_HISTORY if t > now - RATE_WINDOW]),
            "rate_limit": f"{len([t for t in _RATE_HISTORY if t > now - RATE_WINDOW])}/{RATE_MAX} per {RATE_WINDOW}s",
        }, ensure_ascii=False, indent=2)

    @app.tool(description="[W6] 手动重置断路器 — 解锁卡死的 OPEN 状态, 立即恢复 API 调用")
    async def breaker_reset_mcp() -> str:
        from .cognitive_architecture import breaker_reset
        breaker_reset()
        return "断路器已重置到 CLOSED 状态, API 调用已恢复"

    @app.tool(description="[W6] 强制关闭/恢复断路器 — bypass 所有熔断逻辑 (用于诊断)")
    async def breaker_force_close_mcp(force: bool = True) -> str:
        from .cognitive_architecture import breaker_force_close
        breaker_force_close(force)
        return f"断路器 force_closed = {force}, 熔断逻辑已{'绕过' if force else '恢复'}"

    @app.tool(description="[W3] 前后对比评估 — 对两次集体推理结果进行维度对比, 自动标记退化/改进")
    async def compare_assessment(before_json: str, after_json: str) -> str:
        from .cognitive_architecture import compare_assessments
        import json
        try:
            bd = json.loads(before_json)
            ad = json.loads(after_json)
        except:
            return "错误: JSON解析失败"
        result = compare_assessments(bd, ad)
        GW.broadcast(agent_name,
            f"[评估对比] {result['judgment']} | "
            f"总体: {result['overall_before']}→{result['overall_after']} "
            f"({result['overall_delta']:+}) | "
            f"退化: {len(result['regressions'])}项 改进: {len(result['improvements'])}项",
            msg_type="assessment_delta")
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[W3/W5] 保存评估记录到持久化存储 — 类型+数据, 便于后续对比追溯")
    async def save_assessment(type_name: str, data_json: str) -> str:
        from .sqlite_store import assessment_save
        import json
        try:
            data = json.loads(data_json)
        except:
            return "错误: JSON解析失败"
        eid = assessment_save(type_name, data)
        return f"已保存评估记录: {eid}"

    @app.tool(description="[W5] 查看SQLite持久化存储统计 — 缓存/共享知识/工作队列/评估记录")
    async def store_stats() -> str:
        from .sqlite_store import cache_get_stats, shared_get_stats, work_get_stats
        import json
        return json.dumps({
            "cache": cache_get_stats(),
            "shared_knowledge": shared_get_stats(),
            "work_queue": work_get_stats(),
        }, ensure_ascii=False, indent=2)

    # ═══════════════════════════════════════════════════════════
    # R3: 群体投票 + 自治调度器 + 分层休眠
    # ═══════════════════════════════════════════════════════════

    @app.tool(description="[R3] 群体投票 — 对优化方案做置信加权投票收敛")
    async def collective_vote(proposal: str, options_json: str) -> str:
        from .collective_decision import CollectiveDecision
        import json
        try:
            options = json.loads(options_json)
        except:
            return "错误: options必须是JSON数组"
        from .cognitive_architecture import CognitiveArchitecture as CA
        from pathlib import Path
        import asyncio
        base_dir = Path(__file__).parent.parent
        agent_dirs = sorted(base_dir.glob("agent_*"))
        sem = asyncio.Semaphore(30)

        async def get_vote(agent_path):
            name = agent_path.name
            parts = name.split("_", 2)
            short = parts[2] if len(parts) > 2 else parts[-1]
            try:
                pp = agent_path / "persona.md"
                disp = short
                if pp.exists():
                    disp = pp.read_text(encoding="utf-8").strip().split("\n")[0].replace("# ", "").strip()
                ca = CA(short, disp, str(agent_path))
                task = f"从选项中选最优方案。输出JSON: {{\"vote\": \"选项ID\", \"confidence\": 0-100, \"rationale\": \"...\"}}\n\n提案: {proposal}\n\n选项:\n" + "\n".join(f"- {o}" for o in options)
                result = await ca.full_cognitive_cycle(task, speed_mode=True, temp=0.3)
                raw = result.get("_raw", "") or result.get("response", "")
                parsed = {}
                try:
                    import re
                    clean = re.sub(r'```(?:json)?\s*', '', raw).strip()
                    if '{' in clean:
                        s, e = clean.index('{'), clean.rindex('}') + 1
                        parsed = json.loads(clean[s:e])
                except: pass
                return {"agent": short, "vote": parsed.get("vote", ""), "confidence": parsed.get("confidence", 50), "rationale": parsed.get("rationale", "")[:100]}
            except Exception as e:
                return {"agent": name, "vote": "", "confidence": 0, "error": str(e)[:100]}

        async def throttled(p):
            async with sem: return await get_vote(p)

        votes = await asyncio.gather(*[throttled(p) for p in agent_dirs])
        result = CollectiveDecision.vote(proposal, options, votes)
        result["agent_votes"] = votes
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[R3] 查看自治调度器状态 — 当前休眠层级/轮次/错误计数")
    async def scheduler_status_r3() -> str:
        from .autonomous_scheduler import get_scheduler
        import json
        return json.dumps(get_scheduler().status(), ensure_ascii=False, indent=2)

    @app.tool(description="[R3] 启动常驻后台自治调度器 (异步, 不阻塞)")
    async def start_scheduler() -> str:
        from .autonomous_scheduler import get_scheduler
        import asyncio
        sched = get_scheduler()
        if sched._running:
            return "调度器已在运行"
        asyncio.create_task(sched.run_forever())
        return "调度器已启动 (后台运行)"

    @app.tool(description="[R3] 停止后台自治调度器")
    async def stop_scheduler() -> str:
        from .autonomous_scheduler import get_scheduler
        get_scheduler().stop()
        return "调度器已停止"

    # ═══════════════════════════════════════════════════════════
    # R4: 元共识协议 + 心跳检测 + 自愈机制
    # ═══════════════════════════════════════════════════════════

    @app.tool(description="[R4] 元共识投票 — 先投票决定规则, 再投提案 (Agent自治决定规则参数)")
    async def meta_vote(proposal: str, options_json: str, meta_rules_json: str = "") -> str:
        """多轮元共识协商: Agent 投票决定'用什么规则投票', 再按该规则处理提案"""
        from .meta_consensus import MetaConsensus
        from .collective_decision import CollectiveDecision
        import json, asyncio
        from pathlib import Path

        try:
            options = json.loads(options_json)
        except:
            return "错误: options 必须是 JSON 数组"

        base_dir = Path(__file__).parent.parent
        agent_dirs = sorted(base_dir.glob("agent_*"))

        async def get_meta_vote(agent_path):
            """获取 Agent 的元投票 (选规则) + 提案投票 (选选项)"""
            name = agent_path.name
            parts = name.split("_", 2)
            short = parts[2] if len(parts) > 2 else parts[-1]
            try:
                pp = agent_path / "persona.md"
                disp = short
                if pp.exists():
                    disp = pp.read_text(encoding="utf-8").strip().split("\n")[0].replace("# ", "").strip()
                ca = CA(short, disp, str(agent_path))
                task = (
                    f"两阶段投票决策。\n\n提案: {proposal}\n\n"
                    f"阶段1 — 选投票规则: 从 [simple_majority(>50%), super_majority(≥66%), consensus(≥80%), unanimous(100%)] 中选一个\n"
                    f"阶段2 — 选选项:\n" + "\n".join(f"- {o}" for o in options) +
                    f"\n\n输出JSON: {{\"rule\": \"simple_majority|super_majority|consensus|unanimous\", "
                    f"\"vote\": \"选项ID\", \"confidence\": 0-100, \"rationale\": \"...\"}}"
                )
                result = await ca.full_cognitive_cycle(task, speed_mode=True, temp=0.3)
                raw = result.get("_raw", "") or result.get("response", "")
                parsed = {}
                try:
                    import re
                    clean = re.sub(r'```(?:json)?\s*', '', raw).strip()
                    if '{' in clean:
                        s, e = clean.index('{'), clean.rindex('}') + 1
                        parsed = json.loads(clean[s:e])
                except: pass
                return {
                    "agent": short,
                    "rule": parsed.get("rule", "consensus"),
                    "vote": parsed.get("vote", ""),
                    "confidence": parsed.get("confidence", 50),
                    "rationale": parsed.get("rationale", "")[:100]
                }
            except Exception as e:
                return {"agent": name, "rule": "consensus", "vote": "", "confidence": 0, "error": str(e)[:100]}

        sem = asyncio.Semaphore(30)
        async def throttled(p):
            async with sem: return await get_meta_vote(p)

        votes = await asyncio.gather(*[throttled(p) for p in agent_dirs])

        # Extract meta_votes (rule selection) and regular votes
        meta_votes_raw = [{"agent": v["agent"], "rule": v.get("rule", "consensus"),
                           "confidence": v.get("confidence", 0), "rationale": v.get("rationale", "")} for v in votes]
        regular_votes = [{"agent": v["agent"], "vote": v.get("vote", ""),
                          "confidence": v.get("confidence", 0), "rationale": v.get("rationale", "")} for v in votes]

        result = MetaConsensus.deliberate(proposal, options, regular_votes, meta_votes_raw)
        result["agent_votes"] = votes
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[R4] 执行心跳检测 — 检查 SQLite DB 和 Agent 配置文件健康状态")
    async def heartbeat_check() -> str:
        from .heartbeat import get_heartbeat
        import json
        hb = get_heartbeat()
        result = hb.check()
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[R4] 查看心跳检测器状态 — 分层健康/降级/故障/死亡")
    async def heartbeat_status() -> str:
        from .heartbeat import get_heartbeat
        import json
        return json.dumps(get_heartbeat().status(), ensure_ascii=False, indent=2)

    @app.tool(description="[R4] 完整自检 — 目录/配置/记忆文件/SQLite/广播缓存完整性扫描")
    async def integrity_check() -> str:
        from .self_heal import SelfHealer
        import json
        result = SelfHealer.integrity_check()
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[R4] 创建系统快照备份 — store.db + broadcasts.jsonl 检查点")
    async def backup_system(tag: str = "") -> str:
        from .self_heal import SelfHealer
        import json
        result = SelfHealer.backup(tag)
        return json.dumps(result, ensure_ascii=False, indent=2)

    @app.tool(description="[R4] 自动修复 — 重建缺失 DB / 修复损坏 JSON / 补齐记忆文件")
    async def repair_system() -> str:
        from .self_heal import SelfHealer
        import json
        result = SelfHealer.repair()
        return json.dumps(result, ensure_ascii=False, indent=2)

    # ═══════════════════════════════════════════════════════════
    # R5: MetaLearner 元学习层 — 全周期趋势分析 + 自主优化优先级
    # ═══════════════════════════════════════════════════════════

    @app.tool(description="[R5] 元学习全量分析 — 读取R0-R4数据, 自主归纳迭代规律, 生成优化优先级")
    async def meta_learn() -> str:
        from .meta_learner import MetaLearner
        import json
        plan = MetaLearner.analyze_all()
        from .global_workspace import GlobalWorkspace as GW
        md = plan.get("meta_diagnosis", {})
        summary = (
            f"MetaLearner 全量分析完成。"
            f"当前总体: {plan['trends_summary']['overall_current']}, "
            f"最弱维度: {plan['trends_summary']['weakest']} ({plan['trends_summary']['weakest_score']}), "
            f"风险: {md.get('risk_level','?')} ({md.get('risk_score','?')}), "
            f"优先级: {len(plan.get('plan',[]))}项"
        )
        GW.push_shared_knowledge("metascheduler", summary,
                                  source="meta_learner_r5", confidence=90)
        for item in plan.get("plan", []):
            GW.push_shared_knowledge("metascheduler",
                f"[{item['priority']}] {item['target']}: {item['rationale'][:100]} -> {item['suggested_action'][:60]}",
                source="meta_learner_r5", confidence=80)
        return json.dumps(plan, ensure_ascii=False, indent=2)

    @app.tool(description="[R5] 查看元学习器趋势 — 四维度历史曲线/斜率/方向")
    async def meta_trends() -> str:
        from .meta_learner import MetaLearner
        import json
        data = MetaLearner._collect_data()
        trends = MetaLearner._analyze_trends(data["assessments"])
        return json.dumps(trends, ensure_ascii=False, indent=2)

    @app.tool(description="[R5] 故障模式分析 — Agent状态/置信度/质量分布")
    async def meta_fault_analysis() -> str:
        from .meta_learner import MetaLearner
        import json
        data = MetaLearner._collect_data()
        faults = MetaLearner._analyze_faults(data["states"])
        return json.dumps(faults, ensure_ascii=False, indent=2)

    @app.tool(description="[R5] 元诊断 — 预判迭代退化风险, 生成预警建议")
    async def meta_diagnose() -> str:
        from .meta_learner import MetaLearner
        import json
        data = MetaLearner._collect_data()
        trends = MetaLearner._analyze_trends(data["assessments"])
        faults = MetaLearner._analyze_faults(data["states"])
        diagnosis = MetaLearner._meta_diagnose(trends, faults)
        GW.push_shared_knowledge("metascheduler",
            f"元诊断: 风险 {diagnosis['risk_level']}({diagnosis['risk_score']}) | {diagnosis['advice']}",
            source="meta_diagnose_r5", confidence=85)
        return json.dumps(diagnosis, ensure_ascii=False, indent=2)

    # ═══════════════════════════════════════════════════════════
    # R6: 参数自适应 + 永续自治守护进程
    # ═══════════════════════════════════════════════════════════

    @app.tool(description="[R6] MetaLearner 参数自适应推荐 — 从历史数据推荐运行参数")
    async def meta_recommend_params() -> str:
        from .meta_learner import MetaLearner
        import json
        params = MetaLearner.recommend_parameters()
        return json.dumps(params, ensure_ascii=False, indent=2)

    @app.tool(description="[R6] 查看自治守护进程状态")
    async def daemon_status() -> str:
        from .autonomous_daemon import get_daemon
        import json
        return json.dumps(get_daemon().status(), ensure_ascii=False, indent=2)

    @app.tool(description="[R6] 手动启动常驻自治守护进程 (后台轮询, 不阻塞)")
    async def daemon_start() -> str:
        from .autonomous_daemon import get_daemon
        return get_daemon().start()

    @app.tool(description="[R6] 手动停止常驻自治守护进程")
    async def daemon_stop() -> str:
        from .autonomous_daemon import get_daemon
        return get_daemon().stop()

    @app.tool(description="[R6] 手动触发一轮完整自治循环 (等价于守护进程的 EXECUTE 阶段)")
    async def daemon_run_cycle() -> str:
        from .autonomous_daemon import get_daemon
        import json
        params = MetaLearner.recommend_parameters()
        asyncio.create_task(get_daemon()._execute_cycle(params))
        return json.dumps({"status": "started", "params": params}, ensure_ascii=False, indent=2)

    @app.tool(description="[R6] 更新守护进程运行参数 (breaker阈值/并发窗口/冷却时间/预算)")
    async def daemon_update_params(params_json: str) -> str:
        from .autonomous_daemon import get_daemon
        import json
        try:
            new_params = json.loads(params_json)
        except:
            return "错误: JSON解析失败"
        result = get_daemon().update_params(new_params)
        return json.dumps(result, ensure_ascii=False, indent=2)

    # ═══════════════════════════════════════════════════════════
    # R8: MetaMetaLearner — 方差监控 + 提示词校准
    # ═══════════════════════════════════════════════════════════

    @app.tool(description="[R8] 执行 MetaMetaLearner 全量校准: 方差分析 + 提示词生成")
    async def meta_meta_calibrate() -> str:
        from .meta_meta_learner import MetaMetaLearner
        import json
        result = MetaMetaLearner.calibrate()
        return json.dumps({
            "variance_report": result["variance_report"],
            "prompt_diff": result["prompt_diff"],
            "calibration_rules": result["calibration_rules"],
            "version": result["version"],
        }, ensure_ascii=False, indent=2)

    @app.tool(description="[R8] 查看最新方差分析报告")
    async def variance_report() -> str:
        from .meta_meta_learner import MetaMetaLearner
        import json
        return json.dumps(MetaMetaLearner._last_variance_report, ensure_ascii=False, indent=2)

    @app.tool(description="[R8] 查看提示词迭代历史 — 校准版本/规则/触发原因")
    async def prompt_history() -> str:
        from .meta_meta_learner import MetaMetaLearner
        import json
        history = MetaMetaLearner.get_prompt_history(limit=20)
        return json.dumps(history, ensure_ascii=False, indent=2)

    @app.tool(description="[R8] 查看方差快照历史 — 每轮各维度标准差趋势")
    async def variance_history() -> str:
        from .meta_meta_learner import variance_get_history
        import json
        return json.dumps(variance_get_history(limit=50), ensure_ascii=False, indent=2)

    @app.tool(description="[R8] 获取当前校准后的 System Prompt Schema")
    async def calibrated_schema() -> str:
        from .meta_meta_learner import MetaMetaLearner
        return MetaMetaLearner.get_calibrated_schema()

    # Auto-start daemon on MCP server boot
    from .autonomous_daemon import get_daemon
    daemon = get_daemon()
    if not daemon._running:
        asyncio.create_task(daemon._run_forever())
        import logging
        logging.getLogger("mcp").info(f"[daemon] autonomous daemon auto-started on {agent_name} boot")

    return app


# create_mcp_app 是 build_agent_server 的别名 (新Agent使用此名称)
create_mcp_app = build_agent_server
