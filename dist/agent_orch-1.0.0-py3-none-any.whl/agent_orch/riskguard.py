import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import numpy as np

class RiskLevel(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

class RiskCategory(Enum):
    TECHNICAL = "Technical"
    MARKET = "Market"
    OPERATIONAL = "Operational"
    COMPLIANCE = "Compliance"
    FINANCIAL = "Financial"
    STRATEGIC = "Strategic"

@dataclass
class Risk:
    id: str
    name: str
    description: str
    category: RiskCategory
    probability: float  # 0.0 to 1.0
    impact: float  # 0.0 to 1.0
    risk_score: float = field(init=False)
    detected_date: datetime = field(default_factory=datetime.now)
    mitigation_plan: Optional[str] = None
    owner: Optional[str] = None
    status: str = "Open"
    last_reviewed: Optional[datetime] = None
    
    def __post_init__(self):
        self.risk_score = self.probability * self.impact
        self._validate_inputs()
    
    def _validate_inputs(self):
        if not 0 <= self.probability <= 1:
            raise ValueError("Probability must be between 0 and 1")
        if not 0 <= self.impact <= 1:
            raise ValueError("Impact must be between 0 and 1")
    
    def get_risk_level(self) -> RiskLevel:
        if self.risk_score >= 0.75:
            return RiskLevel.CRITICAL
        elif self.risk_score >= 0.5:
            return RiskLevel.HIGH
        elif self.risk_score >= 0.25:
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW

class RiskManager:
    def __init__(self, org_name: str):
        self.org_name = org_name
        self.risks: Dict[str, Risk] = {}
        self.risk_history: List[Dict] = []
        self.logger = logging.getLogger(f"{org_name}.RiskManager")
        self._initialize_logging()
    
    def _initialize_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s -'
)