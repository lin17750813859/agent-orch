import json
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import re
import traceback

class ErrorType(Enum):
    LOGICAL_FALLACY = "logical_fallacy"
    CIRCULAR_REASONING = "circular_reasoning"
    ASSUMPTION_VIOLATION = "assumption_violation"
    INCONSISTENCY = "inconsistency"
    MISSING_PREMISE = "missing_premise"
    OVERGENERALIZATION = "overgeneralization"
    FALSE_CAUSALITY = "false_causality"

@dataclass
class LogicalError:
    error_type: ErrorType
    location: str
    description: str
    severity: int  # 1-10
    context: Dict[str, Any]
    suggested_fix: str

class Debugger:
    def __init__(self):
        self.error_patterns = {
            ErrorType.CIRCULAR_REASONING: [
                r"(?i)because .+ is .+, and .+ is .+ because",
                r"(?i)we know .+ because .+, and .+ because we know"
            ],
            ErrorType.ASSUMPTION_VIOLATION: [
                r"(?i)assuming (without evidence|without justification)",
                r"(?i)it is clear that .* (although|even though)",
                r"(?i)obviously .* (despite|while)"
            ],
            ErrorType.INCONSISTENCY: [
                r"(?i)(but|however|yet) .* (previously|earlier) .*",
                r"(?i)on one hand .* on the other hand .*"
            ],
            ErrorType.FALSE_CAUSALITY: [
                r"(?i)because .* (therefore|thus|hence) .*",
                r"(?i)since .* (consequently|as a result) .*"
            ]
        }
        
        self.fallacy_database = {
            "ad_hominem": {
                "pattern": r"(?i)you .* (because|since) .*",
                "explanation": "Attacking the person rather than the argument",
                "fix": "Focus on the merits of the argument itself, not the person making it"
            },
            "straw_man": {
                "pattern": r"(?i)they say .* but actually .*",
                "explanation": "Misrepresenting"
}
}