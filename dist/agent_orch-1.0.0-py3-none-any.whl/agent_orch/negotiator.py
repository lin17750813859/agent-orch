import json
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import numpy as np

@dataclass
class ResourceRequest:
    agent_id: str
    resource_type: str
    quantity: float
    priority: int
    deadline: datetime
    value: float  # Perceived value of getting this resource
    flexibility: float  # 0-1, how flexible on quantity

@dataclass
class ResourceOffer:
    request_id: str
    offered_quantity: float
    price: float  # Could be in computation time, API calls, etc.
    conditions: List[str] = field(default_factory=list)
    validity_period: datetime = field(default=None)

@dataclass
class Agreement:
    request_id: str
    offer_id: str
    final_quantity: float
    final_price: float
    timestamp: datetime
    expiration: datetime
    fulfilled: bool = False

class Negotiator:
    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self.pending_requests: Dict[str, ResourceRequest] = {}
        self.pending_offers: Dict[str, ResourceOffer] = {}
        self.active_agreements: Dict[str, Agreement] = {}
        self.batna_thresholds: Dict[str, float] = {}  # Best Alternative To Negotiated Agreement
        self.logger = logging.getLogger(f"{agent_id}.Negotiator")
        
    def add_request(self, request: ResourceRequest) -> str:
        """Add a new resource request and generate a request ID"""
        request_id = f"{request.agent_id}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        self.pending_requests[request_id] = request
        return request_id
        
    def generate_offer(self, request_id: str, available_resources: float) -> Optional[ResourceOffer]:
        """Generate a counter-offer for a resource request"""
        if request_id not in self.pending_requests:
            self.logger.warning(f"Request {request_id} not found")
            return None
            
        request = self.pending_requests[request_id]