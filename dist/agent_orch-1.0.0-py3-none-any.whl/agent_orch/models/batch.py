"""
mcp-orch/models/batch.py — 核心数据模型
30-Agent Batch Task 的数据类定义
"""
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime, timezone

@dataclass
class AgentResult:
    agent_name: str
    task: str
    status: str          # success / failed / timeout
    output: str = ""
    confidence: float = 0.0
    tokens_used: int = 0
    cost_yuan: float = 0.0
    latency_ms: float = 0.0
    error: Optional[str] = None

@dataclass
class BatchTask:
    task_id: str
    description: str
    target_agents: list
    priority: int = 5    # 1-10, higher = more urgent
    budget_yuan: float = 10.0
    deadline_s: float = 120.0
    created_at: str = ""
    status: str = "pending"  # pending/running/completed/failed
    results: list = field(default_factory=list)

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()

    def total_cost(self):
        return sum(r.cost_yuan for r in self.results)

    def success_rate(self):
        if not self.results:
            return 0.0
        return sum(1 for r in self.results if r.status == "success") / len(self.results)

@dataclass
class CostRecord:
    task_id: str
    agent: str
    tokens: int
    cost_yuan: float
    timestamp: str = ""
    category: str = "inference"

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
