import json
from typing import List, Dict, Any, Tuple
import numpy as np
from dataclasses import dataclass

@dataclass
class CriticAssessment:
    score: float
    confidence: float
    flaws: List[str]
    strengths: List[str]
    suggestions: List[str]
    risk_level: str

class Critic:
    def __init__(self):
        self.bias_checks = {
            "cynicism": False,
            "pessimism": False,
            "perfectionism": False,
            "critic_privilege": False,
            "slippery_slope": False
        }
        self.confidence_threshold = 0.7
        
    def assess_quality(self, proposal: Dict[str, Any]) -> CriticAssessment:
        """
        Comprehensive quality assessment of a proposal
        Returns a structured assessment with scores, flaws, and suggestions
        """
        # Reset bias checks
        for key in self.bias_checks:
            self.bias_checks[key] = False
            
        # Initialize assessment
        assessment = CriticAssessment(
            score=0.0,
            confidence=0.0,
            flaws=[],
            strengths=[],
            suggestions=[],
            risk_level="low"
        )
        
        # Core quality checks
        assessment.flaws.extend(self._check_fundamental_flaws(proposal))
        assessment.strengths.extend(self._identify_strengths(proposal))
        assessment.suggestions.extend(self._generate_improvements(proposal))
        
        # Calculate score (0-100)
        assessment.score = self._calculate_score(proposal, assessment)
        
        # Determine confidence
        assessment.confidence = self._calculate_confidence(proposal, assessment)
        
        # Assess risk level
        assessment.risk_level = self._assess_risk_level(assessment.flaws)
        
        # Bias self-check
        self._perform_bias_check(assessment)
        
        return assessment
    
    def _check_fundamental_flaws(self, proposal: Dict[str, Any]) -> List[str]:
        """Identify
"""