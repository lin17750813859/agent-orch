import json
import time
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from .base_agent import BaseAgent
from .global_workspace import GlobalWorkspace

@dataclass
class ConflictPoint:
    """Represents a specific point of disagreement between agents"""
    topic: str
    agent1: str
    agent1_position: Any
    agent2: str
    agent2_position: Any
    confidence1: float
    confidence2: float
    metadata: Dict = field(default_factory=dict)

class Mediator(BaseAgent):
    """Conflict resolution agent that helps other agents reach consensus"""
    
    def __init__(self, name: str, workspace: GlobalWorkspace):
        super().__init__(name, workspace)
        self.conflicts: Dict[str, ConflictPoint] = {}
        self.resolution_history: List[Dict] = []
        self.negotiation_timeout = 300  # seconds
        self.active_resolutions: Dict[str, float] = {}
        
    def broadcast_conflict_alert(self, conflict_id: str, severity: str = "medium"):
        """Alert all agents about a conflict that needs resolution"""
        alert = {
            "type": "conflict_alert",
            "conflict_id": conflict_id,
            "severity": severity,
            "timestamp": time.time(),
            "mediator": self.name
        }
        self.workspace.publish(alert, self.name)
        
    def register_conflict(self, conflict: ConflictPoint):
        """Register a new conflict for resolution"""
        conflict_id = f"{conflict.agent1}_vs_{conflict.agent2}_{conflict.topic}"
        self.conflicts[conflict_id] = conflict
        self.active_resolutions[conflict_id] = time.time()
        self.broadcast_conflict_alert(conflict_id)
        
    def propose_compromise(self, conflict_id: str) -> Optional[Dict]:
        """Propose a compromise solution for a conflict"""
        if conflict_id not in self.conflicts:
            return None
            
        conflict = self.conflicts[conflict_id]
        
        # Simple c