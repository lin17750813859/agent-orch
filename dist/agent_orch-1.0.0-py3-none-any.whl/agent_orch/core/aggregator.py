"""
mcp-orch/core/aggregator.py — 多Agent结果聚合
支持合并、投票排序、共识检测
"""
from collections import Counter

class ResultAggregator:
    def __init__(self):
        self.results = []

    def add(self, agent, output, confidence=0.0):
        self.results.append({
            "agent": agent,
            "output": output,
            "confidence": confidence,
        })

    def merge_all(self):
        return "\n\n---\n\n".join(
            f"**{r['agent']}** (置信度:{r['confidence']}):\n{r['output']}"
            for r in self.results
        )

    def consensus_topics(self, min_mentions=2):
        all_words = []
        for r in self.results:
            all_words.extend(r["output"].lower().split())
        return Counter(all_words).most_common(10)

    def confidence_rank(self):
        return sorted(self.results, key=lambda x: -x["confidence"])

    def majority_vote(self, options):
        votes = Counter()
        for r in self.results:
            for opt in options:
                if opt.lower() in r["output"].lower():
                    votes[opt] += 1
        return votes.most_common()

    def summary(self):
        return {
            "total_agents": len(self.results),
            "avg_confidence": sum(r["confidence"] for r in self.results) / max(len(self.results), 1),
            "top_agents": [r["agent"] for r in self.confidence_rank()[:3]],
        }
