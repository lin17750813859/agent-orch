"""
mcp-orch/core/self_heal.py — 自治自愈脚本
检测系统异常并自动修复
"""
import json, os, sys, time, asyncio
from pathlib import Path

BASE = Path(__file__).parent
LEDGER = BASE / "account_ledger.json"
sys.path.insert(0, str(BASE))

async def auto_heal():
    findings = []

    # 1. 检查账本完整性
    with open(LEDGER) as f:
        ledger = json.load(f)
    balance = ledger["balance"]
    tx_count = len(ledger["transactions"])
    computed = 1000.0
    for tx in ledger["transactions"]:
        if tx["type"] == "expense":
            computed += tx["amount_yuan"]
    computed = round(computed, 2)
    if abs(computed - balance) > 0.001:
        findings.append(f"账本不一致: 计算值¥{computed}  !=  记录值¥{balance}")

    # 2. 检查孤立工作空间文件
    ws = BASE / "workspace"
    orphaned = []
    expected = {"evolution_history", "circuit_breaker_state.json"}
    for f in ws.iterdir():
        if f.is_file() and f.name not in expected:
            orphaned.append(f.name)
    if orphaned and len(orphaned) > 5:
        findings.append(f"工作空间有 {len(orphaned)} 个孤立文件")

    # 3. 生成自愈建议
    report = {
        "timestamp": time.time(),
        "balance": balance,
        "tx_count": tx_count,
        "findings": findings,
        "healthy": len(findings) == 0,
        "suggestion": "无" if not findings else "; ".join(findings),
    }

    healdir = BASE / "workspace" / "heal_reports"
    healdir.mkdir(exist_ok=True)
    with open(healdir / f"heal_{int(time.time())}.json", "w") as f:
        json.dump(report, f, indent=2)

    return report

if __name__ == "__main__":
    report = asyncio.run(auto_heal())
    status = "✅" if report["healthy"] else "⚠️"
    print(f"{status} 自愈检查 | 余额¥{report['balance']} | {report['suggestion']}")
