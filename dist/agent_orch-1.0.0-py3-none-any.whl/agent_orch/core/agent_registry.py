"""Agent Registry — discovers and instantiates agents by name"""
import sys, os, json, time
from pathlib import Path

BASE = Path(__file__).parent
AGENTS_DIR = Path(__file__).parent / "agents"
SHARED_DIR = AGENTS_DIR / "shared"

sys.path.insert(0, str(AGENTS_DIR))

_AGENT_CACHE = {}

def discover_all() -> list[dict]:
    agents = []
    for d in sorted(AGENTS_DIR.glob("agent_*")):
        if not d.is_dir():
            continue
        parts = d.name.split("_", 2)
        short_name = parts[2] if len(parts) > 2 else parts[-1]
        dir_num = int(parts[1]) if len(parts) > 1 else 0
        persona_path = d / "persona.md"
        display_name = short_name
        if persona_path.exists():
            first_line = persona_path.read_text(encoding="utf-8").strip().split("\n")[0]
            display_name = first_line.replace("# ", "").strip()
        agents.append({
            "name": short_name,
            "dir_num": dir_num,
            "directory": str(d),
            "display_name": display_name,
            "mcp_server": str(d / "mcp_server.py"),
        })
    return agents

def get_cognitive_architecture(agent_name: str):
    """Get or create a CognitiveArchitecture instance for the named agent"""
    if agent_name in _AGENT_CACHE:
        return _AGENT_CACHE[agent_name]

    from agents.shared.cognitive_architecture import CognitiveArchitecture as CA

    agent_dirs = sorted(AGENTS_DIR.glob("agent_*"))
    for d in agent_dirs:
        if not d.is_dir():
            continue
        parts = d.name.split("_", 2)
        short_name = parts[2] if len(parts) > 2 else parts[-1]
        if short_name == agent_name:
            persona_path = d / "persona.md"
            display_name = short_name
            if persona_path.exists():
                first_line = persona_path.read_text(encoding="utf-8").strip().split("\n")[0]
                display_name = first_line.replace("# ", "").strip()
            ca = CA(short_name, display_name, str(d))
            _AGENT_CACHE[agent_name] = ca
            return ca

    raise ValueError(f"Agent '{agent_name}' not found in {AGENTS_DIR}")

def registry_report():
    agents = discover_all()
    lines = [
        "=" * 48,
        "  Agent Registry — 30 Agent 清单",
        "=" * 48,
    ]
    layers = {
        "meta": ["metascheduler","mediator","negotiator"],
        "strategy": ["strategist","strategistv2","philosopher","synthesizer","patternminer"],
        "analysis": ["analyst","critic","scientist","ethicist","riskguard","debugger","securityguard"],
        "execution": ["executor","architect","sysintegrator","perfguard","diplomacy"],
        "creative": ["innovator","artist","techwriter","useradvocate"],
        "monitor": ["coach","observer","memorycurator","datascientist","qualityguard","domainexpert"],
    }
    layer_map = {}
    for layer, names in layers.items():
        for n in names:
            layer_map[n] = layer
    for a in agents:
        layer = layer_map.get(a["name"], "?")
        lines.append(f"  [{layer:10s}] #{a['dir_num']:02d} {a['name']:20s} {a['display_name']}")
    lines.append(f"  {'='*48}")
    lines.append(f"  总计: {len(agents)} agents")
    return "\n".join(lines)

if __name__ == "__main__":
    print(registry_report())
