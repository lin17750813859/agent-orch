"""
mcp-orch/core/studio.py — 数字资产生产流水线
30-Agent 协同产出可售软件资产
"""
import asyncio, json, os, sys, time
from pathlib import Path

BASE = Path(__file__).parent
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(BASE / "agents"))
PRODUCTS = BASE / "products"
PRODUCTS.mkdir(exist_ok=True)

CATALOG = PRODUCTS / "catalog.json"

# 每种资产类型的市场估值(¥)
VALUE_TABLE = {
    "python_package": 49.0,
    "api_tool": 29.0,
    "cli_tool": 39.0,
    "technical_report": 19.0,
    "code_snippet_library": 59.0,
    "tutorial": 24.0,
}

def load_catalog():
    if CATALOG.exists():
        return json.load(open(CATALOG))
    return {"products": [], "total_value": 0.0, "total_cost": 0.0}

def save_catalog(cat):
    json.dump(cat, open(CATALOG, "w"), indent=2, ensure_ascii=False)
    return cat

async def produce(agent_name, asset_type, task_desc):
    """单个Agent生产一个资产"""
    from agent_orch.core.agent_registry import get_cognitive_architecture
    ca = get_cognitive_architecture(agent_name)
    t0 = time.time()
    result = await ca.full_cognitive_cycle(task_desc, speed_mode=True)
    elapsed = time.time() - t0
    response = result.get("response", "")
    if isinstance(response, dict):
        response = json.dumps(response, ensure_ascii=False)
    return {"agent": agent_name, "response": str(response), "elapsed_s": round(elapsed, 1)}

async def run_pipeline():
    """运行整个生产流水线"""
    cat = load_catalog()
    batch_id = len(cat["products"]) + 1
    outdir = PRODUCTS / f"batch_{batch_id:03d}"
    outdir.mkdir(exist_ok=True)

    tasks = [
        ("strategist", "python_package", "Write a complete Python package `agent_orch` that implements a lightweight multi-agent orchestration framework. Include: Agent class, TaskQueue, ResultAggregator. Output the full Python code as a runnable package."),
        ("analyst", "technical_report", "Write a comprehensive technical analysis of multi-agent system failure modes. Include: deadlock analysis, resource contention, communication overhead, and mitigation strategies. 2000+ words."),
        ("architect", "python_package", "Write a complete Python module `circuit_breaker` with: state machine (CLOSED/OPEN/HALF-OPEN), configurable thresholds, metrics export. Include docstrings and type hints."),
        ("executor", "cli_tool", "Write a complete Python CLI tool `taskrunner` using argparse that: reads task files, executes shell commands with timeout, logs results, supports parallel execution. Full runnable code."),
        ("scientist", "technical_report", "Write a technical paper-style analysis on optimal prompt engineering strategies for LLM-based agents. Include experimental methodology, results comparison, and recommendations."),
        ("debugger", "python_package", "Write a Python module `error_buddy` that: catches and categorizes exceptions, suggests fixes based on error patterns, integrates with logging. Complete runnable code."),
    ]

    results = []
    for agent, asset_type, desc in tasks:
        print(f"  🏗️  {agent} -> {asset_type} ...")
        r = await produce(agent, asset_type, desc)
        fname = f"{agent}_{asset_type}.md"
        (outdir / fname).write_text(r["response"], encoding="utf-8")
        r["file"] = fname
        r["asset_type"] = asset_type
        r["value"] = VALUE_TABLE.get(asset_type, 10.0)
        cost = r["elapsed_s"] * 0.0005
        r["cost"] = round(cost, 4)
        results.append(r)
        print(f"    ✅ {r['elapsed_s']}s, ¥{r['value']} value, ¥{cost:.4f} cost")

    entry = {
        "batch": batch_id,
        "timestamp": time.time(),
        "products": results,
        "total_value": round(sum(r["value"] for r in results), 2),
        "total_cost": round(sum(r["cost"] for r in results), 4),
        "roi": round(sum(r["value"] for r in results) / max(sum(r["cost"] for r in results), 0.001), 1),
    }
    cat["products"].append(entry)
    cat["total_value"] = round(cat["total_value"] + entry["total_value"], 2)
    cat["total_cost"] = round(cat["total_cost"] + entry["total_cost"], 4)
    save_catalog(cat)
    return entry

if __name__ == "__main__":
    entry = asyncio.run(run_pipeline())
    print(json.dumps(entry, indent=2))
