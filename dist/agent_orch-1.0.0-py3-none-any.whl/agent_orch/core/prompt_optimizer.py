"""
mcp-orch/core/prompt_optimizer.py — Agent Prompt 压缩与模板化
目标：将每Agent system prompt 从~2000 tokens 压缩至 ~500 tokens
在不损失输出质量的前提下降低每次推理成本 75%
"""
import json, re, hashlib
from pathlib import Path

BASE = Path(__file__).parent
AGENTS_DIR = Path(__file__).parent / "agents"
WORKSPACE = BASE / "workspace"

class PromptOptimizer:
    def __init__(self):
        self.compression_stats = {"original_tokens": 0, "compressed_tokens": 0, "agents_processed": 0}

    def estimate_tokens(self, text):
        return len(text) // 2

    def compress_system_prompt(self, original_prompt):
        ori_tokens = self.estimate_tokens(original_prompt)
        lines = original_prompt.split("\n")
        compressed_lines = []
        skip_keywords = ["# 详细说明", "# 背景", "例如：", "比如说", "需要注意的是"]

        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            if any(kw in stripped for kw in skip_keywords):
                continue
            if len(stripped) > 200:
                compressed_lines.append(stripped[:200] + "...")
            else:
                compressed_lines.append(stripped)

        compressed = "\n".join(compressed_lines)
        comp_tokens = self.estimate_tokens(compressed)
        ratio = (1 - comp_tokens / max(ori_tokens, 1)) * 100

        self.compression_stats["original_tokens"] += ori_tokens
        self.compression_stats["compressed_tokens"] += comp_tokens
        self.compression_stats["agents_processed"] += 1

        return compressed, round(ratio, 1)

    def scan_all_agent_prompts(self):
        results = []
        agent_dirs = sorted(AGENTS_DIR.glob("agent_*"))
        for d in agent_dirs:
            mcp_file = d / "mcp_server.py"
            if not mcp_file.exists():
                continue
            content = mcp_file.read_text(encoding="utf-8")
            system_prompts = re.findall(r'(?i)(system_prompt|instruction|persona)\s*=\s*["\']{3}(.*?)["\']{3}', content, re.DOTALL)
            for key, prompt in system_prompts:
                compressed, ratio = self.compress_system_prompt(prompt)
                results.append({
                    "agent": d.name,
                    "original_tokens": self.estimate_tokens(prompt),
                    "compressed_tokens": self.estimate_tokens(compressed),
                    "compression_ratio": ratio,
                    "savings_per_call_yuan": round(self.estimate_tokens(prompt) * 5e-06, 6),
                })
        return results

    def report(self):
        results = self.scan_all_agent_prompts()
        total_original = sum(r["original_tokens"] for r in results)
        total_compressed = sum(r["compressed_tokens"] for r in results)
        total_savings = sum(r["savings_per_call_yuan"] for r in results)

        print("=" * 56)
        print("  Agent Prompt 压缩审计报告")
        print("=" * 56)
        print(f"  扫描Agent: {len(results)}")
        print(f"  原始总Tokens: {total_original:,}")
        print(f"  压缩后Tokens: {total_compressed:,}")
        print(f"  压缩率: {(1-total_compressed/max(total_original,1))*100:.1f}%")
        print(f"  单次全循环节省: ¥{total_savings*30:.4f}")
        print(f"  10次循环节省: ¥{total_savings*30*10:.4f}")
        print("-" * 56)
        print("  Top 10 可压缩Agent:")
        for r in sorted(results, key=lambda x: -x["original_tokens"])[:10]:
            bar = "█" * int(r["compression_ratio"] / 5)
            print(f"    {r['agent']:25s} {r['original_tokens']:>5d}→{r['compressed_tokens']:>5d} ({r['compression_ratio']:5.1f}%) {bar}")
        print("=" * 56)
        return results

if __name__ == "__main__":
    po = PromptOptimizer()
    po.report()
